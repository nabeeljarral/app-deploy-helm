<?php
return [
    'trial' => [
        'duration'             => env('TRIAL_DURATION', 365), //days

        /**
         * GP-84 Trial access - Before trial period (configurable # days, 2 days by default) end and on trial period end the system shall send 2 emails
         */
        'days_until_remaining' => env('TRIAL_DAYS_UNTIL_REMAINING', 2), //days
    ],
];
