<?php
return [
    'some' => 1,
    //TODO: ...
];
