<?php
return [
    "project_id" => env('PROJECT_ID'),
    "base_uri" => env('GTR_SYNC_BASE_URI'),
    "system_data_endpoint" => env('GTR_SYNC_SYSTEM_DATA_ENDPOINT'),
    "report_endpoint" => env('GTR_SYNC_REPORT_ENDPOINT'),
];
