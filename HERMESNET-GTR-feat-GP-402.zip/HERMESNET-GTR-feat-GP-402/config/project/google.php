<?php

use Google\Service\Drive;
use Google\Service\Sheets;

return [
    "api"   => [
        "developer_key" => env("GOOGLE_DEVELOPER_KEY"),

        "config_file"   => env('GOOGLE_CONFIG_FILE'),

        "use_service_account" => env('USE_GOOGLE_SERVICE_ACCOUNT',false),
        "service_account"   => env('GOOGLE_SERVICE_ACCOUNT'),
        "service_account_email"   => env('GOOGLE_SERVICE_ACCOUNT_EMAIL'),

        'callback_uri'  => "/api/google/oauth/callback",
        'scopes'        => [
            Drive::DRIVE,
            Drive::DRIVE_FILE,
            Drive::DRIVE_METADATA,
            Drive::DRIVE_APPDATA,
            Sheets::SPREADSHEETS,
        ],
    ],
    'drive' => [

        'meta' => [
            "mime" => [
                "folder" => env('GOOGLE_DRIVE_META_MIME_FOLDER'),
            ]
        ],

        "templates_folder_id"   => env('GOOGLE_DRIVE_TEMPLATE_FOLDER'),
        "templates_file_prefix" => env('GOOGLE_DRIVE_TEMPLATE_FILE_PREFIX'),
        "clients_folder_id"     => env('GOOGLE_DRIVE_CLIENTS_FOLDER'),
        "clients_folder_prefix" => env('GOOGLE_DRIVE_CLIENTS_FOLDER_PREFIX'),
    ],
];
