<?php
return [
    "host"     => env("LOOKER_HOST"),
    "secret"   => env("LOOKER_SECRET"),
    "api_host" => env("LOOKER_API_HOST"),
    "client_id" => env('LOOKER_CLIENT_ID'),
    "client_secret" => env('LOOKER_CLIENT_SECRET'),
    "embedded" => [
        "config_template" => [
            "models"             => [],
            "group_ids"          => [],
            "last_name"          => '',
            "first_name"         => '$user.name',
            "permissions"        => [
                "see_user_dashboards",
                "see_lookml_dashboards",
                "access_data",
                "see_looks",
                "clear_cache_refresh"
            ],
            "access_filters"     => [],
            "session_length"     => 3600,
            "user_attributes"    => [
                "report_id"    => '$report.id',
                "workspace_id" => '$workspace.id',
            ],
            "external_user_id"   => '$user.id',
            "external_group_id"  => "",
            "force_logout_login" => true
        ],
    ]
];
