<?php

namespace App\Abstractions;

interface Presenter
{
    public function present() : iterable;
}
