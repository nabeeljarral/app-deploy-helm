<?php

namespace App\Abstractions\Queue;

use App\Abstractions\Runnable;
use Illuminate\Foundation\Bus\PendingDispatch;

/**
 *
 */
class DispatchAction extends Job
{
    /**
     * @var Runnable
     */
    private Runnable $action;

    /**
     * @param Runnable $action
     */
    public function __construct(Runnable $action)
    {
        $this->action = $action;
    }

    /**
     * @return mixed|void
     */
    public function handle()
    {
        $this->action->run();
    }

    /**
     * @param Runnable $action
     * @return PendingDispatch
     */
    public static function of(Runnable $action): PendingDispatch
    {
        $self = new self($action);
        return dispatch($self);
    }

    /**
     * @param \Throwable $exception
     * @return void
     */
    protected function failedLog(\Throwable $exception): void
    {
        logger()->error("[QueueAction::failed][" . get_class($this->action) . "]", [
            "code"         => $exception->getCode(),
            "message"      => $exception->getMessage(),
            "attempts"     => $this->attempts(),
            "retryAfter"   => $this->retryAfter,
            "tries"        => $this->tries,
        ]);
    }
}
