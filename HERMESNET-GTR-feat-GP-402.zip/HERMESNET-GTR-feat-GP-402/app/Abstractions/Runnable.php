<?php

namespace App\Abstractions;

/**
 *
 */
interface Runnable
{
    /**
     * @return mixed
     */
    public function run();
}
