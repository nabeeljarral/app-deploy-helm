<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class DefineDataCollectionsStructureRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'reports' => ['required', 'array'],
            'reports.*' => ['required', 'int'],
            'items' => ['required', 'array'],
            'items.*' => ['required', 'bool'],
        ];
    }

    public function authorize(): bool
    {
        return true;
    }
}
