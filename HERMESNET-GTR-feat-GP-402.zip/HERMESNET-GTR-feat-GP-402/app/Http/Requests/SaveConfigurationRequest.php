<?php

namespace App\Http\Requests;

use App\Services\Configuration\DTO\ConfigurationDto;
use Illuminate\Foundation\Http\FormRequest;

/**
 *
 */
class SaveConfigurationRequest extends FormRequest
{
    /**
     * @return array[]
     */
    public function rules(): array
    {
        return [
            'name'     => ['required', 'string'],
            'guidance' => ['nullable', 'string']
        ];
    }

    /**
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return ConfigurationDto
     */
    public function getDto(): ConfigurationDto
    {
        return ConfigurationDto::of([
            'name'            => $this->get('name'),
            'guidance'        => $this->get('guidance', ''),
            'is_general'      => false,
            'is_published'    => true,
            'organization_id' => $this->user()->organization_id,
        ]);
    }
}
