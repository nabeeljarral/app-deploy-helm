<?php

namespace App\Http\Requests;

use App\Services\User\DTO\InviteUserDto;
use App\Services\User\Enums\UserRole;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\Validation\Validator;

/**
 *
 */
class InviteUserRequest extends FormRequest
{
    /**
     * @return array
     */
    public function rules(): array
    {
        return [
            'name'           => ["required", "string"],
            'email'          => ['required', 'email'],
            'role'           => ['required', 'string', Rule::in(UserRole::AVAILABLE)],
            'environment_id' => ['required', 'int'],
            'dashboard_id'   => ['nullable', 'int'],
            'items_id'       => ['nullable', 'array'],
        ];
    }

    /**
     * @param Validator $validator
     * @return void
     */
    public function withValidator(Validator $validator): void
    {
        $validator->after(function (Validator $validator) {
            if (!in_array($this->get("role"), [UserRole::DASHBOARD_OWNER, UserRole::DASHBOARD_CONTRIBUTOR])) {
                return;
            }

            if (!$this->get("environment_id") || !$this->get("dashboard_id")) {
                $validator->errors()->add('dashboard_id', "Report and workspace required if role " . UserRole::DASHBOARD_OWNER . " or " . UserRole::DASHBOARD_CONTRIBUTOR);
            }
        });
    }

    /**
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return string[]
     */
    public function messages(): array
    {
        return [
            'user_id.required' => 'User field is required',
        ];
    }

    /**
     * @return InviteUserDto
     */
    public function getDto(): InviteUserDto
    {
        return InviteUserDto::of($this->validated());
    }
}
