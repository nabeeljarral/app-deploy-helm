<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 *
 */
class CreateEnvironmentRequest extends FormRequest
{
    /**
     * @return array
     */
    public function rules(): array
    {
        return [
            'name'             => ['required', 'string'],
            'template_id'      => ['required_if:isBlank,0'],
            'isBlank'          => ['nullable', 'bool'],
            'configuration_id' => ['nullable', 'exists:template_configurations,id']
        ];
    }

    /**
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return bool
     */
    public function isBlankEnvironment(): bool
    {
        return $this->get('isBlank', false);
    }
}
