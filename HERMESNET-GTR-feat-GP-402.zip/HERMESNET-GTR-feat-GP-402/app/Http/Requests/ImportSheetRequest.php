<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class ImportSheetRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            "sheet_id" => ["required", "int", Rule::exists('dashboard_sheets', 'id')],
            "file" => ["required", "file"]
        ];
    }

    public function authorize(): bool
    {
        return true;
    }
}
