<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class SaveProtectionConfigRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'dashboard_id'                  => ['required', 'int', Rule::exists('dashboards', 'id')],
            'unprotected'                   => ['nullable', 'array'],
            'unprotected.*.id'              => ['nullable', 'int'], // if edit
            'unprotected.*.sheet_id'        => ['required', 'int'],
            'unprotected.*.start_row_id'    => ['required', 'int'],
            'unprotected.*.end_row_id'      => ['required', 'int'],
            'unprotected.*.start_column_id' => ['required', 'int'],
            'unprotected.*.end_column_id'   => ['required', 'int'],
            'removed_unprotected'           => ['nullable', 'array'],
            'removed_unprotected.*'         => ['required', 'int'],
        ];
    }


    public function authorize(): bool
    {
        return true;
    }
}
