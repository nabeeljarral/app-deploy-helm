<?php

namespace App\Http\Requests;

use App\Services\User\Enums\UserRole;
use App\Services\User\UserPermissions\UserPermissionDto;
use GuzzleHttp\Promise\Is;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

/**
 *
 */
class ChangeUserPermissionRequest extends FormRequest
{
    /**
     * @return array
     */
    public function rules(): array
    {
        return [
            'role'           => ['required', 'string', Rule::in(UserRole::AVAILABLE)],
            'environment_id' => ['required', 'int'],
            'dashboard_id'   => ['nullable', 'int'],
        ];
    }

    /**
     * @return void
     */
    public function validateRole(): void
    {
        if (in_array($this->get("role"), [UserRole::DASHBOARD_OWNER, UserRole::DASHBOARD_CONTRIBUTOR])) {
            if (!$this->get("environment_id") || !$this->get("dashboard_id")) {
                throw ValidationException::withMessages([
                    'role' => "Report and organization required if role " . UserRole::DASHBOARD_OWNER . "or" . UserRole::DASHBOARD_CONTRIBUTOR
                ]);
            }
        }
    }

    /**
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return UserPermissionDto
     */
    public function getPermissionDto(): UserPermissionDto
    {
        $permissionDto = new UserPermissionDto();

        $permissionDto->setRole($this->get("role"));
        $permissionDto->setEnvironmentId($this->get("environment_id"));
        $permissionDto->setDashboardId($this->get("dashboard_id"));

        return $permissionDto;
    }
}
