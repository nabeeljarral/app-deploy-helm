<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;

class PrintConfElementRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            "id"                                 => ['required', 'string'],
            "name"                               => ['required', 'string'],
            "title"                              => ['required', 'string'],
            "is_parent"                          => ['nullable', 'boolean'],
            "is_mandatory"                       => ['nullable', 'boolean'],
            "is_single"                          => ['nullable', 'boolean'],
            "is_default"                         => ['nullable', 'boolean'],
            "is_embeddable"                      => ['nullable', 'boolean'],
            "order_number"                       => ['required', 'integer'],
            "elements.*.id"                      => ['nullable', 'string'],
            "elements.*.elements"                => ['nullable', 'array'],
            "elements.*.parameters"                  => ['nullable', 'array'],
            "elements.*.embeds"                  => ['nullable', 'array'],
            "elements.*.default_embeds"          => ['nullable', 'array'],
            "print_conf_template_id"             => ['required', 'string'],
            "parameters.*.id"                    => ['required', 'string'],
            "parameters.*.name"                  => ['required', 'string'],
            "parameters.*.title"                 => ['required', 'string'],
            "parameters.*.default_value"         => ['nullable', 'string'],
            "parameters.*.value"                 => ['nullable'],
            "parameters.*.link_source"           => ['nullable'],
            "parameters.*.type"                  => ['required', 'string'],
            "parameters.*.guidance"              => ['nullable', 'string'],
            "parameters.*.is_mandatory"          => ['nullable', 'boolean'],
            "parameters.*.identity"              => ['nullable', 'boolean'],
            "parameters"                         => ['nullable', 'array'],
            "elements"                           => ['nullable', 'array'],
            "parameters.*.enum"                  => ['nullable'],
            "parameters.*.print_conf_enum_id"    => ['nullable', 'string'],
            "parameters.*.print_conf_element_id" => ['required', 'string'],
        ];
    }

    public function authorize(): bool
    {
        return true;
    }

}
