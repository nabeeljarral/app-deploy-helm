<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class RegistrationRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            //'invite_id'              => ['required', 'exists:invited_organizations,id'],
            'user.name'              => ['required', 'string'],
            'user.email'             => ['required', 'email', Rule::unique('users', 'email')],
            'user.password'          => ['min:8', 'confirmed'],
            //'user.password_confirmation' => [],
            'organization.name'      => ['required', 'string'],
            'organization.city'      => ['nullable', 'string'],
            'organization.country' => ['required', 'string'],
        ];
    }

    public function authorize(): bool
    {
        return true;
    }

    public function messages()
    {
        return [
            'user.email' => 'The email has already been taken.',
            //'invite_id'  => 'Something went wrong try again later',
        ];
    }
}
