<?php

namespace App\Http\Requests;

use App\Models\Environment;
use App\Services\Dashboard\DTO\CreateReportDto;
use App\Services\Dashboard\Enums\DashboardType;
use http\Env;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Validator;

/**
 *
 */
class CreateReportRequest extends FormRequest
{
    /**
     * @return array[]
     */
    public function rules(): array
    {
        return [
            'workspace_id' => ['required', 'int'],
            'template_id'  => ['required', 'int'],
            'type'         => ['required', 'string', Rule::in(DashboardType::AVAILABLE)],
            'name'         => ['required', 'string'],
            'country'      => ['required', 'string'],
            'city'         => ['required', 'string'],
            'owner_name'   => ['nullable', 'string'],
            'owner_email'  => ['nullable', 'string'],
        ];
    }

    /**
     * @return string[]
     */
    public function messages(): array
    {
        return [
            'template_id' => 'The template field is required.',
        ];
    }

    /**
     * @param Validator $validator
     * @return void
     */
    public function withValidator(Validator $validator): void
    {
        $validator->after(function (Validator $validator) {
            if (!$this->get('workspace_id')) {
                return;
            }

            $workspace = Environment::findOrFail($this->get('workspace_id'));

            if (!$this->user()->can('viewEnvironment', $workspace)) {
                $validator->errors()->add('workspace_id', 'You cannot create a report for this workspace.');
            }


            $reportExists = $workspace->dashboards()
                ->where('name', $this->get("name"))
                ->exists();

            if ($reportExists) {
                $validator->errors()->add('name', 'The name has already been taken.');
            }
        });
    }

    /**
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return CreateReportDto
     */
    public function getDto(): CreateReportDto
    {
        $dto = CreateReportDto::of($this->validated());
        $dto->user = $this->user();
        return $dto;
    }
}
