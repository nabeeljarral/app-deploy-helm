<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;

class PrintConfTemplateRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            "template_name"                                 => ['required', 'string'],
            "template_id"                                   => ['nullable', 'string'],
            "report_id"                                     => ['nullable', 'string'],
            "elements"                                      => ['required', 'array'],
            "elements.*.id"                                 => ['required', 'string'],
            "elements.*.name"                               => ['required', 'string'],
            "elements.*.title"                              => ['required', 'string'],
            "elements.*.is_parent"                          => ['nullable', 'boolean'],
            "elements.*.is_mandatory"                       => ['nullable', 'boolean'],
            "elements.*.is_single"                          => ['nullable', 'boolean'],
            "elements.*.is_default"                         => ['nullable', 'boolean'],
            "elements.*.is_embeddable"                      => ['nullable', 'boolean'],
            "elements.*.order_number"                       => ['nullable', 'integer'],
            "elements.*.embeds"                             => ['nullable', 'array'],
            "elements.*.default_embeds"                     => ['nullable', 'array'],
            "elements.*.print_conf_template_id"             => ['required', 'string'],
            "elements.*.parameters.*.id"                    => ['required', 'string'],
            "elements.*.parameters.*.name"                  => ['required', 'string'],
            "elements.*.parameters.*.title"                 => ['required', 'string'],
            "elements.*.parameters.*.default_value"         => ['nullable', 'string'],
            "elements.*.parameters.*.value"                 => ['nullable'],
            "elements.*.parameters.*.type"                  => ['required', 'string'],
            "elements.*.parameters.*.guidance"              => ['nullable', 'string'],
            "elements.*.parameters.*.is_mandatory"          => ['nullable', 'boolean'],
            "elements.*.parameters.*.identity"              => ['nullable', 'boolean'],
            "elements.*.parameters"                         => ['nullable', 'array'],
            "elements.*.elements"                           => ['nullable', 'array'],
            "elements.*.parameters.*.enum"                  => ['nullable'],
            "elements.*.parameters.*.print_conf_enum_id"    => ['nullable', 'string'],
            "elements.*.parameters.*.print_conf_element_id" => ['required', 'string'],
        ];
    }

    public function authorize(): bool
    {
        return true;
    }

    public function messages()
    {
        return [
            'template_name.required' => 'The Printing Configuration Name field is required.',
            'elements.required'      => 'Please drag at least one item into the settings area.',
        ];
    }
}
