<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreatePrintConfTemplateRequest;
use App\Http\Requests\PrintConfElementRequest;
use App\Http\Requests\PrintConfTemplateRequest;
use App\Models\Dashboard\Dashboard;
use App\Models\PrintConfTemplate;
use App\Models\Template\Template;
use App\Presenters\PrintConfiguration\PrintConfigurationsItemsPresenter;
use App\Services\PrintConfiguration\Templates\CustomPrintConfiguration;
use App\Transformers\PrintConfiguration\PrintConfElementTransformer;
use App\Transformers\PrintConfiguration\PrintConfTemplateTransformer;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Response;
use Illuminate\Validation\Rule;
use Spatie\Fractalistic\ArraySerializer;

class PrintConfTemplateController extends Controller
{
    public function getElements(): \Illuminate\Http\JsonResponse
    {
        try {
            $elements = PrintConfTemplate::getAvailableElements();

            return fractal($elements)
                ->transformWith(new PrintConfElementTransformer())
                ->parseExcludes('elements')
                ->serializeWith(ArraySerializer::class)
                ->respond();

        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    public function getTemplate(PrintConfTemplate $printConfTemplate): \Illuminate\Http\JsonResponse
    {
        try {
            $this->authorize('view', $printConfTemplate);

            return $this->fractalResponse($printConfTemplate);

        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    public function createCustomTemplate(
        CreatePrintConfTemplateRequest $request,
        CustomPrintConfiguration $printConfiguration
    ): \Illuminate\Http\JsonResponse
    {
        try {
            $data = $request->validated();
            $data['organization_id'] = Auth::user()->organization_id;

            if (isset($data['template_id'])) {
                $template = Template::findOrFail($data['template_id']);
            }
            if (isset($data['report_id'])) {
                $report = Dashboard::findOrFail($data['report_id']);
                $template = $report->globalTemplate;
                $data["organization_id"] = $report->environment->organization_id;
            }

            $printConfTemplate = $printConfiguration->saveCustomTemplate($template, $data);

            return $this->fractalResponse($printConfTemplate);

        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    public function updateCustomTemplate(
        PrintConfTemplate $printConfTemplate,
        PrintConfTemplateRequest $request,
        CustomPrintConfiguration $printConfiguration
    ): \Illuminate\Http\JsonResponse
    {
        try {
            $this->authorize('update', $printConfTemplate);
            $data = $request->validated();

            if ($printConfTemplate->report_id) {
                $data["organization_id"] = Dashboard::findOrFail($printConfTemplate->report_id)->environment->organization_id;
            }

            $printConfTemplate = $printConfiguration->updatePrintConfTemplate($printConfTemplate, $request->validated());
            return $this->fractalResponse($printConfTemplate);

        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    public function deleteTemplate(
        PrintConfTemplate $printConfTemplate,
        CustomPrintConfiguration $printConfiguration
    ): \Illuminate\Http\JsonResponse
    {
        try {
            $this->authorize('delete', $printConfTemplate);

            $printConfiguration->deleteTemplate($printConfTemplate);

            return Response::json(['status' => true]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    public function cloneCustomTemplate(
        PrintConfTemplate $printConfTemplate,
        CustomPrintConfiguration $printConfiguration
    )
    {
        try {
            $printConfTemplate = fractal($printConfTemplate)
                ->transformWith(new PrintConfTemplateTransformer())
                ->parseIncludes('elements')
                ->serializeWith(ArraySerializer::class)
                ->toArray();

            $printConfTemplate['organization_id'] = Auth::user()->organization_id;

            $clonedPrintConfTemplate = $printConfiguration->clonePrintConfTemplate($printConfTemplate);

            return $this->fractalResponse($clonedPrintConfTemplate);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    public function cloneToTemplateCustomTemplate(
        PrintConfTemplate $printConfTemplate,
        CustomPrintConfiguration $printConfiguration
    )
    {
        try {
            $printConfTemplate = fractal($printConfTemplate)
                ->transformWith(new PrintConfTemplateTransformer())
                ->parseIncludes('elements')
                ->serializeWith(ArraySerializer::class)
                ->toArray();

            $printConfTemplate['organization_id'] = Auth::user()->organization_id;
            unset($printConfTemplate['report_id']);
            unset($printConfTemplate['print_conf_template_id']);

            $clonedPrintConfTemplate = $printConfiguration->clonePrintConfTemplate($printConfTemplate, false);

            return $this->fractalResponse($clonedPrintConfTemplate);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }


    private function fractalResponse($printConfTemplate)
    {
        return fractal($printConfTemplate)
            ->transformWith(new PrintConfTemplateTransformer())
            ->parseIncludes('elements')
            ->serializeWith(ArraySerializer::class)
            ->respond();
    }

    public function updateElement(CustomPrintConfiguration $printConfiguration, PrintConfElementRequest $request): \Illuminate\Http\JsonResponse
    {
        try {
            $elementData = $request->validated();
            $element = $printConfiguration->updateElement($elementData);

            return Response::json(['status' => true, 'element' => $element]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function getPrintConfItems(Request $request) {
        try {
            $request->validate([
                'entity' => ['required', 'string', Rule::in('template', 'report')],
                'entity_id' => 'required|integer'
            ]);

            $response = (new PrintConfigurationsItemsPresenter($request->get('entity'), $request->get('entity_id')))->present();

            return Response::json($response);
        }catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    public function checkTemplateName(
        CreatePrintConfTemplateRequest $request,
        CustomPrintConfiguration $printConfiguration
    ){
        $templateData = $request->validated();
        $status = false;
        if(array_key_exists('report_id', $templateData) && isset($templateData['report_id'])){
            $status = $printConfiguration->checkNameInReport($templateData['report_id'], $templateData['template_name']);
        } else if(array_key_exists('template_id', $templateData) && isset($templateData['template_name'])){
            $status = PrintConfTemplate::where("template_id", $templateData['template_id'])
                ->where("organization_id", $request->user()->organization_id)
                ->where("report_id", null)
                ->get()
                ->contains('template_name', $templateData['template_name']);
        }

        return Response::json(['status' => $status]);
    }
}
