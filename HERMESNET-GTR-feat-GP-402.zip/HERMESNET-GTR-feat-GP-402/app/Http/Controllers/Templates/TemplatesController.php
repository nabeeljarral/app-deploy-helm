<?php

namespace App\Http\Controllers\Templates;

use App\Http\Controllers\Controller;
use App\Models\Environment;
use App\Models\Template\Template;
use App\Models\Template\TemplateItem;
use App\Presenters\Template\WorkspaceDcTemplatesPresenter;
use App\Transformers\Templates\TemplateComplianceLevelTransformer;
use App\Transformers\Templates\TemplateItemTransformer;
use App\Transformers\Templates\TemplateTransformer;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Spatie\Fractalistic\ArraySerializer;

/**
 *
 */
class TemplatesController extends Controller
{
    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function getAvailableTemplates(Request $request): JsonResponse
    {
        try {
            $query = Template::query()
                ->where('is_archived', false)
                ->organizationTemplates($request->user()->organization);

            if ($request->get("category")) {
                $query->where("category", $request->get("category"));
            }

            if ($request->get("type")) {
                $query->where("type", $request->get("type"));
            }

            return fractal($query->get())
                ->transformWith(new TemplateTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param Request $request
     * @return JsonResponse
     */
    public function getTemplateDetails(Template $template, Request $request)
    {
        try {
            $transformer = new TemplateTransformer();

            if ($request->boolean("withSheets")) {
                $transformer->setWithSheets(true);
            }

            $includes = explode(',', $request->get("includes", ''));
            if (empty($includes)) {
                $includes = [];
            }

            return fractal($template)
                ->transformWith($transformer)
                ->parseIncludes($includes)
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Environment $workspace
     * @param Request $request
     * @return JsonResponse
     * Get all templates that are available for a workspace
     */
    public function getWorkspaceTemplates(Environment $workspace, Request $request)
    {
        try {
            $templates = (new WorkspaceDcTemplatesPresenter($workspace, $request->get("category")))
                ->present();

            return fractal($templates)
                ->transformWith(new TemplateTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }


    /**
     * @param Template $template
     * @param Request $request
     * @return JsonResponse
     */
    public function getAvailableComplianceLevels(Template $template, Request $request): JsonResponse
    {
        try {
            $complianceLevels = $template->complianceLevels()->where('is_published', '=', true)->get();

            return fractal($complianceLevels)
                ->transformWith(new TemplateComplianceLevelTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }


    public function getItemDetails(TemplateItem $item)
    {
        try {
            $transformer = new TemplateItemTransformer();
            $transformer->setWithItemPath(true);

            return fractal($item)
                ->transformWith($transformer)
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }
}
