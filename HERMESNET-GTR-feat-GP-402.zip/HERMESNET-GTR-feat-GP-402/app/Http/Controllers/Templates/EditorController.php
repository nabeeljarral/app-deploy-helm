<?php

namespace App\Http\Controllers\Templates;

use App\Http\Controllers\Controller;
use App\Utils\LoggerUtil;
use App\Utils\UrlUtil;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;

/**
 *
 */
class EditorController extends Controller
{
    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function uploadImage(Request $request): JsonResponse
    {
        $result = [];
        try {
            for ($i = 0; $request->hasFile('file-' . $i); $i++) {
                $file = $request->file('file-' . $i);
                $path = $file->storePublicly('public/editor/images');
                $path = preg_replace('/^public/', 'storage', $path);

                if (!$path) {
                    throw new \RuntimeException("Failed to upload file");
                }

                $result[$i] = [
                    "url"  => UrlUtil::of(config('app.url'))->join($path)->getValue(),
                    "name" => $file->getBasename(),
                    "size" => $file->getSize()
                ];
            }

            return Response::json(["result" => $result]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return Response::json([
                "errorMessage" => $exception->getMessage(),
                "result"       => $result
            ]);
        }
    }
}
