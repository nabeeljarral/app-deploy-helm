<?php

namespace App\Http\Controllers\Auth;

use App\Actions\Organization\SaveOrganizationAction;
use App\Http\Controllers\Controller;
use App\Http\Requests\RegistrationRequest;
use App\Models\InvitedOrganization;
use App\Models\User;
use App\Services\User\Enums\UserRole;
use App\Transformers\UserTransformer;
use App\Utils\AvatarUtil;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/**
 *
 */
class AuthController extends Controller
{
    use AuthenticatesUsers;

    public function getInvitedOrganization(Request $request)
    {
        try {
            $request->validate(['state' => 'required|string']);
            $email = \Crypt::decrypt($request->get('state'));
            $invitedOrganization = InvitedOrganization::where('email', $email)->firstOrFail();
            return response()->json($invitedOrganization->toArray());
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param RegistrationRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function register(RegistrationRequest $request)
    {
        $userAttributes = $request->get("user");
        $userAttributes['role'] = UserRole::ENVIRONMENT_OWNER;
        $userAttributes['password'] = Hash::make($userAttributes['password']);
        $userAttributes['color'] = AvatarUtil::randomColorHex();

        $user = User::create($userAttributes);

        $organizationAttributes = $request->get("organization");
        $organizationAttributes['user_id'] = $user->id;

        (new SaveOrganizationAction($organizationAttributes))->run();

        if (Auth::attempt(Arr::only($request->get("user"), ['email', 'password']))) {
            $userModel = Auth::user();
            $data = $userModel->toArray();
            $token = $userModel->createToken('MyApp')->plainTextToken;

            // InvitedOrganization::where('id', $request->get('invite_id'))->delete();

            return response()
                ->json($data, 200)
                ->header("access-token", $token);
        }

        return ResponseUtil::error();
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function login(Request $request)
    {
        $request->validate([
            'email'    => ['required'],
            'password' => ['required']
        ]);

        if (Auth::attempt($request->only('email', 'password'))) {
            $userModel = Auth::user();
            $token = $userModel->createToken(name: 'MyApp', abilities: $userModel->getAdminAbilities())->plainTextToken;
            $userModel->last_activity_at = now();
            $userModel->saveQuietly();

            return fractal($userModel)
                ->transformWith(new UserTransformer())
                ->respond()
                ->header("access-token", $token);
        }

        throw ValidationException::withMessages([
            'email' => ['The provided credentials are incorrect.']
        ]);
    }

    /**
     * @return void
     */
    public function logout()
    {
        Auth::logout();
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function sendResetLink(Request $request)
    {
        $request->validate(['email' => "required|email"]);

        try {
            $status = Password::sendResetLink(
                $request->only("email"),
            );

            return $status === Password::RESET_LINK_SENT
                ? response()->json(['status' => __($status)])
                : response()->json(['message' => __($status)], 400);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param string $token
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function resetPasswordCallback(string $token, Request $request)
    {
        $email = $request->get("email");
        if ($email && $token) {
            return redirect()->to('/auth/reset-password?token=' . $token . "&email=" . $request->get("email"), 301);
        } else {
            return redirect()->to('/404', 301);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function resetPassword(Request $request)
    {
        $request->validate([
            'token'    => 'required',
            'email'    => 'required|email',
            'password' => 'required|min:8|confirmed',
        ]);

        try {
            $status = Password::reset(
                $request->only('email', 'password', 'password_confirmation', 'token'),
                function ($user, $password) {
                    $user->forceFill([
                        'password' => Hash::make($password)
                    ])->setRememberToken(Str::random(60));

                    $user->save();

                    event(new PasswordReset($user));
                }
            );

            return $status === Password::PASSWORD_RESET
                ? response()->json(['status' => __($status)])
                : response()->json(['message' => __($status)], 400);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }
}
