<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\GoogleAuthCallbackRequest;
use App\Models\User;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Laravel\Socialite\Facades\Socialite;

/**
 *
 */
class GoogleAuthController extends Controller
{

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function redirectToGoogle(Request $request)
    {
        $with = [
            "prompt" => "select_account" //+consent
        ];
        if (Auth::check()) {
            $with['state'] = Auth::id();

        }

        $redirectUrl = Socialite::driver('google')
            ->with($with)
            ->stateless()
            ->redirect()
            ->getTargetUrl();

        return response()->json([
            'success' => true,
            'url'     => $redirectUrl
        ]);
    }

    /**
     * @param GoogleAuthCallbackRequest $request
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|void
     */
    public function callback(GoogleAuthCallbackRequest $request)
    {
        try {
            LoggerUtil::info("Google Auth Callback", $request->all());
            /**
             * @var $user \Laravel\Socialite\Two\User
             */
            $socialiteUser = Socialite::driver('google')
                ->stateless()
                ->user();

            $user = User::where("id", $request->get("state"))->first();

            if (!$user) {
                Auth::logout();
                return view('callback', [
                    'authStatus' => false,
                    'message'    => "Invalid state!"
                ]);
            }

            if (!is_null($user->google_email) && $user->google_email != $socialiteUser->email) {
                Auth::logout();
                return view('callback', [
                    'authStatus' => false,
                    'message'    => "Invalid google account!"
                ]);
            }

            if (is_null($user->google_email)) {
                $user->social_id = $socialiteUser->id;
                $user->social_type = "google";
                $user->google_email = $socialiteUser->email;
                $user->save();
            }

            \Session::put("google_login", true);
            $response = [
                'authStatus' => true,
                'message'    => "Success",
                "token"      => $user->createToken('MyApp')->plainTextToken,
                'google_auth_user_number' => $request->get('authuser', 0),
            ];
            $response = array_merge($response, $user->toArray());
            return view('callback', $response);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
        }
    }
}
