<?php

namespace App\Http\Controllers\Organization;

use App\Actions\Organization\CreateOrganizationFolder;
use App\Actions\Organization\GetOrganizationDataAction;
use App\Actions\Organization\SaveOrganizationAction;
use App\Http\Controllers\Controller;
use App\Http\Requests\UpdateOrganizationDetailsRequest;
use App\Models\Organization;
use App\Models\User;
use App\Presenters\OrganizationUsersPresenter;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/**
 *
 */
class OrganizationController extends Controller
{

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function getCurrentOrganization(Request $request): JsonResponse
    {
        try {
            $user = $request->user();
            return response()->json([
                'success' => true,
                'data'    => $user->organization->toArray()
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Request $request
     * @return JsonResponse|void
     */
    public function createOrganizationFolder(Request $request)
    {
        try {
            /**
             * @var $user User
             */
            $user = $request->user();

            /**
             * @var $organization Organization
             */
            $organization = $request->user()->organization;


            if (!$organization->drive_folder_id) {
                $organization->drive_folder_id = (new CreateOrganizationFolder($user))->run();
                $organization->save();
            }
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    //

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function saveSettings(UpdateOrganizationDetailsRequest $request): JsonResponse
    {
        $inputData = $request->validated();
        $inputData['user_id'] = Auth::id();

        $saveResult = (new SaveOrganizationAction($inputData))->run();

        if (!$saveResult) {
            return response()->json([
                'success' => false,
                'message' => 'Error while update organization settings'
            ]);
        }

        return response()->json([
            'success' => true,
            'message' => 'Organization Data Updated'
        ]);
    }

    /**
     * @param int $organization_id
     * @param Request $request
     * @return JsonResponse
     */
    public function getUsers(int $organization_id, Request $request)
    {
        try {
            $users = (new OrganizationUsersPresenter($request->user()))->present();
            return response()->json($users->toArray());
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }
}
