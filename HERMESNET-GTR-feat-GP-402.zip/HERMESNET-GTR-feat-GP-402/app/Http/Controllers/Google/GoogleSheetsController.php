<?php

namespace App\Http\Controllers\Google;

use App\Http\Controllers\Controller;
use App\Services\Google\getFieldValue;
use App\Services\Google\ValidateSheetRange;
use App\Utils\LoggerUtil;
use Illuminate\Http\Request;

/**
 *
 */
class GoogleSheetsController extends Controller
{
    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function validateSheetRange(Request $request)
    {
        try {
            $request->validate([
                'file_id' => ['required', 'string'],
                'range'   => ['required', 'string']
            ]);

            $action = new ValidateSheetRange(
                $request->get('file_id'),
                $request->get('range')
            );

            return \Response::json([
                'status'  => $action->run(),
                'message' => $action->getMessage()
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return \Response::json([
                'status'  => false,
                'message' => "Something went wrong. Please try again later."
            ]);
        }
    }

    public function getFieldValue(Request $request)
    {
        try {
            $request->validate([
                'file_id' => ['required', 'string'],
                'range'   => ['required', 'string']
            ]);

            $action = new getFieldValue(
                $request->get('file_id'),
                $request->get('range')
            );

            return \Response::json([
                'text'  => $action->run(),
                'message' => $action->getMessage()
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return \Response::json([
                'status'  => false,
                'message' => "Something went wrong. Please try again later."
            ]);
        }
    }
}
