<?php

namespace App\Http\Controllers\Google;

use App\Http\Controllers\Controller;
use App\Services\Google\GoogleAccessToken;
use App\Utils\GoogleUtil;
use App\Utils\LoggerUtil;
use Illuminate\Http\Request;

/**
 *
 */
class GoogleOAuthController extends Controller
{
    /**
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector|void
     */
    public function oauth()
    {
        try {
            $auth_url = GoogleUtil::authClient(true)->createAuthUrl();
            return redirect($auth_url);
        }
        catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            abort(500);
        }
    }

    /**
     * @param Request $request
     * @return void
     */
    public function callback(Request $request)
    {
        try {
            if ($request->has("code")) {
                $access_token = GoogleUtil::authClient()->fetchAccessTokenWithAuthCode($request->code);
                GoogleAccessToken::save($access_token);
                echo "<h1>Success</h1>";
            } else {
                abort(403);
            }
        }
        catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            abort(500);
        }
    }
}
