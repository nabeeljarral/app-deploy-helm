<?php

namespace App\Http\Controllers\Configuration;

use App\Http\Controllers\Controller;
use App\Http\Requests\SaveConfigurationRequest;
use App\Http\Requests\UpdateReportItemRequest;
use App\Models\ConfigurationItem;
use App\Models\Template\Template;
use App\Models\Template\TemplateConfiguration;
use App\Presenters\Configuration\ConfigurationItemsNestedListPresenter;
use App\Services\Configuration\SelectAllConfigurationItems;
use App\Transformers\Configuration\ConfigurationTransformer;
use App\Transformers\Configuration\Item\ItemTransformer;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Spatie\Fractalistic\ArraySerializer;

/**
 *
 */
class ConfigurationController extends Controller
{

    /**
     * @param TemplateConfiguration $configuration
     * @return JsonResponse
     */
    public function getConfiguration(TemplateConfiguration $configuration): JsonResponse
    {
        try {
            return fractal($configuration)
                ->transformWith(new ConfigurationTransformer())
                ->parseIncludes("template")
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @return JsonResponse
     */
    public function getTemplateConfigurations(Template $template): JsonResponse
    {
        try {
            $configurations = TemplateConfiguration::query()
                ->where('template_id', $template->id)
                ->where('is_published', true)
                ->where(function ($query) {
                    $query->where("organization_id", auth()->user()->organization_id)
                        ->orWhere("organization_id", null);
                })
                ->orderBy("organization_id", "desc")
                ->get();

            return fractal($configurations)
                ->transformWith(new ConfigurationTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param ConfigurationItem $item
     * @return JsonResponse
     */
    public function getItemDetails(ConfigurationItem $item): JsonResponse
    {
        try {
            return fractal($item)
                ->transformWith(new ItemTransformer())
                ->serializeWith(ArraySerializer::class)
                ->parseIncludes("templateItem")
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param int $entityId - TemplateConfiguration or Template id
     * @param Request $request
     * @return JsonResponse
     */
    public function getItemsNestedList(int $entityId, Request $request): JsonResponse
    {
        try {
            /**
             * @var string $entity - configuration or template if report created without configuration or is general configuration use entity=template
             */
            $entity = $request->get('entity', 'configuration');

            if ($entity === 'configuration') {
                $configuration = TemplateConfiguration::find($entityId);
            } else {
                $configuration = Template::findOrFail($entityId);
            }

            $presenter = new ConfigurationItemsNestedListPresenter($configuration);
            return \Response::json($presenter->present());
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    public function updateConfiguration(TemplateConfiguration $configuration, SaveConfigurationRequest $request): JsonResponse
    {
        try {
            $configuration->update($request->validated());
            return $this->getConfiguration($configuration);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param TemplateConfiguration $configuration
     * @param Request $request
     * @return JsonResponse
     */
    public function selectAllItems(TemplateConfiguration $configuration, Request $request): JsonResponse
    {
        try {
            (new SelectAllConfigurationItems(
                entry: $configuration,
                is_included: $request->boolean('is_included'))
            )->run();

            $presenter = new ConfigurationItemsNestedListPresenter($configuration);
            return \Response::json($presenter->present());
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param TemplateConfiguration $configuration
     * @param Request $request
     * @return JsonResponse
     */
    public function updateItemsIncluded(TemplateConfiguration $configuration, Request $request): JsonResponse
    {
        try {
            \Request::validate([
                'ids'         => ['required', 'array'],
                'ids.*'       => ['required', 'int'],
                'is_included' => ['required', 'boolean'],
            ]);

            $configuration->items()
                ->whereIn('id', $request->get('ids'))
                ->update(['is_included' => $request->boolean('is_included')]);

            $presenter = new ConfigurationItemsNestedListPresenter($configuration);
            return \Response::json($presenter->present());
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param ConfigurationItem $item
     * @param UpdateReportItemRequest $request
     * @return JsonResponse
     */
    public function updateItem(ConfigurationItem $item, UpdateReportItemRequest $request): JsonResponse
    {
        try {
            $item->update($request->validated());
            return $this->getItemDetails($item);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }
}
