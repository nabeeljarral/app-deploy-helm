<?php

namespace App\Http\Controllers;

use App\Http\Requests\InviteUserRequest;
use App\Models\InvitedUser;
use App\Models\User;
use App\Services\User\CompleteRegistration;
use App\Services\User\Enums\InvitedUserStatus;
use App\Services\User\Invite\InviteUserProcedure;
use App\Utils\AvatarUtil;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;

class InviteUserController extends Controller
{
    /**
     * @param InviteUserRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function sendInviteUser(InviteUserRequest $request)
    {
        try {
            (new InviteUserProcedure($request->getDto(), $request->user()))->run();
            return response()->json([
                'success' => true,
                'data'    => [],
            ]);
        }
        catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param string $state
     * @return \Illuminate\Http\JsonResponse
     */
    public function getInvitedUser(string $state)
    {
        try {
            $email = Crypt::decrypt($state);
            $invitedUser = InvitedUser::where('email', $email)
                ->where("status", InvitedUserStatus::ACTIVE)
                ->firstOrFail();

            return response()->json($invitedUser->toArray());
        }
        catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }


    /**
     * @param int $id - invited user id
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function registerInviteUser(int $id, Request $request)
    {
        try {
            $request->validate([
                'name'     => ['required'],
                'email'    => ['required', 'email', 'unique:users'],
                'password' => ['required', 'min:8', 'confirmed']
            ]);

            $invitedUser = InvitedUser::where('id', $id)
                ->where("status", InvitedUserStatus::ACTIVE)
                ->firstOrFail();

            $invitedFrom = User::where('id', $invitedUser->invited_from)->firstOrFail();

            User::create([
                'name'            => $request->name,
                'email'           => $request->email,
                'password'        => Hash::make($request->password),
                'role'            => $invitedUser->role,
                'invited_from'    => $invitedFrom->id,
                'organization_id' => $invitedFrom->organization_id,
                'color'           => $invitedUser->color ?? AvatarUtil::randomColorHex(),
            ]);

            if (Auth::attempt($request->only('email', 'password'))) {
                $userModel = Auth::user();
                $data = $userModel->toArray();
                $token = $userModel->createToken('MyApp')->plainTextToken;

                $completeRegistration = new CompleteRegistration(
                    $invitedUser,
                    $request->user()
                );
                $completeRegistration->run();

                return response()
                    ->json($data, 200)
                    ->header("access-token", $token);
            }
            return ResponseUtil::error();
        }
        catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param int $id
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function completeRegistrationInvitedUser(int $id, Request $request)
    {
        try {
            $invitedUser = InvitedUser::where('id', $id)->firstOrFail();

            $completeRegistration = new CompleteRegistration(
                $invitedUser,
                $request->user()
            );
            $completeRegistration->run();

            return response()->json([]);
        }
        catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }
}
