<?php

namespace App\Http\Controllers;

use App\Admin\Mail\SubscriptionRequestMail;
use App\Admin\Services\SendAdminsEmail;
use App\Mail\PaymentDetailMail;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

/**
 *
 */
class SubscriptionController extends Controller
{
    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function subscriptionRequest(Request $request)
    {
        try {
            $user = $request->user();
            $userMail = new PaymentDetailMail($request->user());
            Mail::to($user->email)->queue($userMail);


            $adminMail = new SubscriptionRequestMail($user);
            (new SendAdminsEmail($adminMail))->run();

            return response()->json([
                'status' => true,
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }
}
