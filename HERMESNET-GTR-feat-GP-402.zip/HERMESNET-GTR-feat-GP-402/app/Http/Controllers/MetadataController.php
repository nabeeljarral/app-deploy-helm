<?php

namespace App\Http\Controllers;

use App\Models\City;
use Illuminate\Http\JsonResponse;

/**
 *
 */
class MetadataController extends Controller
{
    /**
     * @return JsonResponse
     */
    public function countries(): JsonResponse
    {
        $response = City::query()
            ->select('city', 'country')
            ->orderBy('country')
            ->orderBy('city')
            ->get()
            ->groupBy('country')
            ->toArray();

        return response()->json($response);
    }
}
