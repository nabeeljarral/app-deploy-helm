<?php

namespace App\Http\Controllers;

use App\Models\Dashboard\Dashboard;
use App\Models\Template\TemplateAnalytics;
use App\Services\Looker\EmbeddingAttributes;
use App\Services\Looker\EmbedSession\LookerEmbedSession;
use App\Services\Looker\EmbedSession\LookerEmbedSessionDto;
use App\Services\Looker\ManuallySignedUrl;
use Illuminate\Http\Request;

/**
 *
 */
class LookerAnalyticsController extends Controller
{
    /**
     * @param TemplateAnalytics $templateAnalytics
     * @return \Illuminate\Http\JsonResponse
     */
    public function getDashboardConfig(TemplateAnalytics $templateAnalytics)
    {
        $urlParts = parse_url($templateAnalytics->looker_embedding_url);
        $path = explode('/', $urlParts['path']);
        $dashboardId = $path[count($path) - 1];

        return response()
            ->json([
                'analytics_id'         => $templateAnalytics->id,
                'dashboard_id'         => $dashboardId,
                'looker_embedding_url' => $templateAnalytics->looker_embedding_url,
                'user_id'              => \Auth::id(),
            ]);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function acquireEmbedSession(Request $request)
    {
        $request->validate([
            'user_id'      => 'required',
            'analytics_id' => 'required',
            'report_id'    => 'nullable',
        ]);

        $sessionDto = LookerEmbedSessionDto::of([
            'userId'      => $request->input('user_id'),
            'analyticsId' => $request->input('analytics_id'),
            'reportId'    => $request->input('report_id'),
            'userAgent'   => $request->header('User-Agent'),
        ]);

        $lookerSession = new LookerEmbedSession($sessionDto);

        return response()->json($lookerSession->acquireEmbedSession());
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     * @throws \Swagger\Client\ApiException
     */
    public function generateEmbedTokens(Request $request)
    {
        $request->validate([
            'api_token'        => 'required',
            'navigation_token' => 'required',
            'user_id'          => 'required',
            'analytics_id'     => 'required',
            'report_id'        => 'nullable',
        ]);

        $sessionDto = LookerEmbedSessionDto::of([
            'userId'      => $request->input('user_id'),
            'analyticsId' => $request->input('analytics_id'),
            'reportId'    => $request->input('report_id'),
            'userAgent'   => $request->header('User-Agent'),
        ]);

        $lookerSession = new LookerEmbedSession($sessionDto);

        return response() -> json($lookerSession->generateEmbedTokens($request->api_token, $request->navigation_token));
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     * @throws \Exception
     */
    public function getManuallySignedUrl(Request $request)
    {
        $request->validate([
            'analytics_id' => 'required',
            'report_id'    => 'nullable',
        ]);

        $analytics = TemplateAnalytics::findOrFail($request->analytics_id);
        $report = null;

        if ($request->input('report_id')) {
            $report = Dashboard::findOrFail($request->report_id);
        }

        $attributes = new EmbeddingAttributes($report, \Auth::user());

        $url = (new ManuallySignedUrl($analytics, $attributes))->run();
        return response()->json(['url' => $url]);
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     */
    public function getConfigTemplate()
    {
        return response()->json(config('project.looker.embedded.config_template'));
    }
}
