<?php

namespace App\Http\Controllers;

use App\Services\PrintConfiguration\ImagesHandler;
use App\Utils\LoggerUtil;
use Illuminate\Http\Request;

class PrintConfImageUploadController extends Controller
{

    public function uploadImage(Request $request, ImagesHandler $imagesHandler): \Illuminate\Http\JsonResponse
    {
        try {
            $request->validate([
                'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:10000',
            ]);

            $image = $request->file('image');
            $imageUrl = $imagesHandler->saveImage($image);

            return response()->json(['url' => $imageUrl]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return response()->json(['message' => $exception->getMessage()], 500);
        }

    }

    public function deleteImage(Request $request, ImagesHandler $imagesHandler): \Illuminate\Http\JsonResponse
    {
        $imageUrl = $request->input('image_url');

        return $imagesHandler->deleteImage($imageUrl);
    }

    public function showImage($filename, ImagesHandler $imagesHandler): \Illuminate\Http\Response|\Illuminate\Http\JsonResponse
    {
        return $imagesHandler->getImage($filename);
    }
}
