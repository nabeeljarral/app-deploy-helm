<?php

namespace App\Http\Controllers;

use App\Abstractions\Queue\DispatchAction;
use App\Exceptions\PolicyException;
use App\Http\Requests\CreateEnvironmentRequest;
use App\Http\Requests\UpdateEnvironmentRequest;
use App\Models\Environment;
use App\Models\Template\Template;
use App\Presenters\EnvironmentDashboardsPresenter;
use App\Presenters\EnvironmentsPresenter;
use App\Services\Dashboard\Enums\DashboardType;
use App\Services\Dashboard\SyncDashboardRelation;
use App\Services\Environment\CreateEnvironment;
use App\Services\Environment\DeleteEnvironment;
use App\Services\Environment\SetEnvironmentDshTimestamps;
use App\Services\User\UserPermissions\CheckUserHasAccess;
use App\Transformers\DashboardTransformer;
use App\Transformers\EnvironmentTransformer;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Spatie\Fractalistic\ArraySerializer;

/**
 *
 */
class EnvironmentController extends Controller
{

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function getUserEnvironment(Request $request)
    {
        $presenter = new EnvironmentsPresenter($request->user());
        return $presenter->respond($request);
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function getAvailableEnvironments(Request $request)
    {
        try {
            $user = $request->user();

            if ($user->isOrganizationOwner()) {
                $environments = Environment::where('organization_id', $user->organization_id)->get();
            } else {
                $presenter = new EnvironmentsPresenter($request->user());
                $presenter->setIgnoreMaxRole(true);
                $environments = $presenter->present();
            }

            $transformer = new EnvironmentTransformer();
            $transformer->setIncludeCurrentRole(true);
            $transformer->setIncludeUsersCount(true);

            return fractal($environments)
                ->transformWith($transformer)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param int $id
     * @param Request $request
     * @return JsonResponse
     */
    public function getById(int $id, Request $request)
    {
        try {
            $user = $request->user();

            $isHasAccess = (new CheckUserHasAccess($user, $id))->check();
            if (!$isHasAccess) {
                return response()->json(['status' => false, 'message' => 'access is denied'], 403);
            }

            $environment = Environment::where('id', $id)->firstOrFail();

            if (!$request->user()->can('viewEnvironment', $environment)) {
                throw new PolicyException('not allowed to view this environment');
            }

            $transformer = new EnvironmentTransformer();
            $transformer->setIncludeCurrentRole(true);

            $response = fractal($environment)
                ->transformWith($transformer);

            if ($request->boolean('withDashboards')) {
                $dashboards = (new EnvironmentDashboardsPresenter($user, $environment->id))->present();

                DispatchAction::of(new SetEnvironmentDshTimestamps($environment));

                $environment->dashboards = $dashboards;
                $response->includeDashboards();
            }

            return $response->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param CreateEnvironmentRequest $request
     * @return JsonResponse
     */
    public function createEnvironment(CreateEnvironmentRequest $request)
    {
        try {
            $action = new CreateEnvironment($request);
            $environment = $action->run();

            return fractal($environment)
                ->transformWith(new EnvironmentTransformer())
                ->parseIncludes("dashboards")
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Environment $environment
     * @param UpdateEnvironmentRequest $request
     * @return JsonResponse
     */
    public function updateEnvironment(Environment $environment, UpdateEnvironmentRequest $request)
    {
        try {
            $environment->fill($request->validated())->save();
            return response()->json([
                'status' => true,
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param int $id
     * @return JsonResponse
     */
    public function refreshConnectedDashboards(int $id)
    {
        try {
            $environment = Environment::where('id', $id)->firstOrFail();
            $relations = $environment->dashboardSheetRelations()->get();

            $execTime = Carbon::now();
            foreach ($relations as $relation) {
                $execTime->addSeconds(2);
                $action = new SyncDashboardRelation($relation);
                DispatchAction::of($action)->delay($execTime);
            }

            return response()->json([
                'success' => true,
                'data'    => [],
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param int $id
     * @return JsonResponse
     */
    public function deleteEnvironment(int $id)
    {
        try {
            $isDeleted = (new DeleteEnvironment($id))->run();
            return response()->json([
                'success' => $isDeleted,
                'data'    => [],
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param int $id
     * @param Request $request
     * @return JsonResponse
     */
    public function getDashboards(int $id, Request $request)
    {
        try {
            $user = $request->user();
            $presenter = new EnvironmentDashboardsPresenter($user, $id);

            if ($type = $request->get('type')) {
                $presenter->setType($type);
            }

            if (!$user->isOrganizationOwner() && $request->boolean("available")) {
                $presenter->setIgnoreMaxRole(true);
            }

            $reports = $presenter->present();


            return fractal($reports)
                ->parseIncludes(['items'])
                ->transformWith(new DashboardTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
            /* return response()->json([
                 'success' => true,
                 'data'    => $presenter->present()->toArray(),
             ]);*/
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template // report template (data collection)
     * @param Request $request
     * @return JsonResponse
     */
    public function getEnvironmentsForCreateReport(Template $template, Request $request)
    {
        try {
            if ($template->type !== DashboardType::DASHBOARD) {
                throw new \InvalidArgumentException("invalid template type");
            }

            $userEnvironments = (new EnvironmentsPresenter($request->user()))->present();

            if (!$template->use_with_any_summary) {
                $userEnvironments = $userEnvironments->whereIn('global_template_id', $template->relatedSummaries->pluck('id')->toArray());
            }

            $transformer = new EnvironmentTransformer();
            $transformer->setIncludeCurrentRole(true);

            return fractal($userEnvironments)
                ->transformWith($transformer)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }
}
