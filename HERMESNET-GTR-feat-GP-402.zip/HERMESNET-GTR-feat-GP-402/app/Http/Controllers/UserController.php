<?php

namespace App\Http\Controllers;

use App\Actions\Organization\CreateOrganizationFolder;
use App\Http\Requests\ChangeUserPermissionRequest;
use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardUser;
use App\Models\InvitedUser;
use App\Models\User;
use App\Presenters\UserDetailsPresenter;
use App\Services\User\Enums\UserRole;
use App\Services\User\Enums\UserType;
use App\Services\User\UserPermissions\CheckCanManagePermission;
use App\Services\User\UserPermissions\CheckUserHasAccess;
use App\Services\User\UserPermissions\RefreshAllUserPermissions;
use App\Services\User\UserPermissions\RevokeUserPermissions;
use App\Services\User\UserPermissions\UpdateUserPermissions;
use App\Services\User\UserPermissions\UserPermissionDto;
use App\Transformers\OrganizationTransformer;
use App\Transformers\UserTransformer;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use App\Services\User\RemoveUser;
use Spatie\Fractalistic\ArraySerializer;

/**
 *
 */
class UserController extends Controller
{

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function getOrganization(Request $request)
    {
        try {
            return fractal($request->user()->organization)
                ->transformWith(new OrganizationTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function getUser(Request $request)
    {
        try {
            /**
             * @var $user User
             */
            $user = $request->user();

            return fractal($user)
                ->transformWith(new UserTransformer())
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function getLowerLevelUsers(Request $request)
    {
        try {
            $currentUser = $request->user();

            $roles = UserRole::getLowerLevelRoles($currentUser->role, true);
            $users = User::whereIn('role', $roles)
                ->where('organization_id', $currentUser->organization_id)
                ->where('id', '<>', \Auth::id())
                ->get();

            return fractal($users)
                ->transformWith(new UserTransformer())
                ->respond();

        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param int $id
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function removeUser(int $id, Request $request)
    {
        try {
            $currentUser = $request->user();

            $targetUser = User::where('id', $id)->first();

            $userType = UserType::REGULAR;
            if (!$targetUser) {
                $targetUser = InvitedUser::where("id", $id)->first();
                $userType = UserType::INVITED;
            }

            if (!$targetUser) {
                throw ValidationException::withMessages([
                    'user' => "User not found"
                ]);
            }

            if ($userType === UserType::REGULAR) {
                if (!$currentUser->can('deleteUser', $targetUser)) {
                    throw ValidationException::withMessages([
                        'user' => "You cannot delete this user"
                    ]);
                }

                $isRemoved = (new RemoveUser($targetUser))->run();
            } else {
                $isRemoved = $targetUser->delete();
            }

            return response()->json([
                "status" => $isRemoved,
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param int $id
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function getUserDetail(int $id, Request $request)
    {
        try {
            $presenter = new UserDetailsPresenter(
                currentUser: $request->user(),
                needleUserId: $id
            );
            $type = $request->get("type");
            if ($type) {
                $presenter->setType($type);
            }
            return response()->json($presenter->present());
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param int $permissionId
     * @return \Illuminate\Http\JsonResponse
     */
    public function getPermission(int $permissionId)
    {
        try {
            $permission = DashboardUser::where("id", $permissionId)->firstOrFail();
            return response()->json($permission->toArray());
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param int $id
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function getRoleByEnvironment(int $id, Request $request)
    {
        $request->validate([
            'environment_id' => ['required', 'int'],
            'dashboard_id'   => ['nullable', 'int'],
        ]);

        try {
            $permission = DashboardUser::where("user_id", $id)
                ->where("environment_id", $request->get("environment_id"));

            if ($request->get("dashboard_id")) {
                $permission->where("dashboard_id", $request->get("dashboard_id"));
            }

            $permission = $permission->get();
            if (!$permission->isEmpty()) {
                $role = UserRole::getMaxRoleOf($permission->pluck("role")->toArray());
            } else {
                $role = null;
            }

            return response()->json([
                'role' => $role
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param int $permissionId
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function revokePermissions(int $permissionId, Request $request)
    {
        try {
            $permission = DashboardUser::where('id', $permissionId)->firstOrFail();
            $user = User::where('id', $permission->user_id)->firstOrFail();

            $canMange = new CheckCanManagePermission(
                $permission,
                $request->user()
            );
            if (!$canMange->run()) {
                throw ValidationException::withMessages([
                    'user' => "You cannot delete this user role"
                ]);
            }

            $userPermissions = new UserPermissionDto();
            $userPermissions->setRole($permission->role);
            $userPermissions->setEnvironmentId($permission->environment_id);
            $userPermissions->setDashboardId($permission->dashboard_id);

            $action = new RevokeUserPermissions($user, $userPermissions);
            $action->setWithOrgFolderPermissions(true);
            $status = $action->run();
            $userIsDeleted = false;
            //delete the user if he does not have any permissions
            $hasMorePermissions = DashboardUser::where("user_id", $user->id)->exists();
            if (!$hasMorePermissions) {
                $removeUser = new RemoveUser($user);
                $userIsDeleted = $removeUser->run();
            }

            return response()->json([
                "status"          => $status,
                "user_is_deleted" => $userIsDeleted,
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param int $id
     * @param ChangeUserPermissionRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function updatePermission(int $id, ChangeUserPermissionRequest $request)
    {
        try {
            $request->validateRole();

            $permission = DashboardUser::where("id", $id)->firstOrFail();

            $canMange = new CheckCanManagePermission(
                $permission,
                $request->user()
            );
            if (!$canMange->run()) {
                throw ValidationException::withMessages([
                    'user' => "You cannot perform this operation"
                ]);
            }

            $action = new UpdateUserPermissions(
                currentPermissions: $permission,
                newPermissionDto: $request->getPermissionDto()
            );
            $action->run();

            return response()->json([
                "status" => true,
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse|void
     */
    public function refreshPermissions(Request $request)
    {
        try {
            $user = $request->user();
            $targetWorkspaceId = $request->get("workspace_id");
            $targetReportId = $request->get("report_id");


            LoggerUtil::info("Refresh Permissions", [
                'user_id'      => $user->id,
                'workspace_id' => $targetWorkspaceId,
                'report_id'    => $targetReportId,
            ]);

            (new RefreshAllUserPermissions($user, $targetWorkspaceId, $targetReportId))->run();

            $organization = $user->organization;
            if (!$organization->drive_folder_id) {
                $organization->drive_folder_id = (new CreateOrganizationFolder($user))->run();
                $organization->save();
            }
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param int $dashboard_id
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function checkUserDashboardAccess(int $dashboard_id, Request $request)
    {
        $status = false;
        try {
            $dashboard = Dashboard::where("id", $dashboard_id)->firstOrFail();
            $status = (new CheckUserHasAccess(
                $request->user(),
                $dashboard->environment_id,
                $dashboard->id
            ))->check();


        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
        }

        return response()->json(compact("status"));
    }

}
