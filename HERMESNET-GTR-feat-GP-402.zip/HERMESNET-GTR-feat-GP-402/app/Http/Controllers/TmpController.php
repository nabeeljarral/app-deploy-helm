<?php

namespace App\Http\Controllers;

use App\Models\Dashboard\Dashboard;
use App\Models\Template\TemplateAnalytics;
use App\Models\User;
use App\Services\Looker\ManuallySignedUrl;

/**
 *
 */
class TmpController extends Controller
{
    /**
     * @return \Illuminate\Http\JsonResponse
     * @throws \Exception
     */
    public function mockPdfFile()
    {
        $report = Dashboard::find(1027);
        $user = User::find(116);
        $analytics = TemplateAnalytics::find(66);

        $url = (new ManuallySignedUrl($report, $analytics, $user))->run();
        return  response()->json([
            'url' => $url,
        ]);
        //return response()->file(storage_path("app/public/test.pdf"));
    }
}
