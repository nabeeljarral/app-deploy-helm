<?php

namespace App\Http\Controllers\DashBoards;

use App\Actions\DashBoard\FetchDashboardTabsAction;
use App\Exceptions\PolicyException;
use App\Http\Controllers\Controller;
use App\Http\Requests\CreateReportRequest;
use App\Http\Requests\DefineDataCollectionsStructureRequest;
use App\Http\Requests\SaveConfigurationRequest;
use App\Http\Requests\ImportSheetRequest;
use App\Http\Requests\UpdateDashboardPropertiesRequest;
use App\Models\ConfigurationItem;
use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardMethodology;
use App\Models\Dashboard\DashboardSheet;
use App\Models\PrintConfTemplate;
use App\Models\Views\ConfigurationItemsView;
use App\Presenters\Report\ReportItemsNestedListPresenter;
use App\Presenters\Report\ReportUsersPresenter;
use App\Services\Configuration\CreateConfigurationFromReport;
use App\Services\Configuration\SelectAllConfigurationItems;
use App\Services\Dashboard\Create\CreateReportProcedure;
use App\Services\Dashboard\DefineDataCollectionsStructure;
use App\Services\Dashboard\DeleteDashboard;
use App\Services\Dashboard\GeneratePdfReport;
use App\Services\Dashboard\GeneratePdfReportOld;
use App\Services\Dashboard\ImportSheet\ImportSheet;
use App\Services\Dashboard\ResetReportItems;
use App\Services\Environment\AddEnvironmentDashboard;
use App\Services\Google\ExportSheet;
use App\Services\GtrSync\Jobs\GtrSyncReportDataJob;
use App\Services\PrintConfiguration\RequestDataGenerator;
use App\Transformers\Configuration\ConfigurationTransformer;
use App\Transformers\Configuration\Item\ItemTransformer;
use App\Transformers\Configuration\Item\ItemViewTransformer;
use App\Transformers\DashboardTransformer;
use App\Transformers\UserTransformer;
use App\Utils\LoggerUtil;
use App\Utils\MinifyUtil;
use App\Utils\ResponseUtil;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Spatie\Fractalistic\ArraySerializer;

/**
 * TODO: rename to ReportController
 */
class DashBoardController extends Controller
{

    /**
     * @param int $id
     * @param Request $request
     * @return JsonResponse
     */
    public function getDashboard(int $id, Request $request)
    {
        try {
            $transformer = new DashboardTransformer();
            $includes = [];
            if ($request->get('includes')) {
                $requestIncludes = explode(',', $request->get('includes'));
                if (!empty($requestIncludes)) {
                    $includes = $requestIncludes;
                }
            }

            return fractal(Dashboard::findOrFail($id))
                ->transformWith($transformer)
                ->parseIncludes($includes)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function fetchDashboardTabs(Request $request): JsonResponse
    {
        $environmentId = $request->input('environment_id');
        $fileId = $request->input('file_id');
        $dashboardId = $request->input('dashboard_id');

        $tabs = (new FetchDashboardTabsAction($environmentId, $fileId, $dashboardId))->run();

        if (is_null($tabs)) {
            return response()
                ->json([
                    'success' => false,
                    'tabs'    => []
                ]);
        }

        return response()
            ->json([
                'success' => true,
                'tabs'    => $tabs
            ]);
    }


    /**
     * @param ImportSheetRequest $request
     * @return JsonResponse
     */
    public function importSheet(ImportSheetRequest $request)
    {
        try {
            ini_set('memory_limit', '2048M');
            $sheet = DashboardSheet::whereId($request->get("sheet_id"))->firstOrFail();
            $localFileId = uniqid();

            $uploaded = $request->file("file")
                ->storeAs('import', $localFileId . ".xlsx");

            if (!$uploaded) {
                throw new \RuntimeException("An error occurred while uploading the file");
            }

            $action = new ImportSheet(
                dashboardSheet: $sheet,
                localFileId: $localFileId,
                uploader: $request->user()
            );

            $action->run();

            return response()
                ->json([
                    'success' => true,
                    'data'    => [],
                ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param CreateReportRequest $request
     * @return JsonResponse
     */
    public function createReport(CreateReportRequest $request): JsonResponse
    {
        try {
            $report = (new CreateReportProcedure($request->getDto()))->run();
            $report = (new AddEnvironmentDashboard($request->user(), $report))->run();

            return fractal($report)
                ->transformWith(new DashboardTransformer())
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param int $id
     * @return JsonResponse
     */
    public function removeDashboard(int $id)
    {
        try {
            $isDeleted = (new DeleteDashboard($id))->run();
            return response()
                ->json([
                    'success' => $isDeleted,
                    'data'    => [],
                ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param int|string|null $id
     * @return JsonResponse
     */
    public function getMethodologyContent(int|string $id = null)
    {
        try {
            $methodology = DashboardMethodology::where("dashboard_id", $id)->first();
            if ($methodology) {
                $content = $methodology->content;
            } else {
                $content = MinifyUtil::html(view("templates.methodology.default", [])->render());
            }

            return response()->json([
                'content' => $content,
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param int $id
     * @param Request $request
     * @return JsonResponse
     */
    public function saveMethodologyContent(int $id, Request $request)
    {
        $request->validate([
            'content' => ['required', 'string']
        ]);

        try {
            $content = MinifyUtil::html($request->get("content"));

            $methodology = DashboardMethodology::updateOrCreate(
                ['dashboard_id' => $id],
                [
                    'dashboard_id' => $id,
                    'content'      => $content
                ]
            );

            return response()->json([
                'content' => $methodology->content,
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param int $id
     * @param int $print_configuration_template_id
     * @param Request $request
     * @return JsonResponse|\Symfony\Component\HttpFoundation\StreamedResponse|void
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function generatePdfReport(int $id, int $print_configuration_template_id, Request $request)
    {
        try {
            $dashboard = Dashboard::where("id", $id)->first();
            if (!$dashboard) {
                throw ValidationException::withMessages([
                    'dashboard' => "Report does not exist"
                ]);
            }
            $printTemplate = new RequestDataGenerator($print_configuration_template_id);
            $printTemplate->withReportStructure($dashboard);

            $generateAction = new GeneratePdfReport($dashboard, $printTemplate->generateRequestData());
            $generateAction->setExportJson($request->boolean("export"));
            return $generateAction->run();
        } catch (\Exception $exception) {
            //dd($exception);
            LoggerUtil::exception($exception);
            abort(403);
        }
    }

    /**
     * @param int $id
     * @return mixed|\Symfony\Component\HttpFoundation\StreamedResponse|void
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function generateOldPdfReport(int $id)
    {
        try {
            $dashboard = Dashboard::where("id", $id)->first();
            if (!$dashboard) {
                throw ValidationException::withMessages([
                    'dashboard' => "Report does not exist"
                ]);
            }

            $generateAction = new GeneratePdfReportOld($dashboard);
            return $generateAction->run();
        } catch (\Exception $exception) {
            //dd($exception);
            LoggerUtil::exception($exception);
            abort(403);
        }
    }

    /**
     * @param int $sheet_id
     * @return \Symfony\Component\HttpFoundation\BinaryFileResponse|void
     */
    public function exportSheet(int $sheet_id)
    {
        ini_set('memory_limit', '2048M');
        try {
            $sheet = DashboardSheet::where('id', $sheet_id)->first();
            $action = new ExportSheet($sheet);
            $action->run();

            return \Response::file($action->getFilePath(), [
                "Content-Disposition" => "attachment; filename=template-" . $sheet->sheet_title . ".xlsx"
            ])->deleteFileAfterSend(true);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            abort(500);
        }
    }

    /**
     * @param Dashboard $dashboard
     * @param int $status
     * @return JsonResponse
     */
    public function updateStatus(Dashboard $dashboard, int $status): JsonResponse
    {
        try {
            $dashboard->status = $status;
            $dashboard->save();
            return response()->json([
                'status' => true,
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Dashboard $dashboard
     * @param UpdateDashboardPropertiesRequest $requestre
     * @return JsonResponse
     */
    public function updateProperties(Dashboard $dashboard, UpdateDashboardPropertiesRequest $request): JsonResponse
    {
        try {
            if (!$request->user()->can("updateDashboardProperties", $dashboard)) {
                throw new PolicyException('you do not have access rights');
            }
            $dashboard->fill($request->validated());
            $dashboard->save();

            return response()->json([
                'status' => true,
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Dashboard $dashboard
     * @param Request $request
     * @return JsonResponse
     */
    public function getItemsNestedList(Dashboard $dashboard, Request $request): JsonResponse
    {
        try {
            $presenter = new ReportItemsNestedListPresenter(
                report: $dashboard,
                includedOnly: $request->boolean('includedOnly'),
                checkPermissions: true
            );

            return \Response::json($presenter->present());
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Dashboard $dashboard
     * @param Request $request
     * @return JsonResponse
     */
    public function getItemsForExport(Dashboard $dashboard, Request $request): JsonResponse
    {
        try {
            $presenter = new ReportItemsNestedListPresenter(
                report: $dashboard,
                includedOnly: $request->boolean('includedOnly'),
                checkPermissions: true
            );

            //TODO: need to discus with client,
            // because google sheet type filter is not correctly filter
            // Wee add new type Custom Table, that can be exported too

            //$presenter->setChildrenScopes(['hasGoogleSheet'']);

            return \Response::json($presenter->present());
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Dashboard $dashboard
     * @param Request $request
     * @return JsonResponse
     */
    public function updateItemsIncluded(Dashboard $dashboard, Request $request): JsonResponse
    {
        \Request::validate([
            'ids'         => ['required', 'array'],
            'ids.*'       => ['required', 'int'],
            'is_included' => ['required', 'boolean'],
        ]);

        try {
            $dashboard->items()
                ->whereIn('id', $request->get('ids'))
                ->update(['is_included' => $request->boolean('is_included')]);

            return \Response::json(['status' => true]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Dashboard $dashboard
     * @param SaveConfigurationRequest $request
     * @return JsonResponse
     */
    public function createConfiguration(Dashboard $dashboard, SaveConfigurationRequest $request): JsonResponse
    {
        try {
            $action = new CreateConfigurationFromReport($dashboard, $request->getDto());
            $configuration = $action->run();

            return fractal($configuration)
                ->transformWith(new ConfigurationTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Dashboard $dashboard
     * @return JsonResponse
     */
    public function resetReportItems(Dashboard $dashboard): JsonResponse
    {
        try {
            (new ResetReportItems($dashboard))->run();

            $presenter = new ReportItemsNestedListPresenter($dashboard);
            return \Response::json($presenter->present());
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Dashboard $dashboard
     * @param Request $request
     * @return JsonResponse
     */
    public function selectAllItems(Dashboard $dashboard, Request $request): JsonResponse
    {
        try {
            (new SelectAllConfigurationItems(
                entry: $dashboard,
                is_included: $request->boolean('is_included'))
            )->run();

            $presenter = new ReportItemsNestedListPresenter($dashboard);
            return \Response::json($presenter->present());
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Dashboard $dashboard
     * @return JsonResponse
     */
    public function getUsers(Dashboard $dashboard)
    {
        try {
            $users = (new ReportUsersPresenter($dashboard))->present();

            return fractal($users)
                ->transformWith(new UserTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Request $request
     * @return JsonResponse
     * Get multiple reports items
     */
    public function getReportsItems(Request $request): JsonResponse
    {
        try {
            $ids = explode(',', $request->get('ids', ''));
            if (empty($ids)) {
                return response()->json();
            }

            $items = ConfigurationItem::query()
                ->whereIn('report_id', $ids)
                ->get();

            $transformer = new ItemTransformer();
            $transformer->setWithItemPath(false);

            return fractal($items)
                ->transformWith($transformer)
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param DefineDataCollectionsStructureRequest $request
     * @return JsonResponse
     */
    public function defineDataCollectionsStructure(DefineDataCollectionsStructureRequest $request): JsonResponse
    {
        try {
            $action = new DefineDataCollectionsStructure(
                reports: $request->get('reports'),
                items: $request->get('items'),
            );

            $status = $action->run();
            return response()->json(compact('status'));
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function dispatchGtrSync(Request $request)
    {
        LoggerUtil::info("[Report] DashBoardController::dispatchGtrSync.", $request->input("ids"));
        try {
            $request->validate([
                'ids'   => ['required', 'array'],
                'ids.*' => ['required', 'int']
            ]);

            foreach ($request->input('ids') as $id) {
                $job = new GtrSyncReportDataJob($id);
                dispatch($job)->delay(now()->addSeconds(20));
            }

            return response()->json(['status' => true]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }
}
