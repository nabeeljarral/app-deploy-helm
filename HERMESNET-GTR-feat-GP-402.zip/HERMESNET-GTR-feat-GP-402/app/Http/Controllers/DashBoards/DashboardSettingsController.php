<?php

namespace App\Http\Controllers\DashBoards;

use App\Abstractions\Queue\DispatchAction;
use App\Http\Controllers\Controller;
use App\Http\Requests\SaveProtectionConfigRequest;
use App\Models\Dashboard\Dashboard;
use App\Models\User;
use App\Services\Dashboard\Permissions\ImplementDashboardProtection;
use App\Services\Dashboard\Permissions\SaveDashboardProtection;
use App\Services\Google\Permissions\RevokeFilePermissions;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Illuminate\Http\Request;

/**
 *
 */
class DashboardSettingsController extends Controller
{
    /**
     * @param SaveProtectionConfigRequest $request
     * @return \Illuminate\Http\JsonResponse|void
     */
    public function saveProtectionConfig(SaveProtectionConfigRequest $request)
    {
        try {
            $dashboard = Dashboard::where("id", $request->dashboard_id)->firstOrFail();

            $saveAction = new SaveDashboardProtection($dashboard);

            if (is_array($request->get("unprotected"))) {
                $saveAction->setUnprotectedRange($request->get("unprotected"));
            }

            if (is_array($request->get("removed_unprotected"))) {
                $saveAction->setRemovedUnprotectedRange($request->get("removed_unprotected"));
            }
            $saveAction->run();

            $implementProtection = new ImplementDashboardProtection($dashboard);
            DispatchAction::of($implementProtection)->afterCommit()->delay(5);

            return response()->json([
                'success' => true,
                'data'    => [],
            ]);
        }
        catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }
}
