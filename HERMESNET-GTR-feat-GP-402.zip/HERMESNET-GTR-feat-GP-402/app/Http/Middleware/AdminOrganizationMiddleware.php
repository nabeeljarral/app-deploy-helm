<?php

namespace App\Http\Middleware;

use App\Models\Organization;
use Closure;
use Illuminate\Http\Request;

class AdminOrganizationMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        if (!$request->hasSession()) {
            return $next($request);
        }

        $user = $request->user();
        if (!$user) {
            return $next($request);
        }

        $session = $request->session();

        if ($user->is_admin && $session->has('organization_id')) {
            $user->setRelation('organization', Organization::query()->find(
                $session->get('organization_id')
            ));
            $user->organization_id = $session->get('organization_id');
        }

        return $next($request->merge(['user' => $user]));
    }
}
