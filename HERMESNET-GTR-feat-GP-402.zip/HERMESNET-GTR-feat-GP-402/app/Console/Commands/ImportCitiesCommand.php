<?php

namespace App\Console\Commands;

use App\Models\City;
use Illuminate\Console\Command;

/**
 *
 */
class ImportCitiesCommand extends Command
{
    /**
     *
     */
    const DEFAULT_FILE_PATH = 'storage/app/cities.csv';

    /**
     * @var string
     */
    protected $signature = 'import:cities {file? : The path to the file}';

    /**
     * @var string
     */
    protected $description = 'Command description';

    /**
     * @return void
     * @throws \Exception
     */
    public function handle(): void
    {
        $filePath = $this->argument('file') ?? self::DEFAULT_FILE_PATH;
        if (!file_exists($filePath)) {
            $this->error('File not found');
            return;
        }

        try {
            $result = $this->import($filePath);
            $this->info('Imported ' . count($result) . ' cities');
        } catch (\Exception $e) {
            $this->error($e->getMessage());
        }
    }

    /**
     * @param string $filePath
     * @return array
     * @throws \Exception
     */
    private function import(string $filePath): array
    {
        $stream = fopen($filePath, 'r');
        $data = [];

        $countryCodes = $this->getCountiesWithCode();

        while (($rawData = fgetcsv($stream, null, ',')) !== FALSE) {
            if (empty($headers)) {
                $headers = $rawData;
                continue;
            }

            $row = array_combine($headers, $rawData);

            $city = trim($row['city']);
            $country = trim($row['country']);

            if (!$city || !$country) {
                throw new \Exception('Invalid file format');
            }

            $data[] = [
                'city' => $city,
                'country' => $country,
                'country_code' => $countryCodes[$country] ?? null,
            ];
        }


        if (City::count() > 0) {
            return $this->upsert($data);
        }

        $bar = $this->output->createProgressBar(count($data));
        foreach (array_chunk($data, 1000) as $chunk) {
            City::insert($chunk);
            $bar->advance(count($chunk));
        }

        return $data;
    }

    /**
     * @param array $data
     * @return array
     * @throws \Exception
     */
    private function upsert(array $data): array
    {
        $bar = $this->output->createProgressBar(count($data));

        \DB::beginTransaction();
        foreach ($data as $record) {
            try {
                City::updateOrCreate($record, $record);
                $bar->advance();
            } catch (\Exception $e) {
                \DB::rollBack();
                throw $e;
            }
        }
        \DB::commit();

        return $data;
    }

    /**
     * Old dashboards use country code from the countries.json file
     * @return array
     */
    private function getCountiesWithCode(): array
    {
        $path = base_path() . '/public/meta/countries.json';
        if (!file_exists($path)) {
            return [];
        }

        $countries = json_decode(file_get_contents($path), true);

        return \Arr::pluck($countries, 'code', 'name');
    }
}
