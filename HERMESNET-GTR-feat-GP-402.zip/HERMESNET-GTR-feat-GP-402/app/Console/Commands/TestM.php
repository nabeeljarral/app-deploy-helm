<?php

namespace App\Console\Commands;

use App\Models\Template\Template;
use App\Models\Template\TemplateItem;
use App\Models\User;
use App\Transformers\Templates\TemplateTransformer;
use App\Utils\GoogleUtil;
use Google\Service\Drive;
use Google\Service\Sheets;
use Illuminate\Console\Command;
use Google;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use Spatie\Fractalistic\ArraySerializer;

class TestM extends Command
{
    protected $fileId = "1nd5TblA8jVT_tCb11HWhjPXYjFD78NLL";
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'testm';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $googleClient = GoogleUtil::apiClient([Drive::DRIVE]);
        $template = TemplateItem::find(174);

        $spreadsheetService = new Sheets($googleClient);
        $spreadsheet = $spreadsheetService->spreadsheets->get('1SPmoxulYn1WBm5Sx77izNsjWVrdRgKHt2dCHZ5Pq728');
        dd($spreadsheet);


        /*$googleClient = GoogleUtil::apiClient([Drive::DRIVE]);
        $driveService = new Drive($googleClient);
        $response = $driveService->files->export('135tHH_cZ2epyyTWoX0elPkDFBJEQYv8dhy4xtWnD9XA','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',['alt' => 'media']);
          $content = $response->getBody()->getContents();
        file_put_contents('test.xlsx',$content);*/
        $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load(storage_path('app/public/test.xlsx'));
        $sheets = $spreadsheet->getAllSheets();

        $sheetsCount = count($sheets);

        for ($i = 0; $i < $sheetsCount; $i++) {
            if ($sheets[$i]->getTitle() != config('project.dashboard.index_sheet')) {
                dump($i);
                $spreadsheet->removeSheetByIndex($spreadsheet->getIndex($spreadsheet->getSheetByName($sheets[$i]->getTitle())));
            }
        }

        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $writer->save(storage_path('app/public/test2.xlsx'));

//        dd($sheets);
    }
}
