<?php

namespace App\Console\Commands;

use App\Http\Controllers\PrintConfTemplateController;
use App\Models\PrintConfTemplate;
use App\Models\Template\Template;
use App\Services\PrintConfiguration\Templates\BlankPrintConfiguration;
use App\Services\PrintConfiguration\Templates\CustomPrintConfiguration;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\RequestOptions;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Http;

class SavePrintConfElementsToDB extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'print-configuration:save-elements';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Saves a blank template from the file to the database';


    /**
     * @throws \Exception
     * @throws GuzzleException
     */
    public function handle(BlankPrintConfiguration $service): string
    {
        $url = env("PRINT_MODULE_URL") . "/get_conf_elements";
        $client = new Client();

        $response = $client->get($url);

        $jsonElements = $response->getBody()->getContents();
        $arrayElements = json_decode($jsonElements, true);

        if($arrayElements == null)
            echo json_last_error_msg();

        return $service->updateBlankTemplate($arrayElements);
    }
}
