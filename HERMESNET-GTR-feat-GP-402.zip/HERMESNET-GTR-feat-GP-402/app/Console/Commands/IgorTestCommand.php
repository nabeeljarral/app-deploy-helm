<?php

namespace App\Console\Commands;

use App\Models\Template\TemplateAnalytics;
use Illuminate\Console\Command;

class IgorTestCommand extends Command
{
    protected $signature = 'igor:test';
    protected $description = 'Command description';

    public function handle()
    {
        $templateAnalytics = TemplateAnalytics::whereNotNull('looker_embedding_url')->first();

        $urlParts = parse_url($templateAnalytics->looker_embedding_url);
        $path = explode('/', $urlParts['path']);
        $dashboardId = $path[count($path) - 1];

        dd($dashboardId);
    }
}
