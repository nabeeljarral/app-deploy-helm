<?php

namespace App\Console\Commands\Admin;

use App\Models\User;
use App\Services\Google\Enums\GoogleDriveFileRole;
use App\Services\Google\Permissions\CreateFilePermissions;
use Illuminate\Console\Command;

/**
 *
 */
class AssignAdminAccessCommand extends Command
{
    /**
     * @var string
     */
    protected $signature = 'admin:assign-admin {user_id}';

    /**
     * @var string
     */
    protected $description = 'Command description';

    /**
     * @return void
     * @throws \Exception
     */
    public function handle(): void
    {
        $userId = (int)$this->argument('user_id');

        $user = User::where("id", $userId)->firstOrFail();

        if ($user->is_admin) {
            $this->error("the user '{$user->name}' already has administrator rights");
            return;
        }

        $action = new CreateFilePermissions(
            fileId: config('project.google.drive.clients_folder_id'),
            role: GoogleDriveFileRole::WRITER,
            email: $user->google_email
        );
        $action->run();

        $user->is_admin = true;
        $user->save();

        $this->output->success("Success");
    }
}
