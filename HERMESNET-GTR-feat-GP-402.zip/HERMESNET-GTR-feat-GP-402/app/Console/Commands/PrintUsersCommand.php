<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;

class PrintUsersCommand extends Command
{
    protected $signature = 'print:users';

    protected $description = 'Command description';

    public function handle()
    {
        $columns = ["id", "email", "name", 'organization_id', "role", "google_email"];
        $this->table(
            $columns,
            User::select($columns)->get()->toArray()
        );
    }
}
