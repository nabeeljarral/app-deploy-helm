<?php

namespace App\Console\Commands;

use App\Models\Dashboard\DashboardSheetRelations;
use App\Models\Dashboard\DashboardUser;
use App\Models\Environment;
use App\Models\Organization;
use App\Services\Google\DeleteFile;
use Illuminate\Console\Command;

/**
 *
 */
class RemoveOrganizationCommand extends Command
{
    /**
     * @var string
     */
    protected $signature = 'organization:remove {id}';

    /**
     * @var string
     */
    protected $description = 'Command description';

    /**
     * @return void
     */
    public function handle()
    {
        if ($this->argument("id") === "all") {
            $this->removeAll();
            return;
        }
        $organizationId = $this->argument("id");
        $this->removeById($organizationId);
    }

    /**
     * @return void
     */
    private function removeAll()
    {
        foreach (Organization::all() as $item) {
            try {
                $this->removeById($item->id);
            }
            catch (\Exception $exception) {
                $this->error($exception->getMessage());
            }
            sleep(3);
        }
    }

    /**
     * @param int $organizationId
     * @return void
     */
    private function removeById(int $organizationId)
    {
        $organization = Organization::where("id", $organizationId)->first();

        if (!$organization) {
            $this->error("Organization not found!");
            return;
        }

        $organization = Organization::where("id", $organizationId)->firstOrFail();
        $environments = Environment::where('organization_id', $organizationId)->get();

        foreach ($environments as $environment) {
            DashboardSheetRelations::where("environment_id", $environment->id)->delete();
            DashboardUser::where("environment_id", $environment->id)->delete();
            $environment->dashboards()->delete();
        }

        $organization->users()->delete();

        if ($organization->drive_folder_id) {
            (new DeleteFile($organization->drive_folder_id))->run();
        }

        $organization->environments()->delete();

        $organization->delete();
    }
}
