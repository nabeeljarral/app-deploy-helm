<?php

namespace App\Console\Commands;

use App\Models\Environment;
use App\Services\Environment\SetEnvironmentDshTimestamps;
use Illuminate\Console\Command;

/**
 *
 */
class EnvironmentSetDshTimestampsCommand extends Command
{
    /**
     * @var string
     */
    protected $signature = 'environment:set-dsh-timestamps';

    /**
     * @var string
     */
    protected $description = 'Command description';

    /**
     * @return void
     */
    public function handle(): void
    {
        $environments = Environment::all();
        $bar = $this->output->createProgressBar($environments->count());

        foreach ($environments as $environment) {
            try {
                (new SetEnvironmentDshTimestamps($environment))->run();
            } catch (\Exception $exception) {
                $this->output->error($exception->getMessage());
            }
            $bar->advance();
            sleep(.5);
        }
    }
}
