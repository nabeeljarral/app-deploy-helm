<?php

namespace App\Console\Commands;

use App\Mail\InviteOrganizationMail;
use App\Models\InvitedOrganization;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;

class InviteNewOrganizationCommand extends Command
{
    protected $signature = 'organization:invite-new';

    protected $description = 'Command description';

    public function handle(): void
    {
        $invitedOrganization = InvitedOrganization::create([
            'email'     => "iy@crmoz.com",
            'user_name' => "Organization #1",
            'owner' => 551
        ]);

        $mail = new InviteOrganizationMail($invitedOrganization);
        $sentMessage = Mail::to($invitedOrganization->email)->send($mail);

        dd($sentMessage);
    }
}
