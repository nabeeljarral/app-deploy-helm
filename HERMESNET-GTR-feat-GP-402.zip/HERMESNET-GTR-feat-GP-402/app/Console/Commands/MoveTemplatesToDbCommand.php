<?php

namespace App\Console\Commands;

use App\Models\Template\Template;
use App\Models\Template\TemplateRelatedSummary;
use App\Services\Dashboard\Enums\DashboardType;
use App\Services\Template\Enums\TemplateCategory;
use Illuminate\Console\Command;

/**
 *
 */
class MoveTemplatesToDbCommand extends Command
{
    /**
     * @var string
     */
    protected $signature = 'move:templates-to-db';

    /**
     * @var string
     */
    protected $description = 'Command description';

    /**
     * @return void
     */
    public function handle(): void
    {
        $templatesConfig = config("project.dashboard.templates");
        foreach ($templatesConfig as $key => $item) {
            Template::create([
                'name'                   => $item['label'],
                'description'            => $item['description'],
                'category'               => TemplateCategory::DEFAULT,
                'type'                   => $item['type'],
                'is_trial'               => (bool)\Arr::get($item, "trial"),
                'is_public'              => true,
                'is_published'           => true,
                'is_blank'               => $key === "empty",
                'has_preview'            => !!\Arr::get($item, "preview_id"),
                'gd_file_id'             => $item['id'],
                'index_sheet'            => $item['index_sheet'],
                'gd_preview_file_id'     => \Arr::get($item, "preview_id"),
                'hidden_connected_sheet' => (bool)\Arr::get($item, "hidden_connected_sheet"),
                'data_sheet'             => \Arr::get($item, "data_sheet", "Data"),
            ]);
        }

        foreach ($templatesConfig as $item) {
            $dcTemplate = Template::where("gd_file_id", $item['id'])
                ->where('type', DashboardType::DASHBOARD)
                ->first();

            if (!$dcTemplate) {
                continue;
            }

            $relatedSummary = \Arr::get($item, 'related_summary');
            if (!is_array($relatedSummary)) {
                continue;
            }

            $summaryTemplates = Template::whereIn("gd_file_id", $relatedSummary)
                ->whereNot("id", $dcTemplate->id)
                ->get();

            foreach ($summaryTemplates as $template) {
                TemplateRelatedSummary::updateOrCreate([
                    'data_collection_id' => $dcTemplate->id,
                    'summary_id' => $template->id,
                ]);
            }

            $dcTemplate->use_with_any_summary = false;
            $dcTemplate->save();
        }
    }
}
