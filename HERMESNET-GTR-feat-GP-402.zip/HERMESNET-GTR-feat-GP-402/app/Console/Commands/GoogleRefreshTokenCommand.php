<?php

namespace App\Console\Commands;

use App\Services\Google\GoogleAccessToken;
use App\Utils\LoggerUtil;
use Illuminate\Console\Command;

/**
 *
 */
class GoogleRefreshTokenCommand extends Command
{
    /**
     * @var string
     */
    protected $signature = 'google:refresh-token';

    /**
     * @var string
     */
    protected $description = 'Refresh Google Access Token';

    /**
     * @return void
     */
    public function handle()
    {
        try {
            GoogleAccessToken::getInstance()->refresh();
        }
        catch (\Exception $exception) {
            LoggerUtil::exception($exception);
        }
    }
}
