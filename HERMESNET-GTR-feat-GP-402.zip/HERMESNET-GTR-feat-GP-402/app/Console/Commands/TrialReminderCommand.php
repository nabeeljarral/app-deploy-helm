<?php

namespace App\Console\Commands;

use App\Admin\Mail\TrialAdminNotificationMail;
use App\Admin\Services\SendAdminsEmail;
use App\Mail\TrialExpiredReminderMail;
use App\Models\Organization;
use App\Models\User;
use App\Services\User\Enums\UserRole;
use App\Utils\LoggerUtil;
use Illuminate\Console\Command;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Mail;

/**
 *
 */
class TrialReminderCommand extends Command
{
    /**
     * @var string
     */
    protected $signature = 'trial:reminder {--is-over}';

    /**
     * @var string
     */
    protected $description = 'Command description';

    /**
     * @return void
     */
    public function handle(): void
    {
        $isOver = $this->option('is-over');

        logger()->info("TrialReminderCommand.", [
            'is-over' => $isOver
        ]);

        $date = $isOver
            ? today()
            : today()->addDays(config('project.subscription.trial.days_until_remaining'));

        $organizations = Organization::where('is_trial_access', true)
            ->where('trial_expired_at', '=', $date)
            ->get();

        if ($organizations->isEmpty()) {
            $this->output->info("no organizations for remaining");
            return;
        }

        $this->toEnvironmentOwners($organizations);
        $this->toAdmins($organizations);
    }

    /**
     * @param Collection $organizations
     * @return void
     */
    private function toEnvironmentOwners(Collection $organizations): void
    {
        $isOver = $this->option('is-over');

        foreach ($organizations as $organization) {
            try {
                $environmentOwners = $organization->users()
                    ->where('role', UserRole::ENVIRONMENT_OWNER)
                    ->get();

                $daysLeft = ($isOver) ? 0 : config('project.subscription.trial.days_until_remaining');

                /**@var User $environmentOwner */
                foreach ($environmentOwners as $environmentOwner) {
                    $this->output->info($organization->organization_name . " - " . $environmentOwner->email);
                    $mail = new TrialExpiredReminderMail(
                        $environmentOwner->name,
                        $daysLeft
                    );
                    Mail::to($environmentOwner->email)->queue($mail);
                }
            } catch (\Exception $exception) {
                $this->output->error($exception->getMessage());
                LoggerUtil::exception($exception);
            }
        }
    }

    /**
     * @param Collection $organizations
     * @return void
     */
    private function toAdmins(Collection $organizations): void
    {
        $adminMail = new TrialAdminNotificationMail($organizations, $this->option('is-over'));
        (new SendAdminsEmail($adminMail))->run();
    }
}
