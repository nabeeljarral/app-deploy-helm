<?php

namespace App\Console\Commands\TMP;

use App\Models\City;
use App\Models\Dashboard\Dashboard;
use Illuminate\Console\Command;

class UpdateDashboardsCountryField extends Command
{
    /**
     * @var string
     */
    protected $signature = 'tmp:update-dashboards-country-field';

    /**
     * @var string
     */
    protected $description = 'Command description';

    /**
     * @return void
     */
    public function handle(): void
    {
        $countryCodes = City::select('country', 'country_code')
            ->distinct()
            ->whereNotNull('country_code')
            ->get()
            ->pluck('country', 'country_code')
            ->toArray();

        $dashboards = Dashboard::whereNotNull('country')->get();

        foreach ($dashboards as $dashboard) {
            $country = $countryCodes[$dashboard->country] ?? null;
            if (!$country) {
                continue;
            }
            $dashboard->update(['country' => $country], ['timestamps' => false]);
        }
    }
}
