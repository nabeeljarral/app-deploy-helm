<?php

namespace App\Console\Commands\TMP;

use App\Models\City;
use App\Models\Organization;
use Illuminate\Console\Command;

/**
 *
 */
class TmpGP348Command extends Command
{
    /**
     * @var string
     */
    protected $signature = 'tmp:gp348';

    /**
     * @var string
     */
    protected $description = 'GP-342: Organizations registered before GP-342 implementation do not have Country';

    /**
     * @return void
     */
    public function handle(): void
    {
        $countryCodes = City::select(['country', 'country_code'])
            ->distinct()
            ->whereNotNull('country_code')
            ->get()
            ->pluck('country', 'country_code')
            ->toArray();

        $organizations = Organization::whereNull('country')->whereNotNull('countries')->get();
        $bar = $this->output->createProgressBar($organizations->count());
        foreach ($organizations as $organization) {
            $code = \Arr::first($organization->countries);
            if (!$code || !isset($countryCodes[$code])) {
                continue;
            }
            $organization->update(['country' => $countryCodes[$code]], ['timestamps' => false]);
            $bar->advance();
        }
    }
}
