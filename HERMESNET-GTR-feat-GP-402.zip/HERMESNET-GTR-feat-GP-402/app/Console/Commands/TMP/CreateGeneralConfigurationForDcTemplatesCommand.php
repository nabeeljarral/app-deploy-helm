<?php

namespace App\Console\Commands\TMP;

use App\Models\Template\Template;
use App\Services\Configuration\CreateTemplateConfiguration;
use App\Services\Configuration\DTO\ConfigurationDto;
use App\Services\Dashboard\Enums\DashboardType;
use App\Services\Template\Enums\TemplateCategory;
use Illuminate\Console\Command;

/**
 *
 */
class CreateGeneralConfigurationForDcTemplatesCommand extends Command
{
    /**
     * @var string
     */
    protected $signature = 'tmp:create-general-configuration-for-dc-templates';

    /**
     * @var string
     */
    protected $description = 'Create general configuration for data collection templates if not exists';

    /**
     * @return void
     */
    public function handle(): void
    {
        $templates = Template::where('type', DashboardType::DASHBOARD)
            ->where("category", TemplateCategory::COMPLEX)
            ->with("configurations", function ($query) {
                $query->whereNull('organization_id')
                    ->where("is_general", true);
            })
            ->get();

        foreach ($templates as $item) {
            if ($item->configurations->count() > 0) {
                continue;
            }

            $configurationDto = new ConfigurationDto();
            $configurationDto->name = $item->name;
            $configurationDto->is_general = true;
            $configurationDto->is_published = true;

            (new CreateTemplateConfiguration($item, $configurationDto))->run();
        }
    }
}
