<?php

namespace App\Console\Commands\TMP;

use App\Models\Dashboard\Dashboard;
use Illuminate\Console\Command;

/**
 *
 */
class TmpGP353Command extends Command
{
    /**
     * @var string
     */
    protected $signature = 'tmp:gp353';

    /**
     * @var string
     */
    protected $description = 'GP-353: Summary reports created before gp-344 deployment shall have city/country set to those from organization if empty';

    /**
     * @return void
     */
    public function handle(): void
    {
        $reports = Dashboard::query()
            ->whereNull('city')
            ->whereNull('country')
            ->get();

        $bar = $this->output->createProgressBar($reports->count());

        foreach ($reports as $report) {
            $bar->advance();

            $organization = $report->environment->organization;
            if (!$organization || !$organization->city || !$organization->country) {
                continue;
            }

            $report->update([
                'country' => $organization->country,
                'city' => $organization->city,
            ]);
        }
    }
}
