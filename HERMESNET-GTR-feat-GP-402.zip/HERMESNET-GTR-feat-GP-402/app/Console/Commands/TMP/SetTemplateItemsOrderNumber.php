<?php

namespace App\Console\Commands\TMP;


use App\Models\Template\Template;
use App\Models\Template\TemplateItem;
use App\Services\Template\Enums\TemplateCategory;
use Illuminate\Console\Command;
use Illuminate\Support\Collection;

/**
 *
 */
class SetTemplateItemsOrderNumber extends Command
{
    /**
     * @var string
     */
    protected $signature = 'tmp:set-template-items-order-number {--all} {--templateId=}';

    /**
     * @var string
     */
    protected $description = 'Command description';

    /**
     * @return void
     */
    public function handle(): void
    {
        $templateId = $this->option('templateId');
        $all = $this->option('all');

        if ($this->confirm('Are you sure you want to run this command?')) {
            if ($templateId) {
                $template = Template::findOrFail($templateId);
                $this->info("Template: " . $template->name);
                $this->handleTemplate($template);
                $this->info("Done");
            } else if ($all) {
                $templates = Template::where("category", TemplateCategory::COMPLEX)->get();

                foreach ($templates as $template) {
                    $this->info("Template: " . $template->name);
                    $this->handleTemplate($template);
                }

                $this->info("Done");
            } else {
                $this->error('Please provide templateId or --all option');
            }
        }
    }


    /**
     * @param Template $template
     * @return void
     */
    private function handleTemplate(Template $template): void
    {
        $items = $template->items()
            ->where('parent_item_id', null)
            ->with("nestedItems")
            ->get();

        $this->setItemsOrderNumber($items);
    }


    /**
     * @param Collection<TemplateItem> $items
     * @return void
     */
    public function setItemsOrderNumber(Collection $items): void
    {
        $number = 0;
        foreach ($items as $item) {

            $item->order_number = $number;
            $item->save();

            if ($item->nestedItems->count() > 0) {
                $this->setItemsOrderNumber($item->nestedItems);
            }

            ++$number;
        }
    }
}
