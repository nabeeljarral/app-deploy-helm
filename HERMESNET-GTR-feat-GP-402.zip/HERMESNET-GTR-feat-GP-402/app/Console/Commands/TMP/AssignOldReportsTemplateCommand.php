<?php

namespace App\Console\Commands\TMP;

use App\Models\Environment;
use App\Models\Template\Template;
use App\Services\Dashboard\Enums\DashboardType;
use Illuminate\Console\Command;

class AssignOldReportsTemplateCommand extends Command
{
    protected $signature = 'tmp:assign-old-reports-template';

    protected $description = 'Command description';

    public function handle(): void
    {
        $workspaces = Environment::whereNull('global_template_id')->get();

        foreach ($workspaces as $workspace) {
            $summaryReport = $workspace->dashboards()->where("type", DashboardType::SUMMARY_DASHBOARD)->first();
            if (!$summaryReport || !$summaryReport->template_id) {
                continue;
            }
            $summaryTemplate = Template::where("gd_file_id", $summaryReport->template_id)
                ->where("type", DashboardType::SUMMARY_DASHBOARD)
                ->first();

            if (!$summaryTemplate) {
                continue;
            }

            $summaryReport->global_template_id = $summaryTemplate->id;
            $summaryReport->save();

            $workspace->global_template_id = $summaryTemplate->id;
            $workspace->save();

            $dataCollections = $workspace->dashboards()
                ->whereNull("global_template_id")
                ->whereNotNull("template_id")
                ->where("type", DashboardType::DASHBOARD)
                ->get();

            foreach ($dataCollections as $dashboard) {
                $template = Template::where("gd_file_id", $dashboard->template_id)
                    ->where("type", DashboardType::DASHBOARD)
                    ->first();

                if (!$template) {
                    continue;
                }

                $dashboard->global_template_id = $template->id;
                $dashboard->save();
            }
        }
    }
}
