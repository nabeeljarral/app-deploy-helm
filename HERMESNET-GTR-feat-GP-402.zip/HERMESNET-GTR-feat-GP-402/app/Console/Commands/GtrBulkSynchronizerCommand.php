<?php

namespace App\Console\Commands;

use App\Models\Environment;
use App\Models\Organization;
use App\Services\GtrSync\Requests\GtrSyncSystemDataRequest;
use App\Utils\LoggerUtil;
use Illuminate\Console\Command;

/**
 * GP-341 Bulk GTR data synchronization
 */
class GtrBulkSynchronizerCommand extends Command
{
    /**
     * @var string
     */
    protected $signature = 'gtr:bulk-synchronizer';

    /**
     * @var string
     */
    protected $description = 'GP-341 Bulk GTR data synchronization';

    /**
     * @return void
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function handle(): void
    {
        $this->confirm("Are you sure you want to continue?");
        try {
            $this->info("Sending request...");

            $payload = $this->prepareRequestPayload();
            (new GtrSyncSystemDataRequest($payload, 'Organizations'))->run();

            $this->info("Done. " . count($payload) . ' organizations sent.', 'info');
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            $this->error("Error:" . $exception->getMessage(), 'error');
        }
    }

    /**
     * @return array
     */
    private function prepareRequestPayload(): array
    {
        $organizations = [];

        foreach (Organization::all() as $organization) {
            $workspaces = $this->getOrgWorkspaces($organization) ?? [];
            $organizations[] = [
                'OrganizationID'   => $organization->id,
                'OrganizationName' => $organization->organization_name,
                'Country'          => $organization->country,
                'Workspaces'       => $workspaces,
            ];
        }

        return $organizations;
    }

    /**
     * @param Organization $organization
     * @return array|null
     */
    private function getOrgWorkspaces(Organization $organization): ?array
    {
        $workspaces = Environment::query()
            ->with("dashboards")
            ->where('organization_id', $organization->id)
            ->get();

        if ($workspaces->isEmpty()) {
            return null;
        }

        $result = [];
        foreach ($workspaces as $workspace) {
            $reports = $this->getWorkspaceReports($workspace) ?? [];
            $result[] = [
                "WorkspaceID"   => $workspace->id,
                "WorkspaceName" => $workspace->name,
                "Country"       => $workspace->country,
                "City"          => $workspace->city,
                "Reports"       => $reports,
            ];
        }

        return $result;
    }

    /**
     * @param Environment $environment
     * @return array|null
     */
    private function getWorkspaceReports(Environment $environment): ?array
    {
        $result = [];
        foreach ($environment->dashboards as $dashboard) {
            $result[] = [
                "ReportID"   => $dashboard->id,
                "ReportName" => $dashboard->name,
                "Country"    => $dashboard->country,
                "City"       => $dashboard->city,
            ];
        }
        return $result;
    }
}
