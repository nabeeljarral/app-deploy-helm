<?php

namespace App\Transformers\Configuration;

use App\Models\Template\TemplateConfiguration;
use App\Transformers\OrganizationTransformer;
use App\Transformers\Templates\LookupTemplateTransformer;
use App\Utils\TransformersUtil;
use League\Fractal\Resource\Item;
use League\Fractal\TransformerAbstract;

/**
 *
 */
class ConfigurationTransformer extends TransformerAbstract
{
    /**
     * @var array
     */
    protected array $defaultIncludes = [];

    /**
     * @var array|string[]
     */
    protected array $availableIncludes = ['template'];

    /**
     * @param TemplateConfiguration $templateConfiguration
     * @return array
     */
    public function transform(TemplateConfiguration $templateConfiguration): array
    {
        return [
            'id'                   => (string)$templateConfiguration->id,
            'template_id'          => (string)$templateConfiguration->template_id,
            'organization_id'      => (string)$templateConfiguration->organization_id,
            'name'                 => $templateConfiguration->name,
            'guidance'             => $templateConfiguration->guidance,
            'is_general'           => (bool)$templateConfiguration->is_general,
            'is_published'         => (bool)$templateConfiguration->is_published,
            'created_at'           => $templateConfiguration->created_at,
            'updated_at'           => $templateConfiguration->updated_at,
            'created_at_formatted' => TransformersUtil::dateTimeFormatted($templateConfiguration->created_at),
            'updated_at_formatted' => TransformersUtil::dateTimeFormatted($templateConfiguration->updated_at),
        ];
    }

    /**
     * @param TemplateConfiguration $templateConfiguration
     * @return Item
     */
    public function includeTemplate(TemplateConfiguration $templateConfiguration): Item
    {
        return $this->item($templateConfiguration->template, new LookupTemplateTransformer);
    }
}
