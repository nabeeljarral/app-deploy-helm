<?php

namespace App\Transformers\Configuration\Item;

use App\Models\Views\ConfigurationItemsView;
use League\Fractal\Resource\Collection;
use League\Fractal\Resource\Item;
use League\Fractal\TransformerAbstract;

/**
 *
 */
class PrintingNestedItemsTransformer extends TransformerAbstract
{

    /**
     * @var string
     */
    protected string $relationName = "items";

    /**
     * @var array|string[]
     */
    protected array $defaultIncludes = ['items'];

    /**
     * @var array
     */
    protected array $availableIncludes = [];

    /**
     * @param ConfigurationItemsView $item
     * @return array
     */
    public function transform(ConfigurationItemsView $item): array
    {
        $result = [
            'name'               => $item->name,
            'included'           => $item->is_included,
        ];

        if ($item->reason_of_omission) {
            $result['omission_reason'] = $item->reason_of_omission;
        }

        if ($item->use_google_sheet) {
            $result['tab'] = $item->sheet_name ?? null;
        }else {
            $result['content'] = $item->content ?? null;
        }

        return $result;
    }

    /**
     * @param ConfigurationItemsView $configurationItemsView
     * @return Collection
     */
    public function includeItems(ConfigurationItemsView $configurationItemsView): Collection
    {
        return $this->collection($configurationItemsView->{$this->relationName}, new PrintingNestedItemsTransformer, $this->relationName);
    }

    /**
     * @return string
     */
    public function getRelationName(): string
    {
        return $this->relationName;
    }
}
