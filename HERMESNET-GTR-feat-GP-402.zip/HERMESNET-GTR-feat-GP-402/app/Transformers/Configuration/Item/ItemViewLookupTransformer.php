<?php

namespace App\Transformers\Configuration\Item;

use App\Models\Views\ConfigurationItemsView;
use League\Fractal\TransformerAbstract;

/**
 *
 */
class ItemViewLookupTransformer extends TransformerAbstract
{
    /**
     * @var array
     */
    protected array $defaultIncludes = [];

    /**
     * @var array
     */
    protected array $availableIncludes = [];

    /**
     * @param ConfigurationItemsView $configurationItem
     * @return array
     */
    public function transform(ConfigurationItemsView $configurationItem): array
    {
        return [
            'id'               => (string)$configurationItem->id,
            'configuration_id' => (string)$configurationItem->configuration_id,
            'report_id'        => (string)$configurationItem->report_id,
            'item_id'          => (string)$configurationItem->item_id,
            'is_included'      => (bool)$configurationItem->is_included,
            'order_number'     => $configurationItem->order_number,
            'mandatory'        => (bool)$configurationItem->mandatory,
            'has_content'      => $configurationItem->use_google_sheet ? !!$configurationItem->sheet_name : !!$configurationItem->content,
            'use_google_sheet' => $configurationItem->use_google_sheet,
        ];
    }
}
