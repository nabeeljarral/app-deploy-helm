<?php

namespace App\Transformers\Configuration\Item;

use App\Models\ConfigurationItem;
use App\Presenters\Configuration\ConfigurationItemPathPresenter;
use App\Transformers\Configuration\ConfigurationTransformer;
use App\Transformers\DashboardTransformer;
use App\Transformers\Templates\TemplateItemTransformer;
use League\Fractal\Resource\Item;
use League\Fractal\TransformerAbstract;

/**
 *
 */
class ItemTransformer extends TransformerAbstract
{
    /**
     * @var array
     */
    protected array $defaultIncludes = [];

    /**
     * @var array|string[]
     */
    protected array $availableIncludes = ['configuration', 'report', 'templateItem'];

    /**
     * @var bool
     */
    private bool $withItemPath = true;

    /**
     * @param ConfigurationItem $configurationItem
     * @return array
     */
    public function transform(ConfigurationItem $configurationItem): array
    {
        $result = [
            'id'                 => (string)$configurationItem->id,
            'configuration_id'   => (string)$configurationItem->configuration_id,
            'report_id'          => (string)$configurationItem->report_id,
            'item_id'            => (string)$configurationItem->item_id,
            'is_included'        => (bool)$configurationItem->is_included,
            'reason_of_omission' => $configurationItem->reason_of_omission,
            'content'            => $configurationItem->content,
            'created_at'         => $configurationItem->created_at,
            'updated_at'         => $configurationItem->updated_at,
        ];

        if ($this->withItemPath) {
            $result['path'] = (new ConfigurationItemPathPresenter($configurationItem))->present();
        }

        return $result;
    }

    /**
     * @param ConfigurationItem $configurationItem
     * @return Item
     */
    public function includeConfiguration(ConfigurationItem $configurationItem): Item
    {
        return $this->item($configurationItem->configuration, new ConfigurationTransformer);
    }

    /**
     * @param ConfigurationItem $configurationItem
     * @return Item
     */
    public function includeReport(ConfigurationItem $configurationItem): Item
    {
        return $this->item($configurationItem->report, new DashboardTransformer);
    }

    /**
     * @param ConfigurationItem $configurationItem
     * @return Item
     */
    public function includeTemplateItem(ConfigurationItem $configurationItem): Item
    {
        return $this->item($configurationItem->templateItem, new TemplateItemTransformer);
    }

    /**
     * @param bool $withItemPath
     */
    public function setWithItemPath(bool $withItemPath): void
    {
        $this->withItemPath = $withItemPath;
    }
}
