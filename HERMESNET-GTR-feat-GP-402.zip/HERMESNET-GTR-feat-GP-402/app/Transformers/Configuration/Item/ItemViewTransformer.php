<?php

namespace App\Transformers\Configuration\Item;

use App\Models\Views\ConfigurationItemsView;
use League\Fractal\TransformerAbstract;

/**
 *
 */
class ItemViewTransformer extends TransformerAbstract
{
    /**
     * @var array
     */
    protected array $defaultIncludes = [];

    /**
     * @var array
     */
    protected array $availableIncludes = [];

    /**
     * @param ConfigurationItemsView $configurationItemsViewsView
     * @return array
     */
    public function transform(ConfigurationItemsView $configurationItemsViewsView): array
    {
        return [
            'id'                 => (string)$configurationItemsViewsView->id,
            'template_id'        => (string)$configurationItemsViewsView->template_id,
            'configuration_id'   => (string)$configurationItemsViewsView->configuration_id,
            'is_included'        => (bool)$configurationItemsViewsView->is_included,
            'report_id'          => (string)$configurationItemsViewsView->report_id,
            'name'               => (string)$configurationItemsViewsView->name,
            'reason_of_omission' => (string)$configurationItemsViewsView->reason_of_omission,
            'mandatory'          => (bool)$configurationItemsViewsView->mandatory,
            'sheet_name'         => (string)$configurationItemsViewsView->sheet_name,
            'parent_item_id'     => (string)$configurationItemsViewsView->parent_item_id,
            'item_id'            => (string)$configurationItemsViewsView->item_id,
            'order_number'       => $configurationItemsViewsView->order_number,
            'created_at'         => $configurationItemsViewsView->created_at,
            'updated_at'         => $configurationItemsViewsView->updated_at,
            'has_content'        => $configurationItemsViewsView->use_google_sheet ? !!$configurationItemsViewsView->sheet_name : !!$configurationItemsViewsView->content,
            'use_google_sheet' => $configurationItemsViewsView->use_google_sheet,
        ];
    }
}
