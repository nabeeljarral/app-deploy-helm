<?php

namespace App\Transformers\Configuration\Item;

use App\Models\Views\ConfigurationItemsView;
use League\Fractal\Resource\Collection;
use League\Fractal\Resource\Item;
use League\Fractal\TransformerAbstract;

/**
 *
 */
class NestedItemsTransformer extends TransformerAbstract
{

    /**
     * @var string
     */
    protected string $relationName = "nestedItems";

    /**
     * @var array|string[]
     */
    protected array $defaultIncludes = ['nestedItems', 'parentItem'];

    /**
     * @var array
     */
    protected array $availableIncludes = [];

    /**
     * @param ConfigurationItemsView $item
     * @return array
     */
    public function transform(ConfigurationItemsView $item): array
    {
        return [
            'id'                 => (string)$item->id,
            'item_id'            => (string)$item->item_id,
            'configuration_id'   => (string)$item->configuration_id,
            'template_id'        => (string)$item->template_id,
            'report_id'          => (string)$item->report_id,
            'parent_item_id'     => (string)$item->parent_item_id,
            'requirements'       => $item->requirements,
            'recommendations'    => $item->recommendations,
            'guidance'           => $item->guidance,
            'name'               => $item->name,
            'is_included'        => (bool)$item->is_included,
            'order_number'       => $item->order_number,
            'mandatory'          => (bool)$item->mandatory,
            'reason_of_omission' => $item->reason_of_omission,
            'has_content'        => $item->use_google_sheet ? !!$item->sheet_name : !!$item->content,
            'use_google_sheet'   => $item->use_google_sheet,
            'content_type'       => $item->content_type,
        ];
    }

    /**
     * @param ConfigurationItemsView $configurationItemsView
     * @return Collection
     */
    public function includeNestedItems(ConfigurationItemsView $configurationItemsView): Collection
    {
        return $this->collection($configurationItemsView->{$this->relationName}, new NestedItemsTransformer, $this->relationName);
    }

    /**
     * @param ConfigurationItemsView $configurationItemsView
     * @return Item|null
     */
    public function includeParentItem(ConfigurationItemsView $configurationItemsView): ?Item
    {
        if ($configurationItemsView->parentItem) {
            return $this->item($configurationItemsView->parentItem, new ItemViewLookupTransformer);
        }
        return null;
    }

    /**
     * @return string
     */
    public function getRelationName(): string
    {
        return $this->relationName;
    }
}
