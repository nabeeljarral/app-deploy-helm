<?php

namespace App\Transformers;

use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardUser;
use App\Models\Environment;
use App\Presenters\EnvironmentDashboardsPresenter;
use App\Presenters\EnvironmentsPresenter;
use App\Presenters\Template\WorkspaceDcTemplatesPresenter;
use App\Services\User\Enums\UserRole;
use App\Transformers\Templates\LookupTemplateTransformer;
use App\Utils\AvatarUtil;
use League\Fractal\ParamBag;
use League\Fractal\Resource\Collection;
use League\Fractal\TransformerAbstract;
use League\Fractal\Resource\Item;

/**
 *
 */
class EnvironmentTransformer extends TransformerAbstract
{
    /**
     * @var array|string[]
     */
    private array $validParams = ['includesResourceKey'];

    /**
     * @var array|string[]
     */
    protected array $defaultIncludes = ["template"];

    /**
     * @var array|string[]
     */
    protected array $availableIncludes = ["dashboards", "template", "dataCollectionTemplates"];

    /**
     * @var bool
     */
    protected bool $includeCurrentRole = false;

    /**
     * @var bool
     */
    protected bool $includeUsersCount = false;

    /**
     * @param Environment $environment
     * @return array
     */
    public function transform(Environment $environment): array
    {
        $result = [
            'id'                    => (int)$environment->id,
            'organization_id'       => (int)$environment->organization_id,
            'name'                  => $environment->name,
            'name_formatted'        => \Str::limit($environment->name, 40),
            "short_name"            => AvatarUtil::getShortName($environment->name),
            'folder_id'             => $environment->folder_id,
            "color"                 => $environment->color,
            'created_at'            => $environment->created_at,
            'updated_at'            => $environment->updated_at,
            'template_id'           => $environment->global_template_id,
            'dashboards_count'      => $this->dashboardsCount($environment),
            'dashboard_users_count' => $environment->dashboard_users_count ?? 0,
            'updated_at_formatted'  => $this->getUpdatedAtFormatted($environment),
            'users_statistics'      => $this->usersStatistics($environment),
            'country'               => $environment->country,
            'city'                  => $environment->city,
        ];

        if ($this->includeUsersCount) {
            $result['users_count'] = $this->userCount($environment);
        }

        if ($this->includeCurrentRole) {
            $result["current_role"] = $this->getCurrentRole($environment);
        }

        return $result;
    }

    /**
     * @param Environment $environment
     * @param ParamBag $paramBag
     * @return Collection
     */
    public function includeDashboards(Environment $environment, ParamBag $paramBag): Collection
    {
        return $this->collection($environment->dashboards, new DashboardTransformer)
            ->setResourceKey(\Arr::get($paramBag->get('includesResourceKey'), 0, ''));
    }

    /**
     * @param Environment $environment
     * @param ParamBag $paramBag
     * @return Item|null
     */
    public function includeTemplate(Environment $environment, ParamBag $paramBag): ?Item
    {
        if ($environment->globalTemplate) {
            return $this->item($environment->globalTemplate, new LookupTemplateTransformer())
                ->setResourceKey(\Arr::get($paramBag->get('includesResourceKey'), 0, ''));
        }

        return null;
    }

    /**
     * @param Environment $environment
     * @return Collection
     */
    public function includeDataCollectionTemplates(Environment $environment, ParamBag $paramBag): Collection
    {
        $category = null;
        if ($environment->globalTemplate) {
            $category = $environment->globalTemplate->category;
        }
        $templates = (new WorkspaceDcTemplatesPresenter($environment, $category))->present();
        return $this->collection($templates, new LookupTemplateTransformer())
            ->setResourceKey(\Arr::get($paramBag->get('includesResourceKey'), 0, ''));
    }

    /**
     * @param bool $includeCurrentRole
     */
    public function setIncludeCurrentRole(bool $includeCurrentRole): void
    {
        $this->includeCurrentRole = $includeCurrentRole;
    }

    /**
     * @param bool $includeUsersCount
     */
    public function setIncludeUsersCount(bool $includeUsersCount): void
    {
        $this->includeUsersCount = $includeUsersCount;
    }

    /**
     * User role in current environment
     * @param Environment $environment
     * @return string|null
     */
    private function getCurrentRole(Environment $environment): ?string
    {
        $userRoles = DashboardUser::where("user_id", \Auth::id())
            ->select('role')
            ->where("environment_id", $environment->id)
            ->get()
            ->pluck("role")
            ->toArray();

        if (empty($userRoles)) {
            return null;
        }

        return UserRole::getMaxRoleOf($userRoles);
    }

    /**
     * @param Environment $environment
     * @return int
     */
    private function dashboardsCount(Environment $environment): int
    {
        try {
            $dashboards = (new EnvironmentDashboardsPresenter(\Auth::user(), $environment->id))->present();
            return $dashboards->count();
        } catch (\Exception $exception) {
            return 0;
        }
    }

    /**
     * @param Environment $environment
     * @return int
     */
    private function userCount(Environment $environment): int
    {
        $envOwners = $environment->organization
            ->users()
            ->select('id')
            ->where('role', UserRole::ENVIRONMENT_OWNER)
            ->get()
            ->pluck('id')
            ->toArray();

        $dashboardsUsers = $environment->dashboardUsers()
            ->select('user_id')
            ->get()
            ->pluck('user_id')
            ->toArray();


        $users = array_merge($envOwners, $dashboardsUsers);
        $users = array_unique($users);

        return count($users);
    }

    /**
     * @param Environment $environment
     * @return string
     */
    private function getUpdatedAtFormatted(Environment $environment): string
    {
        if ($environment->updated_at->diffInHours() >= 24) {
            return $environment->updated_at->format("M d, Y");
        } else {
            return $environment->updated_at->diffForHumans();
        }
    }

    /**
     * @param Environment $environment
     * @return array
     */
    private function usersStatistics(Environment $environment): array
    {
        return DashboardUser::where("environment_id", $environment->id)
            ->select("role")
            ->selectRaw("COUNT(role) as count")
            ->groupBy("role")
            ->get()
            ->pluck("count", 'role')
            ->toArray();
    }
}
