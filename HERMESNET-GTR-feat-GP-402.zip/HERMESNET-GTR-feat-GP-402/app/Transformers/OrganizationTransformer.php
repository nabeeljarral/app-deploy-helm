<?php

namespace App\Transformers;

use App\Models\Organization;
use League\Fractal\Resource\Collection;
use League\Fractal\TransformerAbstract;

/**
 *
 */
class OrganizationTransformer extends TransformerAbstract
{
    /**
     * @var array
     */
    protected array $defaultIncludes = [];

    /**
     * @var array|string[]
     */
    protected array $availableIncludes = ['environments', 'getEnvironmentOwners', 'users'];

    /**
     * @param Organization $organization
     * @return array
     */
    public function transform(Organization $organization): array
    {
        $trialDaysLeft = $this->trialPeriodDaysLeft($organization);
        $trialLeftLabel = ($trialDaysLeft > 0)
            ? $trialDaysLeft . ' ' . \Str::plural('day', $trialDaysLeft) . ' left'
            : 'The trial has ended';

        return [
            'id'                         => (int)$organization->id,
            'organization_name'          => $organization->organization_name,
            'countries'                  => $organization->countries,
            'country'                    => $organization->country,
            'city'                       => $organization->city,
            'report_period'              => $organization->report_period,
            'number_of_employees'        => $organization->number_of_employees,
            'user_id'                    => (int)$organization->user_id,
            'drive_folder_id'            => $organization->drive_folder_id,
            'created_at'                 => $organization->created_at,
            'updated_at'                 => $organization->updated_at,
            'is_trial_access'            => $organization->is_trial_access,
            'trial_expired_at'           => $organization->trial_expired_at,
            'created_at_formatted'       => $organization->created_at->format("M d, Y"),
            'updated_at_formatted'       => $organization->updated_at->format("M d, Y"),
            'trial_expired_at_formatted' => ($organization->trial_expired_at) ? $organization->trial_expired_at->format("M d, Y") : '-',
            'trial_days_left'            => $trialDaysLeft,
            'trial_left_label'           => $trialLeftLabel,
        ];
    }

    /**
     * @param Organization $organization
     * @return int
     */
    private function trialPeriodDaysLeft(Organization $organization): int
    {
        if (!$organization->trial_expired_at || $organization->trial_expired_at < now()) {
            return 0;
        }
        $daysLeft = now()->floatDiffInDays($organization->trial_expired_at);
        return ceil($daysLeft);
    }

    /**
     * @param Organization $organization
     * @return Collection
     */
    public function includeEnvironments(Organization $organization): Collection
    {
        return $this->collection($organization->environments, new EnvironmentTransformer);
    }

    /**
     * @param Organization $organization
     * @return Collection
     */
    public function includeGetEnvironmentOwners(Organization $organization): Collection
    {
        return $this->collection($organization->getEnvironmentOwners, new UserTransformer);
    }

    /**
     * @param Organization $organization
     * @return Collection
     */
    public function includeUsers(Organization $organization): Collection
    {
        return $this->collection($organization->users, new UserTransformer);
    }
}
