<?php

namespace App\Transformers;

use App\Models\Dashboard\DashboardUser;
use League\Fractal\Resource\Item;
use League\Fractal\TransformerAbstract;

class UserPermissionsTransformer extends TransformerAbstract
{
    protected array $defaultIncludes = [];

    protected array $availableIncludes = [];

    public function transform(DashboardUser $dashboardUser): array
    {
        return [
            'id'                         => (string)$dashboardUser->id,
            'user_id'                    => (string)$dashboardUser->user_id,
            'environment_id'             => (string)$dashboardUser->environment_id,
            'dashboard_id'               => (string)$dashboardUser->dashboard_id,
            'role'                       => $dashboardUser->role,
            'drive_role'                 => $dashboardUser->drive_role,
            'permissions_id'             => $dashboardUser->permissions_id,
            'environment_name'           => $dashboardUser->environment_name ?? null,
            'environment_name_formatted' => \Str::limit($dashboardUser->environment_name ?? '', 30),
            'environment_color'          => $dashboardUser->environment_color ?? null,
            'dashboard_name'             => $dashboardUser->dashboard_name ?? null,
            'dashboard_name_formatted'   => \Str::limit($dashboardUser->dashboard_name ?? '', 30),
            'created_at'                 => $dashboardUser->created_at,
            'updated_at'                 => $dashboardUser->updated_at,
        ];
    }
}
