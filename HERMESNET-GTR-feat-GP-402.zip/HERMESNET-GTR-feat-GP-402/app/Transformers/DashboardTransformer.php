<?php

namespace App\Transformers;

use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardUser;
use App\Services\User\GetUserEntryRole;
use App\Transformers\Configuration\ConfigurationTransformer;
use App\Transformers\Configuration\Item\ItemTransformer;
use App\Transformers\PrintConfiguration\PrintConfTemplateTransformer;
use App\Transformers\Templates\LookupTemplateTransformer;
use App\Transformers\Templates\TemplateAnalyticsTransformer;
use App\Utils\TransformersUtil;
use League\Fractal\ParamBag;
use League\Fractal\Resource\Item;
use App\Presenters\EnvironmentDashboardsPresenter;
use App\Services\User\Enums\UserRole;
use League\Fractal\Resource\Collection;
use League\Fractal\TransformerAbstract;

/**
 *
 */
class DashboardTransformer extends TransformerAbstract
{
    /**
     * @var array
     */
    protected array $defaultIncludes = ["template", "sheets"];

    /**
     * @var array
     */
    protected array $availableIncludes = [
        "sheets",
        "environment",
        "template",
        "configuration",
        "analyticsTabs",
        "items",
        "printConfigurations"
    ];

    /**
     * @param Dashboard $dashboard
     * @return array
     */
    public function transform(Dashboard $dashboard): array
    {
        /**
         * User role in current dashboard\dashboards
         * @var $currentRole string
         * @see EnvironmentDashboardsPresenter
         */
        $currentRole = $this->getCurrentRole($dashboard);

        return [
            'id'                   => (string)$dashboard->id,
            'name'                 => $dashboard->name,
            'type'                 => $dashboard->type,
            'city'                 => $dashboard->city,
            'country'              => $dashboard->country,
            'environment_id'       => (int)$dashboard->environment_id,
            'template_id'          => $dashboard->global_template_id,
            'template_name'        => $dashboard->template_name,
            'file_id'              => $dashboard->file_id,
            'index_sheet'          => $dashboard->index_sheet,
            'current_role'         => $currentRole,
            'configuration_id'     => $dashboard->configuration_id,
            'status'               => $dashboard->status,
            'color'                => $dashboard->color,
            'created_at'           => $dashboard->created_at,
            'updated_at'           => $dashboard->updated_at,
            'updated_at_formatted' => TransformersUtil::dateTimeFormatted($dashboard->updated_at),
        ];
    }

    /**
     * @param Dashboard $dashboard
     * @return Collection
     */
    public function includeSheets(Dashboard $dashboard): Collection
    {
        return $this->collection($dashboard->sheets, new DashboardSheetTransformer());
    }

    /**
     * @param Dashboard $dashboard
     * @return Item
     */
    public function includeEnvironment(Dashboard $dashboard): Item
    {
        return $this->item($dashboard->environment, new EnvironmentTransformer());
    }

    /**
     *
     * @param Dashboard $dashboard
     * @return string|null
     */
    private function getCurrentRole(Dashboard $dashboard): ?string
    {
        if (!\Auth::check()) {
            return null;
        }
        return GetUserEntryRole::get(\Auth::user(), $dashboard, true);
    }

    /**
     * @param Dashboard $dashboard
     * @return Item|null
     */
    public function includeTemplate(Dashboard $dashboard): ?Item
    {
        if ($dashboard->globalTemplate) {
            return $this->item($dashboard->globalTemplate, new LookupTemplateTransformer());
        }

        return null;
    }

    /**
     * @param Dashboard $dashboard
     * @return Item|null
     */
    public function includeConfiguration(Dashboard $dashboard): ?Item
    {
        if ($dashboard->configuration_id) {
            return $this->item($dashboard->configuration, new ConfigurationTransformer());
        }

        return null;
    }

    /**
     * @param Dashboard $dashboard
     * @return Collection|null
     */
    public function includeAnalyticsTabs(Dashboard $dashboard): ?Collection
    {
        if ($dashboard->global_template_id) {
            return $this->collection($dashboard->analyticsTabs, new TemplateAnalyticsTransformer());
        }

        return null;
    }

    public function includeItems(Dashboard $dashboard): Collection
    {
        $itemsTransformer = new ItemTransformer();
        $itemsTransformer->setWithItemPath(false);

        return $this->collection($dashboard->items, $itemsTransformer);
    }

    /**
     * @param Dashboard $dashboard
     * @param ParamBag $paramBag
     * @return Collection|null
     */
    public function includePrintConfigurations(Dashboard $dashboard, ParamBag $paramBag): ?Collection
    {
        $items = $dashboard->printConfTemplates()
            ->where("report_id", $dashboard->id);

        if ($paramBag->get('currentOrganization')) {
            $items->where('organization_id', \Auth::user()->organization_id);
        }
        $items = $items->get();

        return $this->collection($items, new PrintConfTemplateTransformer());
    }
}
