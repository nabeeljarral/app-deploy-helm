<?php

namespace App\Transformers;

use App\Models\Dashboard\Dashboard;
use App\Models\User;
use App\Services\User\Enums\UserRole;
use App\Utils\AvatarUtil;
use League\Fractal\TransformerAbstract;

/**
 *
 */
class UserTransformer extends TransformerAbstract
{
    /**
     * @var array
     */
    protected array $defaultIncludes = [];

    /**
     * @var array
     */
    protected array $availableIncludes = [];

    /**
     * @param User $user
     * @return array
     */
    public function transform(User $user): array
    {
        $registrationComplete = is_string($user->google_email);

        return [
            'id'                         => (int)$user->id,
            'name'                       => $user->name,
            'short_name'                 => AvatarUtil::getShortName($user->name),
            'email'                      => $user->email,
            'social_id'                  => $user->social_id,
            'social_type'                => $user->social_type,
            'role'                       => $user->role,
            'max_role'                   => $user->getMaxRole(),
            'google_email'               => $user->google_email,
            'organization_id'            => (int)$user->organization_id,
            'invited_from'               => (int)$user->invited_from,
            'color'                      => $user->color,
            'organization_name'          => $user->organization_name,
            'environment_name'           => $user->environment_name,
            'dashboard_name'             => $user->dashboard_name,
            'registrationComplete'       => $registrationComplete,
            'is_admin'                   => $user->is_admin,
            'is_templates_admin'         => $user->is_templates_admin,
            'created_at'                 => $user->created_at,
            'updated_at'                 => $user->updated_at,
            'last_activity_at'           => $user->last_activity_at,
            'last_activity_at_formatted' => $this->getLastActivityFormatted($user),
            'created_at_formatted'       => $user->created_at->format("M d, Y"),
            'updated_at_formatted'       => $user->updated_at->format("M d, Y"),
        ];
    }

    /**
     * @param User $user
     * @return string
     */
    private function getLastActivityFormatted(User $user): string
    {
        if (!$user->last_activity_at) {
            return '';
        }

        if ($user->last_activity_at->diffInHours() >= 24) {
            return $user->last_activity_at->format("M d, Y");
        } else {
            return $user->last_activity_at->diffForHumans();
        }
    }
}
