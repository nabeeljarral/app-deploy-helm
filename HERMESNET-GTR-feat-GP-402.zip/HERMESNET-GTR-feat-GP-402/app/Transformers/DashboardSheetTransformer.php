<?php

namespace App\Transformers;

use App\Models\Dashboard\DashboardSheet;
use League\Fractal\Resource\Item;
use League\Fractal\TransformerAbstract;

/**
 *
 */
class DashboardSheetTransformer extends TransformerAbstract
{
    /**
     * @var array
     */
    protected array $defaultIncludes = [];

    /**
     * @var array|string[]
     */
    protected array $availableIncludes = [];

    /**
     * @param DashboardSheet $dashboardSheet
     * @return array
     */
    public function transform(DashboardSheet $dashboardSheet): array
    {
        return [
            'id'           => (int)$dashboardSheet->id,
            'dashboard_id' => (int)$dashboardSheet->dashboard_id,
            'type'         => $dashboardSheet->type,
            'sheet_title'  => $dashboardSheet->sheet_title,
            'sheet_id'     => $dashboardSheet->sheet_id,
            'sheet_type'   => $dashboardSheet->sheet_type,
            'created_at'   => $dashboardSheet->created_at,
            'updated_at'   => $dashboardSheet->updated_at,
        ];
    }
}
