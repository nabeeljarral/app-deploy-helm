<?php

namespace App\Transformers\PrintConfiguration;

use App\Models\Organization;
use App\Models\PrintConfTemplate;
use App\Services\Template\Actions\FetchTemplateSheets;
use App\Utils\LoggerUtil;
use App\Utils\TransformersUtil;
use League\Fractal\Resource\Collection;
use League\Fractal\TransformerAbstract;
use Spatie\Fractalistic\ArraySerializer;

/**
 *
 */
class PrintConfTemplateTransformer extends TransformerAbstract
{
    /**
     * @var string[]
     */
    protected array $defaultIncludes = [];

    /**
     * @var string[]
     */
    protected array $availableIncludes = ['elements'];

    /**
     * @param PrintConfTemplate $template
     * @return array
     */
    public function transform(PrintConfTemplate $printConfTemplate): array
    {
        $displayName = $printConfTemplate->template_name;
        $organization = Organization::find($printConfTemplate->organization_id);
        if ($organization) {
            $displayName = $organization->organization_name . ' - ' . $displayName;
        }

        return [
            'id'                   => (string) $printConfTemplate->id,
            'template_name'        => $printConfTemplate->template_name,
            'display_name'        => $displayName,
            'is_blank'             => (boolean) $printConfTemplate->is_blank,
            'template_id'          => is_null($printConfTemplate->template_id) ? null : (string) $printConfTemplate->template_id,
            'report_id'            => is_null($printConfTemplate->report_id) ? null : (string) $printConfTemplate->report_id,
            'organization_id'      => is_null($printConfTemplate->organization_id) ? null : (string) $printConfTemplate->organization_id,
            'created_at'           => $printConfTemplate->created_at,
            'updated_at'           => $printConfTemplate->updated_at,
            'created_at_formatted' => TransformersUtil::dateTimeFormatted($printConfTemplate->created_at),
            'updated_at_formatted' => TransformersUtil::dateTimeFormatted($printConfTemplate->updated_at),
        ];
    }

    /**
     * @param PrintConfTemplate $printConfTemplate
     * @return Collection
     */
    public function includeElements(PrintConfTemplate $printConfTemplate): Collection
    {
        return $this->collection($printConfTemplate->elements, new PrintConfElementTransformer);
    }

}
