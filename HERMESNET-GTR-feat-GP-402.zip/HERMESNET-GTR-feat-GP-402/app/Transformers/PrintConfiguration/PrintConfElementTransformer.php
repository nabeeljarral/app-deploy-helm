<?php

namespace App\Transformers\PrintConfiguration;

use App\Models\PrintConfElement;
use App\Models\Template\TemplateItem;
use League\Fractal\Resource\Collection;
use League\Fractal\TransformerAbstract;

/**
 *
 */
class PrintConfElementTransformer extends TransformerAbstract
{

    /**
     * @var string[]
     */
    protected array $defaultIncludes = ['parameters', 'elements'];

    /**
     * @var string[]
     */
    protected array $availableIncludes = [];

    /**
     * @param PrintConfElement $confElement
     * @return array
     */
    public function transform(PrintConfElement $confElement): array
    {
        return [
            'id'                    => (string) $confElement->id,
            'name'                  => $confElement->name,
            'title'                 => $confElement->title,
            'embeds'                => $confElement->embeds,
            'default_embeds'        => $confElement->default_embeds,
            'is_mandatory'          => (boolean) $confElement->is_mandatory,
            'is_single'             => (boolean) $confElement->is_single,
            'is_default'            => (boolean) $confElement->is_default,
            'is_embeddable'         => (boolean) $confElement->is_embeddable,
            'is_parent'             => (boolean) $confElement->is_parent,
            'order_number'          => (string) $confElement->order_number,
            'print_conf_element_id' => (string) $confElement->print_conf_element_id,
            'print_conf_template_id'=> (string) $confElement->print_conf_template_id
        ];
    }


    /**
     * @param PrintConfElement $confElement
     * @return Collection
     */
    public function includeElements(PrintConfElement $confElement): Collection
    {
        return $this->collection($confElement->elements, new PrintConfElementTransformer);
    }

    /**
     * @param PrintConfElement $confElement
     * @return Collection
     */
    public function includeParameters(PrintConfElement $confElement): Collection
    {
        return $this->collection($confElement->parameters, new PrintConfParameterTransformer);
    }
}
