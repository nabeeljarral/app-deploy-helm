<?php

namespace App\Transformers\PrintConfiguration;

use App\Models\PrintConfParameter;
use League\Fractal\Resource\Item;
use League\Fractal\TransformerAbstract;

/**
 *
 */
class PrintConfParameterTransformer extends TransformerAbstract
{

    /**
     * @var string[]
     */
    protected array $defaultIncludes = ['enum'];

    /**
     * @var string[]
     */
    protected array $availableIncludes = [];

    /**
     * @param PrintConfParameter $confParameter
     * @return array
     */
    public function transform(PrintConfParameter $confParameter): array
    {
        return [
            'id'                    => (string)$confParameter->id,
            'name'                  => $confParameter->name,
            'title'                 => $confParameter->title,
            'type'                  => $confParameter->type,
            'default_value'         => $confParameter->default_value,
            'value'                 => $confParameter->value,
            'guidance'              => $confParameter->guidance,
            'is_mandatory'          => (boolean)$confParameter->is_mandatory,
            'identity'              => (boolean)$confParameter->identity,
            'print_conf_element_id' => (string)$confParameter->print_conf_element_id,
            'print_conf_enum_id'    => (string)$confParameter->print_conf_enum_id,
            'link_source'           => (string)$confParameter->link_source,
        ];
    }

    /**
     * @param PrintConfParameter $confParameter
     * @return item|null
     */
    public function includeEnum(PrintConfParameter $confParameter)
    {
        if ($confParameter->print_conf_enum_id) {
            return $this->item($confParameter->enum, new PrintConfEnumTransformer());
        }
        return null;
    }


}
