<?php

namespace App\Transformers\PrintConfiguration;

use App\Models\PrintConfEnum;
use League\Fractal\Resource\Collection;
use League\Fractal\TransformerAbstract;

/**
 *
 */
class PrintConfEnumTransformer extends TransformerAbstract
{
    /**
     * @var array
     */
    protected array $defaultIncludes = [];

    /**
     * @var array
     */
    protected array $availableIncludes = [];


    /**
     * @param PrintConfEnum $confEnum
     * @return array
     */
    public function transform(PrintConfEnum $confEnum): array
    {
        return [
            'id'     => (string) $confEnum->id,
            'name'   => $confEnum->name,
            'values' => $confEnum->values
        ];
    }

}
