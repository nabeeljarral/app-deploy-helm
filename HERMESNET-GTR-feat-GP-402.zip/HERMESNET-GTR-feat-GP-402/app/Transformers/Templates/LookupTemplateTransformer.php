<?php

namespace App\Transformers\Templates;

use App\Models\Template\Template;
use League\Fractal\Resource\Collection;
use League\Fractal\Resource\Item;
use League\Fractal\TransformerAbstract;

/**
 *
 */
class LookupTemplateTransformer extends TransformerAbstract
{
    /**
     * @var array
     */
    protected array $defaultIncludes = [];

    /**
     * @var array
     */
    protected array $availableIncludes = ['relatedDataCollections'];

    /**
     * @param Template $template
     * @return array
     */
    public function transform(Template $template): array
    {
        return [
            'id'                                => (int)$template->id,
            'name'                              => $template->name,
            'category'                          => $template->category,
            'type'                              => $template->type,
            'is_blank'                          => (bool)$template->is_blank,
            'is_archived'                       => (bool)$template->is_archived,
            'has_preview'                       => $template->gd_preview_file_id !== null,
            'allow_aggregation_view'            => (bool)$template->allow_aggregation_view,
            'allow_report_structure_definition' => (bool)$template->allow_report_structure_definition,
        ];
    }

    /**
     * @param Template $template
     * @return Collection
     */
    public function includeRelatedDataCollections(Template $template): Collection
    {
        return $this->collection($template->relatedDataCollections, new LookupTemplateTransformer());
    }
}
