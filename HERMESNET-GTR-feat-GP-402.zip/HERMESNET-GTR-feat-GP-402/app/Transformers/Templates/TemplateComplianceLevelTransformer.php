<?php

namespace App\Transformers\Templates;

use App\Models\Template\TemplateAnalytics;
use App\Models\Template\TemplateComplianceLevel;
use League\Fractal\TransformerAbstract;

/**
 *
 */
class TemplateComplianceLevelTransformer extends TransformerAbstract
{
    /**
     * @var array
     */
    protected array $defaultIncludes = [];

    /**
     * @var array
     */
    protected array $availableIncludes = [];

    /**
     * @param TemplateComplianceLevel $templateComplianceLevel
     * @return array
     */
    public function transform(TemplateComplianceLevel $templateComplianceLevel): array
    {
        return [
            'id'           => (string) $templateComplianceLevel->id,
            'template_id'  => (string) $templateComplianceLevel->template_id,
            'name'         => $templateComplianceLevel->name,
            'guidance'     => $templateComplianceLevel->guidance,
            'icon'         => $templateComplianceLevel->icon,
            "is_trial"     => (bool) $templateComplianceLevel->is_trial,
            "is_published" => (bool) $templateComplianceLevel->is_published,
            'created_at'   => $templateComplianceLevel->created_at,
            'updated_at'   => $templateComplianceLevel->updated_at,
        ];
    }
}
