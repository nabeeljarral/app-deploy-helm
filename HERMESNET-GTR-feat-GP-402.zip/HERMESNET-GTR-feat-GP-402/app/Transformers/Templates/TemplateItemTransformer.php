<?php

namespace App\Transformers\Templates;

use App\Models\Template\TemplateItem;
use App\Presenters\Template\TemplateItemPathPresenter;
use League\Fractal\Resource\Collection;
use League\Fractal\Resource\Item;
use League\Fractal\TransformerAbstract;

/**
 *
 */
class TemplateItemTransformer extends TransformerAbstract
{
    /**
     * @var array
     */
    protected array $defaultIncludes = [];

    /**
     * @var string[]
     */
    protected array $availableIncludes = ['childItems', 'nestedItems', 'parentItem', 'template'];

    /**
     * @var bool
     */
    private bool $withItemPath = false;

    /**
     * @param TemplateItem $templateItem
     * @return array
     */
    public function transform(TemplateItem $templateItem): array
    {
        $result = [
            'id'                    => (string)$templateItem->id,
            'name'                  => $templateItem->name,
            'template_id'           => (string)$templateItem->template_id,
            'parent_item_id'        => (string)$templateItem->parent_item_id,
            'mandatory'             => (bool)$templateItem->mandatory,
            'requirements'          => $templateItem->requirements,
            'recommendations'       => $templateItem->recommendations,
            'guidance'              => $templateItem->guidance,
            'content'               => $templateItem->content,
            'custom_table_meta'     => $templateItem->custom_table_meta,
            'content_type'          => $templateItem->content_type,
            'include_in_printing'   => (bool)$templateItem->include_in_printing,
            'sheet_name'            => $templateItem->sheet_name,
            'sheet_height'          => $templateItem->sheet_height,
            'order_number'          => (int)$templateItem->order_number,
            'deleted_at'            => $templateItem->deleted_at,
            'created_at'            => $templateItem->created_at,
            'updated_at'            => $templateItem->updated_at,
        ];

        if ($this->withItemPath) {
            $result['path'] = (new TemplateItemPathPresenter($templateItem))->present();
        }

        return $result;
    }


    /**
     * @param TemplateItem $templateItem
     * @return Collection
     */
    public function includeNestedItems(TemplateItem $templateItem): Collection
    {
        return $this->collection($templateItem->nestedItems, new TemplateItemTransformer);
    }

    /**
     * @param TemplateItem $templateItem
     * @return Item
     */
    public function includeParentItem(TemplateItem $templateItem): Item
    {
        return $this->item($templateItem->parentItem, new TemplateItemTransformer);
    }

    /**
     * @param TemplateItem $templateItem
     * @return Item
     */
    public function includeTemplate(TemplateItem $templateItem): Item
    {
        return $this->item($templateItem->template, new LookupTemplateTransformer);
    }

    /**
     * @param bool $withItemPath
     */
    public function setWithItemPath(bool $withItemPath): void
    {
        $this->withItemPath = $withItemPath;
    }
}
