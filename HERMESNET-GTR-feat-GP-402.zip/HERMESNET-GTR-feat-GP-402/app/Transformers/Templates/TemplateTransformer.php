<?php

namespace App\Transformers\Templates;

use App\Models\Template\Template;
use App\Services\Template\Actions\FetchTemplateSheets;
use App\Transformers\Configuration\ConfigurationTransformer;
use App\Transformers\PrintConfiguration\PrintConfTemplateTransformer;
use App\Utils\LoggerUtil;
use App\Utils\TransformersUtil;
use League\Fractal\ParamBag;
use League\Fractal\Resource\Collection;
use League\Fractal\TransformerAbstract;

/**
 *
 */
class TemplateTransformer extends TransformerAbstract
{
    /**
     * @var array
     */
    protected array $defaultIncludes = [];

    /**
     * @var string[]
     */
    protected array $availableIncludes = ['nestedItems', 'configurations', 'printConfigurations', 'analyticsTabs', 'relatedDataCollections'];

    /**
     * @var bool
     */
    protected bool $withSheets = false;

    /**
     * @param Template $template
     * @return array
     */
    public function transform(Template $template): array
    {
        $result = [
            'id'                                => (string)$template->id,
            'name'                              => $template->name,
            'description'                       => $template->description,
            'category'                          => $template->category,
            'type'                              => $template->type,
            'is_trial'                          => (bool)$template->is_trial,
            'is_public'                         => (bool)$template->is_public,
            'is_published'                      => (bool)$template->is_published,
            'is_blank'                          => (bool)$template->is_blank,
            'is_archived'                       => (bool)$template->is_archived,
            'use_with_any_summary'              => (bool)$template->use_with_any_summary,
            'has_preview'                       => $template->gd_preview_file_id !== null,
            'gd_file_id'                        => $template->gd_file_id,
            'index_sheet'                       => $template->index_sheet,
            'gd_preview_file_id'                => $template->gd_preview_file_id,
            'hidden_connected_sheet'            => (bool)$template->hidden_connected_sheet,
            'data_sheet'                        => $template->data_sheet,
            'guidance'                          => $template->guidance,
            'allow_aggregation_view'            => (bool)$template->allow_aggregation_view,
            'allow_report_structure_definition' => (bool)$template->allow_report_structure_definition,
            'created_at'                        => $template->created_at,
            'updated_at'                        => $template->updated_at,
            'created_at_formatted'              => TransformersUtil::dateTimeFormatted($template->created_at),
            'updated_at_formatted'              => TransformersUtil::dateTimeFormatted($template->updated_at),
            'meta'                              => $this->getMeta($template),
        ];

        if ($this->withSheets) {
            $result['sheets'] = $this->getSheets($template);
        }
        return $result;
    }

    /**
     * @param Template $template
     * @return array
     */
    private function getMeta(Template $template): array
    {
        return [
            'reports_count' => $template->reports()->count(),
        ];
    }

    /**
     * @param Template $template
     * @return Collection
     */
    public function includeNestedItems(Template $template): Collection
    {
        return $this->collection($template->nestedItems, new NestedItemsTransformer);
    }

    /**
     * @param Template $template
     * @return array
     */
    private function getSheets(Template $template): array
    {
        try {
            return (new FetchTemplateSheets($template))->run();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return [];
        }
    }

    /**
     * @param bool $withSheets
     */
    public function setWithSheets(bool $withSheets): void
    {
        $this->withSheets = $withSheets;
    }

    /**
     * @param Template $template
     * @return Collection|null
     */
    public function includeConfigurations(Template $template): ?Collection
    {
        if ($template->configurations->isEmpty()) {
            return null;
        }
        return $this->collection($template->configurations, new ConfigurationTransformer);
    }

    /**
     * @param Template $template
     * @param ParamBag $paramBag
     * @return Collection|null
     */
    public function includePrintConfigurations(Template $template, ParamBag $paramBag): ?Collection
    {
        $items = $template->printConfTemplates()
            ->where("report_id", null);

        if ($paramBag->get('currentOrganization')) {
            $items->where(function ($query) {
                $query->where('organization_id', null)
                    ->orWhere('organization_id', \Auth::user()->organization_id);
            });
        }

        $items = $items->get();
        if ($items->isEmpty()) {
            return null;
        }
        return $this->collection($items, new PrintConfTemplateTransformer());
    }

    /**
     * @param Template $template
     * @return Collection|null
     */
    public function includeAnalyticsTabs(Template $template): ?Collection
    {
        return $this->collection($template->analytics, new TemplateAnalyticsTransformer());
    }

    /**
     * @param Template $template
     * @return Collection
     */
    public function includeRelatedDataCollections(Template $template): Collection
    {
        return $this->collection($template->relatedDataCollections, new LookupTemplateTransformer());
    }
}
