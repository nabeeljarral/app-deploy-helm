<?php

namespace App\Transformers\Templates;

use App\Models\Template\TemplateItem;
use League\Fractal\Resource\Collection;
use League\Fractal\TransformerAbstract;

/**
 *
 */
class NestedItemsTransformer extends TransformerAbstract
{
    /**
     * @var array
     */
    protected array $defaultIncludes = ['nestedItems'];

    protected array $availableIncludes = [];

    /**
     * @param TemplateItem $templateItem
     * @return array
     */
    public function transform(TemplateItem $templateItem): array
    {
        return [
            'id'                => (string)$templateItem->id,
            'name'              => $templateItem->name,
            'parent_item_id'    => (string)$templateItem->parent_item_id,
            'order_number'      => (int)$templateItem->order_number,
            'mandatory'         => (bool)$templateItem->mandatory,
            'requirements'      => $templateItem->requirements,
            'recommendations'   => $templateItem->recommendations,
            'guidance'          => $templateItem->guidance,
            'has_content'       => $templateItem->content_type==1 || $templateItem->content_type==2 ? !!$templateItem->sheet_name : !!$templateItem->content,
            'content_type'      => $templateItem->content_type,
        ];
    }

    /**
     * @param TemplateItem $templateItem
     * @return Collection
     */
    public function includeNestedItems(TemplateItem $templateItem): Collection
    {
        return $this->collection($templateItem->nestedItems, new NestedItemsTransformer);
    }
}
