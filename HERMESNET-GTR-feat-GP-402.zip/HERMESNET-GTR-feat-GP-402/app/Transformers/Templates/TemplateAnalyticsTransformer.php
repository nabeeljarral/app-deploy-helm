<?php

namespace App\Transformers\Templates;

use App\Models\Template\TemplateAnalytics;
use League\Fractal\TransformerAbstract;

/**
 *
 */
class TemplateAnalyticsTransformer extends TransformerAbstract
{
    /**
     * @var array
     */
    protected array $defaultIncludes = [];

    /**
     * @var array
     */
    protected array $availableIncludes = [];

    /**
     * @param TemplateAnalytics $templateAnalytics
     * @return array
     */
    public function transform(TemplateAnalytics $templateAnalytics): array
    {
        $lookerEmbeddingConfig = $templateAnalytics->looker_embedding_config;
        if (!$lookerEmbeddingConfig) {
            $lookerEmbeddingConfig = config('project.looker.embedded.config_template');
        }

        return [
            'id'           => (string)$templateAnalytics->id,
            'template_id'  => (string)$templateAnalytics->template_id,
            'name'         => $templateAnalytics->name,
            'sheet_name'   => $templateAnalytics->sheet_name,
            'icon'         => $templateAnalytics->icon,
            'order_number' => $templateAnalytics->order_number,
            'created_at'   => $templateAnalytics->created_at,
            'updated_at'   => $templateAnalytics->updated_at,

            'looker_embedding_config' => $lookerEmbeddingConfig,
            'looker_embedding_url'    => $templateAnalytics->looker_embedding_url
        ];
    }
}
