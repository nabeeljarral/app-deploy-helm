<?php

namespace App\Exceptions;

class PolicyException extends \RuntimeException
{

}
