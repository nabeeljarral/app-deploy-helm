<?php

namespace App\Observers;

use App\Abstractions\Queue\DispatchAction;
use App\Models\Organization;
use App\Services\GtrSync\Requests\GtrSyncSystemDataRequest;

/**
 *
 */
class OrganizationObserver
{
    /**
     * @param Organization $organization
     * @return void
     */
    public function created(Organization $organization): void
    {
        $this->gtrSync($organization);
    }

    /**
     * @param Organization $organization
     * @return void
     */
    public function updated(Organization $organization): void
    {
        $this->gtrSync($organization);
    }

    /**
     * @param Organization $organization
     * @return void
     */
    private function gtrSync(Organization $organization): void
    {
        $fields = [
            'id'                => "OrganizationID",
            'organization_name' => "OrganizationName",
            'country'           => "Country",
        ];

        if (!$organization->isDirty(array_keys($fields))) {
            return;
        }

        $action = new GtrSyncSystemDataRequest(
            array_map(fn($key) => $organization->$key, array_flip($fields)),
            "Organization"
        );
        DispatchAction::dispatch($action);
    }
}
