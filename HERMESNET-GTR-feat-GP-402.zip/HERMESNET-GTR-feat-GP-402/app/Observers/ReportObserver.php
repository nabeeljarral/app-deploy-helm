<?php

namespace App\Observers;

use App\Abstractions\Queue\DispatchAction;
use App\Models\Dashboard\Dashboard;
use App\Services\GtrSync\Requests\GtrSyncSystemDataRequest;

/**
 *
 */
class ReportObserver
{
    /**
     * @param Dashboard $dashboard
     * @return void
     */
    public function created(Dashboard $dashboard): void
    {
        $this->gtrSync($dashboard);
    }

    /**
     * @param Dashboard $dashboard
     * @return void
     */
    public function updated(Dashboard $dashboard): void
    {
        $this->gtrSync($dashboard);
    }

    /**
     * @param Dashboard $dashboard
     * @return void
     */
    private function gtrSync(Dashboard $dashboard): void
    {
        $fields = [
            'id'             => "ReportID",
            'name'           => "ReportName",
            'environment_id' => "WorkspaceID",
            'country'        => "Country",
            'city'           => "City",
        ];

        if (!$dashboard->isDirty(array_keys($fields))) {
            return;
        }

        $action = new GtrSyncSystemDataRequest(
            array_map(fn($key) => $dashboard->$key, array_flip($fields)),
            "Report"
        );
        DispatchAction::dispatch($action);
    }
}
