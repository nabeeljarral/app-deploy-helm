<?php

namespace App\Observers;

use App\Abstractions\Queue\DispatchAction;
use App\Models\Environment;
use App\Services\GtrSync\Requests\GtrSyncSystemDataRequest;

/**
 *
 */
class WorkspaceObserver
{
    /**
     * @param Environment $environment
     * @return void
     */
    public function created(Environment $environment): void
    {
        $this->gtrSync($environment);
    }

    /**
     * @param Environment $environment
     * @return void
     */
    public function updated(Environment $environment): void
    {
        $this->gtrSync($environment);
    }

    /**
     * @param Environment $environment
     * @return void
     */
    private function gtrSync(Environment $environment): void
    {
        $fields = [
            'id'              => "WorkspaceID",
            'name'            => "WorkspaceName",
            'organization_id' => "OrganizationID",
            'country'         => "Country",
            'city'            => "City",
        ];

        if (!$environment->isDirty(array_keys($fields))) {
            return;
        }

        $action = new GtrSyncSystemDataRequest(
            array_map(fn($key) => $environment->$key, array_flip($fields)),
            "Workspace"
        );
        DispatchAction::dispatch($action);
    }
}
