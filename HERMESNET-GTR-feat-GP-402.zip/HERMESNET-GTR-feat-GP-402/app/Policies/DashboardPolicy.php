<?php

namespace App\Policies;

use App\Models\User;
use App\Services\User\Enums\UserRole;
use Illuminate\Auth\Access\HandlesAuthorization;

class DashboardPolicy
{
    use HandlesAuthorization;

    public function updateDashboardProperties(User $user): bool
    {
        if ($user->is_admin === true) {
            return true;
        }
        return UserRole::isGrandedOrEqual($user->getMaxRole(), UserRole::DASHBOARD_OWNER);
    }
}
