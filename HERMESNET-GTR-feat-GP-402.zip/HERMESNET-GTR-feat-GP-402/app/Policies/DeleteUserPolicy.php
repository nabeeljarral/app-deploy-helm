<?php

namespace App\Policies;

use App\Exceptions\PolicyException;
use App\Models\User;
use App\Models\Views\UsersWithPermissionsView;
use App\Services\User\Enums\UserRole;
use Illuminate\Auth\Access\HandlesAuthorization;
use Illuminate\Support\Collection;

/**
 *
 */
class DeleteUserPolicy
{
    use HandlesAuthorization;

    /**
     * @var User
     */
    private User $currentUser;

    /**
     * @var User
     */
    private User $targetUser;

    /**
     * @param User $user
     * @param User $targetUser
     * @return bool
     */
    public function action(User $user, User $targetUser): bool
    {
        $this->currentUser = $user;
        $this->targetUser = $targetUser;

        $this->throwIfIsSelf();
        $this->throwIfTargetIsAdmin();

        if ($this->isAdmin()) {
            return true;
        }

        return $this->roleIsAllowDelete();
    }

    /**
     * @return void
     */
    private function throwIfTargetIsAdmin(): void
    {
        if ($this->targetUser->is_admin) {
            throw new PolicyException('You cannot delete an administrator');
        }
    }

    /**
     * @return void
     */
    private function throwIfIsSelf(): void
    {
        if ($this->currentUser->id === $this->targetUser->id) {
            throw new PolicyException('You cannot delete yourself');
        }
    }

    /**
     * @return bool
     */
    private function isAdmin(): bool
    {
        return $this->currentUser->is_admin;
    }

    /**
     * @return bool
     */
    private function roleIsAllowDelete(): bool
    {
        $currentUserPermission = UsersWithPermissionsView::where('organization_id', $this->currentUser->organization_id)
            ->select(['environment_id', 'dashboard_id', 'role'])
            ->where("id", $this->currentUser->id)
            ->get();

        $needleUserPermissions = UsersWithPermissionsView::where('organization_id', $this->targetUser->organization_id)
            ->select(['environment_id', 'dashboard_id', 'role'])
            ->where("id", $this->targetUser->id)
            ->get();

        $currentRole = $this->getMaxCommonRole($currentUserPermission, $needleUserPermissions);
        $needleRole = $this->getMaxCommonRole($needleUserPermissions, $currentUserPermission);

        if (!$currentRole || !$needleRole) {
            return false;
        }

        return UserRole::isGrandedOrEqual($currentRole, $needleRole);
    }

    /**
     * @param Collection $source
     * @param Collection $target
     * @return string|null
     */
    private function getMaxCommonRole(Collection $source, Collection $target): ?string
    {
        $roles = [];

        foreach ($source as $item) {
            $targetPermissions = $target->where("environment_id", $item->environment_id);

            if ($targetPermissions->isEmpty()) {
                continue;
            }

            $maxRolePerEnv = UserRole::getMaxRoleOf($targetPermissions->pluck("role")->toArray());
            if ($item->role === UserRole::ENVIRONMENT_OWNER || $maxRolePerEnv === UserRole::ENVIRONMENT_OWNER) {
                $roles[] = $item->role;
                continue;
            }

            $targetPermissions->where("dashboard_id", $item->dashboard_id);
            if (!$targetPermissions->isEmpty()) {
                $roles[] = $item->role;
            }
        }

        if (empty($roles)) {
            return null;
        }
        return UserRole::getMaxRoleOf($roles);
    }
}
