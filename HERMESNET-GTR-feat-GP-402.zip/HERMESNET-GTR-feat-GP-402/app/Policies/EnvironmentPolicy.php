<?php

namespace App\Policies;

use App\Models\Environment;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

/**
 *
 */
class EnvironmentPolicy
{
    use HandlesAuthorization;

    /**
     * @param User $user
     * @param Environment $environment
     * @return bool
     */
    public function viewEnvironment(User $user, Environment $environment): bool
    {
        if ($user->is_admin === true) {
            return true;
        }

        return $user->organization_id === $environment->organization_id;
    }
}
