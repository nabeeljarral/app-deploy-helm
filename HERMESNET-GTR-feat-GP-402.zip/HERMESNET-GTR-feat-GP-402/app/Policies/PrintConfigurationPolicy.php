<?php

namespace App\Policies;

use App\Models\PrintConfTemplate;
use App\Models\User;
use App\Services\User\Enums\UserRole;
use Illuminate\Auth\Access\HandlesAuthorization;

class PrintConfigurationPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     *
     * @param \App\Models\User $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function viewAny(User $user)
    {
        return true;
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param \App\Models\User $user
     * @param \App\Models\PrintConfTemplate $printConfTemplate
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function view(User $user, PrintConfTemplate $printConfTemplate)
    {
        return $user->isAdmin()
            || is_null($printConfTemplate->organization_id)
            || $user->organization_id === $printConfTemplate->organization_id;
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param \App\Models\User $user
     * @param \App\Models\PrintConfTemplate $printConfTemplate
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function update(User $user, PrintConfTemplate $printConfTemplate)
    {
        if ($user->isAdmin()) {
            return true;
        }

        if ($user->organization_id !== $printConfTemplate->organization_id) {
            return false;
        }

        if (!$printConfTemplate->report_id) {
            return UserRole::isGrandedOrEqual($user->getMaxRole(), UserRole::ENVIRONMENT_OWNER);
        }

        return UserRole::isGrandedOrEqual($user->getMaxRole(), UserRole::DASHBOARD_OWNER);
    }

    /**
     * Determine whether the user can delete the model.
     *
     * @param \App\Models\User $user
     * @param \App\Models\PrintConfTemplate $printConfTemplate
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function delete(User $user, PrintConfTemplate $printConfTemplate)
    {
        if ($user->isAdmin()) {
            return true;
        }

        if ($user->organization_id !== $printConfTemplate->organization_id) {
            return false;
        }

        if (!$printConfTemplate->report_id) {
            return UserRole::isGrandedOrEqual($user->getMaxRole(), UserRole::ENVIRONMENT_OWNER);
        }

        return UserRole::isGrandedOrEqual($user->getMaxRole(), UserRole::DASHBOARD_OWNER);
    }

    /**
     * Determine whether the user can restore the model.
     *
     * @param \App\Models\User $user
     * @param \App\Models\PrintConfTemplate $printConfTemplate
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function restore(User $user, PrintConfTemplate $printConfTemplate)
    {
        return $user->isAdmin()
            || $user->organization_id === $printConfTemplate->organization_id
            && UserRole::isGrandedOrEqual($user->getMaxRole(), UserRole::DASHBOARD_OWNER);
    }

    /**
     * Determine whether the user can permanently delete the model.
     *
     * @param \App\Models\User $user
     * @param \App\Models\PrintConfTemplate $printConfTemplate
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function forceDelete(User $user, PrintConfTemplate $printConfTemplate)
    {
        return $user->isAdmin()
            || $user->organization_id === $printConfTemplate->organization_id
            && UserRole::isGrandedOrEqual($user->getMaxRole(), UserRole::DASHBOARD_OWNER);
    }
}
