<?php

namespace App\Policies;

use App\Models\Template\Template;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

/**
 *
 */
class TemplatePolicy
{
    use HandlesAuthorization;

    /**
     * @param User $user
     * @param Template $template
     * @return bool
     */
    public function changeTemplateType(User $user, Template $template): bool
    {
        return !$template->reports()->exists();
    }

    /**
     * @param User $user
     * @param Template $template
     * @return bool
     */
    public function deleteTemplate(User $user, Template $template): bool
    {
        return !$template->reports()->exists() || ($user->is_admin || $user->is_templates_admin);
    }
}
