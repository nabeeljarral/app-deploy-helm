<?php

namespace App\Services\Configuration;

use App\Abstractions\Runnable;
use App\Models\Template\TemplateConfiguration;
use App\Services\Configuration\DTO\ConfigurationDto;

/**
 *
 */
class UpdateTemplateConfiguration implements Runnable
{
    /**
     * @param TemplateConfiguration $configuration
     * @param ConfigurationDto $dto
     */
    public function __construct(
        protected TemplateConfiguration $configuration,
        protected ConfigurationDto      $dto
    )
    {

    }

    /**
     * @return TemplateConfiguration
     */
    public function run(): TemplateConfiguration
    {
        $this->configuration->fill($this->dto->toArray());

        if ($this->configuration->isDirty('is_general') && !$this->configuration->is_general) {
            $this->createConfigurationItems();
        }

        $this->configuration->save();
        return $this->configuration;
    }

    /**
     * @return void
     */
    public function createConfigurationItems(): void
    {
        $existingItems = $this->configuration->items()->get();

        foreach ($this->configuration->template->items as $templateItem) {
            if ($existingItems->where("item_id", $templateItem->id)->count() > 0) {
                continue;
            }

            $this->configuration->items()->create([
                'configuration_id' => $this->configuration->id,
                'is_included'      => true,
                'item_id'          => $templateItem->id,
                'content'          => $templateItem->content
            ]);
        }
    }
}
