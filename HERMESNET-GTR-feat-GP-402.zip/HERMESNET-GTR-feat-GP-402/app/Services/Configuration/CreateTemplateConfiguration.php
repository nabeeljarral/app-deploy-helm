<?php

namespace App\Services\Configuration;

use App\Abstractions\Runnable;
use App\Models\Template\Template;
use App\Models\Template\TemplateConfiguration;
use App\Services\Configuration\DTO\ConfigurationDto;

/**
 *
 */
class CreateTemplateConfiguration implements Runnable
{
    /**
     * @param Template $template
     * @param ConfigurationDto $dto
     */
    public function __construct(
        protected Template         $template,
        protected ConfigurationDto $dto,
    )
    {

    }

    /**
     * @return TemplateConfiguration
     */
    public function run(): TemplateConfiguration
    {
        $configuration = $this->template->configurations()->create($this->dto->toArray());

        if (!$this->dto->is_general) {
            foreach ($this->template->items as $templateItem) {
                $configuration->items()->create([
                    'configuration_id' => $configuration->id,
                    'is_included'      => true,
                    'item_id'          => $templateItem->id,
                    'content'          => $templateItem->content
                ]);
            }
        }

        return $configuration;
    }
}
