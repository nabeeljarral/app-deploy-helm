<?php

namespace App\Services\Configuration;

use App\Abstractions\Runnable;
use App\Models\ConfigurationItem;
use App\Models\Dashboard\Dashboard;
use App\Models\Template\TemplateConfiguration;
use App\Services\Configuration\DTO\ConfigurationDto;

/**
 *
 */
class CreateConfigurationFromReport implements Runnable
{
    /**
     * @param Dashboard $report
     * @param ConfigurationDto $dto
     */
    public function __construct(
        private Dashboard $report,
        private ConfigurationDto $dto,
    )
    {

    }

    /**
     * @return TemplateConfiguration
     */
    public function run(): TemplateConfiguration
    {
        $template_id = $this->report?->configuration
            ? $this->report->configuration->template_id
            : $this->report->global_template_id;

        $configuration = TemplateConfiguration::create([
            'template_id'     => $template_id,
            'organization_id' => $this->dto->organization_id,
            'name'            => $this->dto->name,
            'guidance'        => $this->dto->name,
            'is_general'      => $this->dto->is_general,
            'is_published'    => $this->dto->is_published,
        ]);

        $items = $this->report
            ->items()
            ->select(['item_id', 'is_included', 'reason_of_omission'])
            ->get()
            ->each(fn($item) => $item->configuration_id = $configuration->id)
            ->toArray();

        ConfigurationItem::insert($items);

        return $configuration;
    }
}
