<?php

namespace App\Services\Configuration\DTO;

use App\Abstractions\DataTransferObject;

class ConfigurationDto extends DataTransferObject
{
    public string $name;
    public ?string $guidance = "";
    public bool $is_general = true;
    public bool $is_published = false;
    public ?int $organization_id = null;
}
