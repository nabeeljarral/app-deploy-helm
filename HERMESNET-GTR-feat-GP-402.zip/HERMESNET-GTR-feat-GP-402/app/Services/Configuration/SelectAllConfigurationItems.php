<?php

namespace App\Services\Configuration;

use App\Abstractions\Runnable;
use App\Models\ConfigurationItem;
use App\Models\Dashboard\Dashboard;
use App\Models\Template\TemplateConfiguration;
use App\Models\Views\ConfigurationItemsView;

class SelectAllConfigurationItems implements Runnable
{
    public function __construct(
        protected TemplateConfiguration|Dashboard $entry,
        protected bool                            $is_included = false
    )
    {

    }

    /**
     * @return void
     */
    public function run()
    {
        $column = $this->entry instanceof TemplateConfiguration ? "configuration_id" : "report_id";

        if ($this->is_included) {
            ConfigurationItem::where($column, $this->entry->id)
                ->update([
                    'is_included' => $this->is_included
                ]);
            return;
        }

        $column = $this->entry instanceof TemplateConfiguration ? "configuration_id" : "report_id";
        $items = ConfigurationItemsView::where($column, $this->entry->id)
            ->with("parentItem")
            ->where("mandatory", false)
            ->get();

        foreach ($items as $item) {
            if ($item->parentItem && $item->parentItem->mandatory) {
                continue;
            }
            ConfigurationItem::where("id", $item->id)
                ->update([
                    'is_included' => $this->is_included
                ]);
        }
    }
}
