<?php

namespace App\Services\Environment;

use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Models\Environment;
use App\Utils\GoogleUtil;
use App\Utils\LoggerUtil;
use Carbon\Carbon;
use Google\Service\Drive;

/**
 * Sync environment all dashboards modified and created time
 */
class SetEnvironmentDshTimestamps implements Runnable
{
    /**
     * @param Environment $environment
     */
    public function __construct(
        protected Environment $environment
    )
    {

    }

    /**
     * @return void
     */
    public function run(): void
    {

        if ($this->environment->last_sync_gs_at && Carbon::parse($this->environment->last_sync_gs_at)->diffInMinutes(now()) <= 1) {
            return;
        }

        LoggerUtil::info("[Environment] SetEnvironmentDshTimestamps::run. env_id: " . $this->environment->id);
        $dashboards = $this->environment->dashboards()->whereNotNull('file_id')->get();
        foreach ($dashboards as $dashboard) {
            try {
                $file = $this->getFile($dashboard->file_id);

                $dashboard->created_at = Carbon::createFromTimeString($file->getCreatedTime());
                $dashboard->updated_at = Carbon::createFromTimeString($file->getModifiedTime());

                $dashboard->save();
            } catch (\Exception $exception) {
                LoggerUtil::exception($exception);
            }
        }

        $this->environment->last_sync_gs_at = now();
        $this->environment->save();
    }

    /**
     * @param string $fileId
     * @return Drive\DriveFile
     * @throws \Google\Exception
     */
    private function getFile(string $fileId): Drive\DriveFile
    {
        $googleClient = GoogleUtil::apiClient([Drive::DRIVE]);

        $driveService = new Drive($googleClient);
        return $driveService
            ->files
            ->get($fileId, [
                'fields' => 'modifiedTime, createdTime'
            ]);
    }
}
