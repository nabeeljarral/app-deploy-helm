<?php

namespace App\Services\Environment;

use App\Abstractions\Runnable;
use App\Models\Dashboard\DashboardUser;
use App\Models\Environment;
use App\Services\Google\DeleteFile;

/**
 *
 */
class DeleteEnvironment implements Runnable
{
    /**
     * @param int $environment_id
     */
    public function __construct(
        private int $environment_id
    )
    {

    }

    /**
     * @return bool
     */
    public function run(): bool
    {
        $environment = Environment::where('id', $this->environment_id)->firstOrFail();

        DashboardUser::where('environment_id', $this->environment_id)->delete();

        (new DeleteFile($environment->folder_id))->run();

        $environment->delete();

        return true;
    }
}
