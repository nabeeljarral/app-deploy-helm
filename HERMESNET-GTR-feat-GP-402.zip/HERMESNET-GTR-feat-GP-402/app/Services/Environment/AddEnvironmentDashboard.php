<?php

namespace App\Services\Environment;

use App\Abstractions\Queue\DispatchAction;
use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardUser;
use App\Models\Environment;
use App\Models\Template\Template;
use App\Models\User;
use App\Services\Dashboard\AddDashboardSheet;
use App\Services\Dashboard\ConnectDashboards;
use App\Services\Dashboard\Enums\DashboardType;
use App\Services\Dashboard\Enums\SheetType;
use App\Services\Dashboard\Permissions\ImplementDashboardProtection;
use App\Services\Dashboard\Permissions\SaveDashboardProtection;
use App\Services\Dashboard\SyncDashboardRelation;
use App\Services\User\Enums\UserRole;
use App\Services\User\UserPermissions\CreateUserPermissions;
use App\Services\User\UserPermissions\UserPermissionDto;
use App\Utils\LoggerUtil;

class AddEnvironmentDashboard implements Runnable
{
    private Environment $environment;

    /**
     * @param User $currentUser
     * @param Dashboard $dashboard
     */
    public function __construct(
        private User      $currentUser,
        private Dashboard $dashboard
    )
    {

    }

    /**
     * @return Dashboard
     */
    public function run(): Dashboard
    {
        $this->environment = $this->dashboard->environment;
        $globalTemplate = $this->dashboard->globalTemplate;

        /**
         * Connect summary with org dashboard
         */
        $summaryDashboard = $this->environment->dashboards()
            ->where('type', DashboardType::SUMMARY_DASHBOARD)
            ->firstOrFail();

        if (!$summaryDashboard->file_id) {
            return  $this->dashboard;
        }

        try {
            //create $destination sheet
            $destinationSheetTitle = "Dashboard: " . $this->dashboard->name;
            $destinationSheet = (new AddDashboardSheet($summaryDashboard, $destinationSheetTitle, SheetType::CONNECTED))
                ->setHidden($globalTemplate->hidden_connected_sheet)
                ->run();

            //create sheet relations
            $sourceSheet = $this->dashboard->sheets()->where("sheet_title", $globalTemplate->data_sheet)->firstOrFail();
            $relations = (new ConnectDashboards($sourceSheet, $destinationSheet))->run();

            //sync relations
            $syncAction = new SyncDashboardRelation($relations);
            DispatchAction::of($syncAction)->afterCommit()->delay(5);


            $saveProtection = new SaveDashboardProtection($summaryDashboard);
            $saveProtection->run();

            $implementProtection = new ImplementDashboardProtection($summaryDashboard);
            DispatchAction::of($implementProtection)->afterCommit();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
        }

        $this->createUserPermissions($this->dashboard);

        return $this->dashboard;
    }

    /**
     * @param Dashboard $dashboard
     * @return void
     */
    private function createUserPermissions(Dashboard $dashboard): void
    {
        //if current user is ENVIRONMENT_OWNER in this environment - not create permissions
        $userRoles = DashboardUser::where("user_id", $this->currentUser->id)
            ->where("environment_id", $this->environment->id)
            ->pluck("role")
            ->toArray();

        if (!empty($userRoles) && UserRole::getMaxRoleOf($userRoles) === UserRole::ENVIRONMENT_OWNER) {
            return;
        }

        $envPermissions = DashboardUser::where('user_id', $this->currentUser->id)
            ->where('environment_id', $this->environment->id)
            ->get()
            ->first();

        if ($envPermissions) {
            $role = $envPermissions->role;
        } else {
            $role = $this->currentUser->getMaxRole();
        }

        if ($role == UserRole::ENVIRONMENT_OWNER) {
            return;
        }

        $userPermissions = new UserPermissionDto();
        $userPermissions->setRole($role);
        $userPermissions->setEnvironmentId($this->environment->id);
        $userPermissions->setDashboardId($dashboard->id);

        $action = new CreateUserPermissions($this->currentUser, $userPermissions);
        $action->run();
    }
}
