<?php

namespace App\Services\Environment;

use App\Abstractions\Runnable;
use App\Actions\Organization\CreateOrganizationFolder;
use App\Http\Requests\CreateEnvironmentRequest;
use App\Models\Environment;
use App\Models\Organization;
use App\Models\Template\Template;
use App\Models\User;
use App\Services\Dashboard\Create\CreateReportProcedure;
use App\Services\Dashboard\DTO\CreateReportDto;
use App\Services\Dashboard\Enums\DashboardType;
use App\Services\User\Enums\UserRole;
use App\Services\User\UserPermissions\CreateUserPermissions;
use App\Services\User\UserPermissions\UserPermissionDto;
use App\Utils\AvatarUtil;
use App\Utils\GoogleUtil;
use App\Utils\LoggerUtil;
use Google\Client;
use Google\Service\Drive;

/**
 *
 */
class CreateEnvironment implements Runnable
{
    /**
     * @var User
     */
    private User $user;

    /**
     * @var Organization
     */
    private Organization $organization;

    /**
     * @var Client
     */
    private Client $googleClient;

    /**
     * @var Template
     */
    private Template $template;

    /**
     * @var Environment
     */
    private Environment $environment;

    /**
     * @param CreateEnvironmentRequest $request
     */
    public function __construct(
        private CreateEnvironmentRequest $request
    )
    {

    }

    /**
     * @return Environment
     * @throws \Google\Exception
     */
    public function run(): Environment
    {
        LoggerUtil::info("CreateEnvironment::run", []);

        $this->user = $this->request->user();
        $this->organization = $this->user->organization;
        $this->googleClient = GoogleUtil::apiClient([Drive::DRIVE]);

        $this->setTemplate();
        $this->createOrgFolderIfNotExists();
        $this->environment = Environment::create([
            'organization_id'    => $this->organization->id,
            'name'               => $this->request->get("name"),
            'color'              => AvatarUtil::randomColorHex(),
            'global_template_id' => $this->template->id,
            'country'            => $this->request->get('country'),
            'city'               => $this->request->get('city'),
        ]);

        $this->createEnvironmentFolder();
        $this->createReport();
        $this->createUserPermissions();

        return $this->environment;
    }

    private function setTemplate(): void
    {
        if ($this->request->boolean("isBlank")) {
            $this->template = Template::organizationTemplates($this->organization)
                ->where('is_blank', true)
                ->firstOrFail();
        } else {
            $this->template = Template::where("id", $this->request->get("template_id"))->firstOrFail();
        }
    }

    /**
     * @return void
     */
    private function createReport(): void
    {
        $createReportDto = new CreateReportDto();
        $createReportDto->name = $this->environment->name;
        $createReportDto->workspace_id = $this->environment->id;
        $createReportDto->template_id = $this->template->id;
        $createReportDto->type = DashboardType::SUMMARY_DASHBOARD;
        $createReportDto->country = $this->user->organization->country;
        $createReportDto->city = $this->user->organization->city;
        $createReportDto->configuration_id = $this->request->get("configuration_id");

        (new CreateReportProcedure($createReportDto))->run();
    }

    /**
     * @return void
     */
    private function createOrgFolderIfNotExists(): void
    {
        if ($this->organization->drive_folder_id) {
            return;
        }

        $this->organization->drive_folder_id = (new CreateOrganizationFolder($this->user))->run();
        $this->organization->save();
    }

    /**
     * @return void
     */
    private function createEnvironmentFolder(): void
    {
        $folderName = "env_" . $this->environment->id;

        $folderMata = new Drive\DriveFile();
        $folderMata->setName($folderName);
        $folderMata->setMimeType(config('project.google.drive.meta.mime.folder'));
        $folderMata->setParents([$this->organization->drive_folder_id]);

        $driveService = new Drive($this->googleClient);
        $envFolder = $driveService->files->create($folderMata);

        $this->environment->folder_id = $envFolder->getId();
        $this->environment->saveQuietly();
    }

    /**
     * @return void
     */
    private function createUserPermissions(): void
    {
        $userPermissions = new UserPermissionDto();
        $userPermissions->setRole(UserRole::ENVIRONMENT_OWNER);
        $userPermissions->setEnvironmentId($this->environment->id);

        $createUserPermissions = new CreateUserPermissions(
            user: $this->user,
            permissionDto: $userPermissions
        );

        $createUserPermissions->run();
    }
}
