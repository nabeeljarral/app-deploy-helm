<?php

namespace App\Services\Dashboard\Permissions;

use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardProtection;
use App\Models\Dashboard\DashboardUnprotectedRange;
use App\Models\Dashboard\DashboardUser;
use App\Models\User;
use App\Models\Views\UsersWithPermissionsView;
use App\Services\Google\Enums\GoogleDriveFileRole;
use App\Services\Google\Permissions\ProtectedRange\ProtectSheet;
use App\Services\User\Enums\UserRole;
use App\Services\User\Enums\UserType;
use App\Utils\GoogleUtil;
use App\Utils\LoggerUtil;
use Google\Service\Drive;
use Google\Service\Sheets;
use Illuminate\Support\Collection;

/**
 * Update or create dashboard file protected & unprotected ranges based SaveDashboardProtection
 */
class ImplementDashboardProtection implements Runnable
{
    /**
     * @var Dashboard
     */
    private Dashboard $dashboard;

    /**
     * @var array
     */
    private array $requests = [];

    /**
     * @var bool
     */
    private bool $force = false;

    /**
     * @param Dashboard $dashboard
     */
    public function __construct(
        Dashboard $dashboard
    )
    {
        $this->dashboard = $dashboard;
    }

    /**
     * @return void
     * @throws \Exception
     */
    public function run(): void
    {
        logger()->info("ImplementDashboardProtection::run", ['dashboard_id' => $this->dashboard->id, 'force' => $this->force]);

        $this->prepareRequests();
        if (empty($this->requests)) {
            logger()->info("ImplementDashboardProtection::run | no content", ['dashboard_id' => $this->dashboard->id]);
            return;
        }

        $googleClient = GoogleUtil::apiClient([
            Drive::DRIVE,
            Sheets::SPREADSHEETS
        ]);

        $spreadsheetService = new Sheets($googleClient);

        $batchUpdateSpreadsheetRequest = new Sheets\BatchUpdateSpreadsheetRequest();
        $batchUpdateSpreadsheetRequest->setRequests($this->requests);

        $response = $spreadsheetService
            ->spreadsheets
            ->batchUpdate($this->dashboard->file_id, $batchUpdateSpreadsheetRequest);

        /**
         * parse response and set protected_range_id
         */
        foreach ($response->getReplies() as $reply) {
            try {
                if (!$reply->getAddProtectedRange()) {
                    continue;
                }

                $protectedRange = $reply->getAddProtectedRange()->getProtectedRange();
                $description = $protectedRange->getDescription();

                list($prefix, $protectionId) = explode("_", $description);

                $protectionModel = DashboardProtection::whereId($protectionId)->first();
                if (!$protectionModel) {
                    continue;
                }

                $protectionModel->protected_range_id = $protectedRange->getProtectedRangeId();
                $protectionModel->save();
            }
            catch (\Exception $exception) {
                LoggerUtil::exception($exception);
            }
        }
    }


    /**
     * Prepare batch request items
     * @return void
     * @throws \Exception
     */
    private function prepareRequests(): void
    {
        $dshProtections = $this->getDshProtections();
        $dshEditors = (new GetDashboardEditors($this->dashboard))->run();

        foreach ($dshProtections as $protection) {
            $hasUnprotectedRanges = $protection
                ->unprotectedRanges()
                ->where("need_implement", true)
                ->exists();

            $trashedRanges = $protection->unprotectedRanges()->onlyTrashed();
            $hasTrashedRanges = $trashedRanges->exists();

            if (
                !$this->isForce() &&
                (
                    $protection->protected_range_id &&
                    !$hasUnprotectedRanges &&
                    !$hasTrashedRanges
                )
            ) {
                continue;
            }

            $protectSheetAction = new ProtectSheet(
                $protection->dashboard->file_id,
                $protection->sheet->sheet_id,
            );

            if ($protection->protected_range_id) {
                $protectSheetAction->setProtectedRangeId($protection->protected_range_id);
            }

            /**
             * PrepareUnprotectedRanges
             */
            $unprotectedRanges = $this->prepareUnprotectedRanges($protection);
            if (!empty($unprotectedRanges)) {
                $protectSheetAction->setUnprotectedRange($unprotectedRanges);
            }

            $protectSheetAction->setEditors($dshEditors);
            $protectSheetAction->setDescription('p_' . $protection->id);

            $request = $protectSheetAction->getProtectedRangeRequest();
            $this->requests[] = $request;

            if ($hasTrashedRanges) {
                $trashedRanges->forceDelete();
            }
        }

    }

    /**
     * @param DashboardProtection $protection
     * @return array
     */
    private function prepareUnprotectedRanges(DashboardProtection $protection): array
    {

        $unprotectedRanges = $protection
            ->unprotectedRanges()
            ->get();
        $unprotectedRangEntities = [];

        foreach ($unprotectedRanges as $item) {
            $unprotectedRangEntities[] = $item->getGridRangeEntity();

            $item->need_implement = false;
            $item->save();
        }

        return $unprotectedRangEntities;
    }

    /**
     * @return bool
     */
    public function isForce(): bool
    {
        return $this->force;
    }

    /**
     * @param bool $force
     */
    public function setForce(bool $force): void
    {
        $this->force = $force;
    }

    /**
     * @return DashboardProtection[]
     */
    private function getDshProtections()
    {
        $dshProtectionExists = DashboardProtection::where('dashboard_id', $this->dashboard->id);

        if (!$dshProtectionExists->exists()) {
            $saveDashboardProtection = new SaveDashboardProtection($this->dashboard);
            $saveDashboardProtection->run();
        }

        return $dshProtectionExists->get();
    }
}
