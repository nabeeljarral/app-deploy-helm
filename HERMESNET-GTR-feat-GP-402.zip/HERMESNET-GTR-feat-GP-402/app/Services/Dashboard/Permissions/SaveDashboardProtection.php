<?php

namespace App\Services\Dashboard\Permissions;

use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardProtection;
use App\Models\Dashboard\DashboardSheet;
use App\Models\Dashboard\DashboardUnprotectedRange;
use Illuminate\Support\Arr;

/**
 * SaveDashboardProtection to DB
 */
class SaveDashboardProtection implements Runnable
{
    /**
     * @var Dashboard
     */
    private Dashboard $dashboard;

    /**
     * unprotected ranges for edit/create
     * @var array
     */
    private array $unprotectedRange = [];

    /**
     * unprotected ranges for remove
     * @var array
     */
    private array $removedUnprotectedRange = [];

    /**
     * @param Dashboard $dashboard
     */
    public function __construct(
        Dashboard $dashboard
    )
    {
        $this->dashboard = $dashboard;
    }

    /**
     * @return mixed|void
     */
    public function run()
    {
        foreach ($this->dashboard->sheets as $sheet) {
            if (
                $this->dashboard->template_name != "empty"
                && $sheet->sheet_title === config("project.dashboard.analytics_sheet")
            ) {
                continue;
            }

            $dashboardProtection = $sheet->dashboardProtection;
            if (!$dashboardProtection) {
                $dashboardProtection = DashboardProtection::create([
                    'dashboard_id' => $this->dashboard->id,
                    'sheet_id'     => $sheet->id
                ]);
            }

            $this->saveUnprotectedRange($sheet, $dashboardProtection);
        }

        if (!empty($this->removedUnprotectedRange)) {
            DashboardUnprotectedRange::whereIn('id', $this->removedUnprotectedRange)->delete();
        }
    }

    /**
     * @param DashboardSheet $sheet
     * @param DashboardProtection $dashboardProtection
     * @return void
     */
    private function saveUnprotectedRange(DashboardSheet $sheet, DashboardProtection $dashboardProtection)
    {
        $unprotectedRange = collect($this->unprotectedRange)
            ->where('sheet_id', $sheet->id);

        if ($unprotectedRange->isEmpty()) {
            return;
        }

        foreach ($unprotectedRange as $item) {
            $id = Arr::get($item, 'id');
            if ($id) {
                $range = DashboardUnprotectedRange::where('id', $id)->firstOrFail();
                $range->fill($item);

                $isDirty = $range->isDirty([
                    "start_row_id",
                    "end_row_id",
                    "start_column_id",
                    "end_column_id",
                ]);

                if ($isDirty) {
                    $range->need_implement = true;
                    $range->save();
                }

            } else {
                $item['dsh_protection_id'] = $dashboardProtection->id;
                $item['need_implement'] = true;
                DashboardUnprotectedRange::create($item);
            }
        }
    }

    /**
     * @param array $unprotectedRange
     */
    public function setUnprotectedRange(array $unprotectedRange): void
    {
        $this->unprotectedRange = $unprotectedRange;
    }

    /**
     * @param array $removedUnprotectedRange
     */
    public function setRemovedUnprotectedRange(array $removedUnprotectedRange): void
    {
        $this->removedUnprotectedRange = $removedUnprotectedRange;
    }
}
