<?php

namespace App\Services\Dashboard\Permissions;

use App\Abstractions\Queue\DispatchAction;
use App\Abstractions\Runnable;
use App\Models\Environment;
use App\Utils\LoggerUtil;
use Carbon\Carbon;

/**
 *
 */
class UpdateOrgDshProtection implements Runnable
{
    /**
     * @param int $organization_id
     */
    public function __construct(
        private int $organization_id
    )
    {

    }

    /**
     * @return mixed|void
     */
    public function run()
    {
        LoggerUtil::info("UpdateOrgDshProtection::run", ["organization_id" => $this->organization_id]);
        $environments = Environment::where("organization_id", $this->organization_id)
            ->get();

        $executionTime = Carbon::now();

        foreach ($environments as $environment) {
            foreach ($environment->dashboards as $dashboard) {
                $executionTime->addSeconds(2);
                $action = new ImplementDashboardProtection($dashboard);
                $action->setForce(true);
                DispatchAction::of($action)->delay($executionTime);
            }
        }
    }
}
