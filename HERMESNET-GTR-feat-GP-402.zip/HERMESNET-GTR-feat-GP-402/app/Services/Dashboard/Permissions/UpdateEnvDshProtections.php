<?php

namespace App\Services\Dashboard\Permissions;

use App\Abstractions\Queue\DispatchAction;
use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Models\Environment;
use App\Utils\LoggerUtil;
use Carbon\Carbon;

class UpdateEnvDshProtections implements Runnable
{
    public function __construct(
        private int $environment_id
    )
    {
    }

    public function run()
    {
        LoggerUtil::info("UpdateEnvDshProtections::run", ["environment_id" => $this->environment_id]);

        $executionTime = Carbon::now();
        $dashboards = Dashboard::where("environment_id", $this->environment_id)->get();
        foreach ($dashboards as $dashboard) {
            $executionTime->addSeconds(2);
            $action = new ImplementDashboardProtection($dashboard);
            $action->setForce(true);
            DispatchAction::of($action)->delay($executionTime);
        }
    }

}
