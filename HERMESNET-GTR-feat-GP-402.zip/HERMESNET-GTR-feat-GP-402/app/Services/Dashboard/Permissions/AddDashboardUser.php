<?php

namespace App\Services\Dashboard\Permissions;

use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardUser;
use App\Models\Environment;
use App\Models\User;
use App\Services\Google\Enums\GoogleDriveFileRole;
use App\Services\Google\Permissions\CreateFilePermissions;
use App\Services\User\Enums\UserRole;
use Google\Service\Drive;

/**
 *
 */
class AddDashboardUser implements Runnable
{
    /**
     * @var Dashboard|null
     */
    private ?Dashboard $dashboard = null;

    /**
     * @param User $user
     * @param Environment $environment
     */
    public function __construct(
        private User $user,
        private Environment $environment,
        private string $role
    )
    {

    }

    /**
     * @return void
     */
    private function validateUser(): void
    {
        if (!$this->user->google_email) {
            throw new \RuntimeException("User field google_email field can`t be empty");
        }
    }

    private function validateRole(): void
    {
        if (UserRole::isContributor($this->role) && empty($this->dashboard)) {
            throw new \RuntimeException("Report should be specified");
        }
    }

    /**
     * @return DashboardUser
     */
    public function run(): DashboardUser
    {
        $this->validateRole();
        //$this->validateUser();

        $attributes = [
            'user_id'        => $this->user->id,
            'role'           => $this->role,
            'environment_id' => $this->environment->id,
            'drive_role'     => GoogleDriveFileRole::WRITER,
        ];

        if (UserRole::isEnvironmentOwner($this->role)) {
            $fileId = $this->environment->folder_id;
        } else {
            $fileId = $this->dashboard->file_id;
            $attributes["dashboard_id"] = $this->dashboard->id;
        }

        if ($this->user->google_email) {
            $action = new CreateFilePermissions(
                $fileId,
                GoogleDriveFileRole::WRITER,
                $this->user->google_email,
            );

            $filePermissions = $action->run();
            $attributes["permissions_id"] = $filePermissions->getId();
        }

        return DashboardUser::create($attributes);
    }

    /**
     * @param Dashboard|null $dashboard
     */
    public function setDashboard(?Dashboard $dashboard): void
    {
        $this->dashboard = $dashboard;
    }
}
