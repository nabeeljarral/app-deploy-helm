<?php

namespace App\Services\Dashboard\Permissions;

use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Models\Views\UsersWithPermissionsView;
use App\Services\User\Enums\UserRole;
use App\Services\User\Enums\UserType;
use App\Utils\LoggerUtil;

/**
 *
 */
class GetDashboardEditors implements Runnable
{
    /**
     * @param Dashboard $dashboard
     */
    public function __construct(
        private Dashboard $dashboard
    )
    {

    }

    /**
     * @return string[]
     */
    public function run(): array
    {
        $environment = $this->dashboard->environment;

        $environmentOwners = UsersWithPermissionsView::where('type', UserType::REGULAR)
            ->where("organization_id", $environment->organization_id)
            ->where("role", UserRole::ENVIRONMENT_OWNER)
            ->get();

        $other = UsersWithPermissionsView::where('type', UserType::REGULAR)
            ->where("organization_id", $environment->organization_id)
            ->where("dashboard_id", $this->dashboard->id)
            ->where("role", UserRole::DASHBOARD_OWNER)
            ->get();

        $result = array_merge(
            $environmentOwners->pluck("google_email")->toArray(),
            $other->pluck("google_email")->toArray()
        );

        return array_values(array_unique($result));

        /*$users = UsersWithPermissionsView::where('type', UserType::REGULAR)
            ->where("organization_id", $environment->organization_id)
            ->whereIn("role", [UserRole::ENVIRONMENT_OWNER, UserRole::DASHBOARD_OWNER])
            ->get();

        $result = [];
        $contributors = UsersWithPermissionsView::where('type', UserType::REGULAR)
            ->where("organization_id", $environment->organization_id)
            ->where('dashboard_id', $this->dashboard->id)
            ->where("role", UserRole::DASHBOARD_CONTRIBUTOR)
            ->get()
            ->pluck("google_email")
            ->toArray();
        foreach ($users as $item) {
            $google_email = $item->google_email;
            if ($item->role === UserRole::ENVIRONMENT_OWNER && !in_array($google_email, $contributors)) {
                $result[] = $google_email;
                continue;
            }

            if ($item->dashboard_id === $this->dashboard->id) {
                $result[] = $google_email;
            }
        }
        return array_values(array_unique($result));*/
    }
}
