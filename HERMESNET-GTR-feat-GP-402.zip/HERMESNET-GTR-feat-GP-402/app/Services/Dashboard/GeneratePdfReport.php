<?php

namespace App\Services\Dashboard;

use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Services\PrintConfiguration\DTO\PrintingConfigurationDTO;
use Illuminate\Http\Response as HttpResponse;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\RequestOptions;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Response;
use Psr\Http\Message\ResponseInterface;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 *
 */
class GeneratePdfReport implements Runnable
{
    /**
     * @var bool
     */
    protected bool $exportJson = false;

    /**
     * @param Dashboard $dashboard
     * @param PrintingConfigurationDTO $templateConfig
     */
    public function __construct(
        private Dashboard                $dashboard,
        private PrintingConfigurationDTO $templateConfig
    )
    {

    }

    /**
     * @return JsonResponse|HttpResponse|mixed|StreamedResponse
     * @throws GuzzleException
     */
    public function run(): mixed
    {
        $fileName = $this->dashboard->id . '.pdf';
        try {
            if ($this->exportJson) {
                return $this->exportJson();
            }

            $response = $this->generateFile();
        } catch (ValidationException $validationException) {
            return response()->json(['error' => 'Validation error', 'message' => $validationException->getMessage() . ': ' . implode(', ', $this->templateConfig->getMandatoryFields())], 400);
        } catch (\GuzzleHttp\Exception\RequestException $exception) {
            $message = json_decode($exception->getResponse()->getBody()->getContents());
            return response()->json(['type' => $message->type, 'error' => $message->title, 'message' => $message->detail], 500);
        }

        return Response::stream(
            function () use ($response) {
                echo $response->getBody();
            },
            200,
            [
                'Content-Disposition' => 'inline; filename="' . $fileName . '"',
                'Content-Type'        => 'application/pdf'
            ]
        );
    }

    /**
     * @return HttpResponse
     */
    private function exportJson(): HttpResponse
    {
        $response = new \Illuminate\Http\Response(json_encode($this->getTemplateDataConfig()));
        $disposition = $response->headers->makeDisposition(
            ResponseHeaderBag::DISPOSITION_ATTACHMENT,
            $this->dashboard->id . '.json'
        );
        $response->headers->set('Content-Disposition', $disposition);
        $response->headers->set('Content-Type', "application/json");

        return $response;
    }

    /**
     * @return ResponseInterface
     * @throws ValidationException
     * @throws GuzzleException
     */
    private function generateFile(): ResponseInterface
    {
        $url = env("PRINT_MODULE_URL") . "/get_pdf";
        $client = new Client();

        return $client->post($url, [
            RequestOptions::QUERY => [
                'sheetId' => $this->dashboard->file_id, //google drive file id
            ],
            RequestOptions::JSON  => $this->getTemplateDataConfig()
        ]);
    }

    /**
     * @return array
     */
    private function getTemplateDataConfig(): array
    {
        if (count($this->templateConfig->getMandatoryFields()) > 0) {
            throw ValidationException::withMessages([
                'message' => "Some required fields are not filled in"
            ]);
        }

        return $this->templateConfig->getTemplateDataConfig();
    }


    /**
     * @param bool $exportJson
     * @return void
     */
    public function setExportJson(bool $exportJson): void
    {
        $this->exportJson = $exportJson;
    }
}
