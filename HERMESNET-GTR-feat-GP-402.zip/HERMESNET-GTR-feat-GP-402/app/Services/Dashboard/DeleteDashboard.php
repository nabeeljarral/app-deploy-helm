<?php

namespace App\Services\Dashboard;

use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardUser;
use App\Services\Dashboard\Enums\DashboardType;
use App\Services\Google\DeleteFile;
use App\Utils\GoogleUtil;
use App\Utils\LoggerUtil;
use Google\Service\Drive;
use Google\Service\Sheets\DeleteSheetRequest;
use Google\Service\Sheets;


/**
 *
 */
class DeleteDashboard implements Runnable
{
    /**
     * @param int $dashboard_id
     */
    public function __construct(private int $dashboard_id)
    {
    }

    /**
     * @return bool
     */
    public function run(): bool
    {
        $dashboard = Dashboard::where('id', $this->dashboard_id)->firstOrFail();

        try {
            $this->removeSummarySheet($dashboard);
        }
        catch (\Exception $exception) {
            LoggerUtil::exception($exception);
        }

        (new DeleteFile($dashboard->file_id))->run();

        DashboardUser::where('dashboard_id', $this->dashboard_id)->delete();

        $dashboard->delete();

        return true;
    }

    /**
     * @param Dashboard $dashboard
     * @return void
     */
    private function removeSummarySheet(Dashboard $dashboard): void
    {
        $summaryDashboard = $dashboard->environment->dashboards()
            ->where('type', DashboardType::SUMMARY_DASHBOARD)
            ->first();

        if (!$summaryDashboard) {
            return;
        }

        $sheet = $summaryDashboard->sheets()
            ->where("sheet_title", "Dashboard: " . $dashboard->name)
            ->first();

        if (!$sheet) {
            return;
        }

        $deleteSheetRequest = new DeleteSheetRequest();
        $deleteSheetRequest->setSheetId($sheet->sheet_id);

        $request = new Sheets\Request();
        $request->setDeleteSheet($deleteSheetRequest);

        $googleClient = GoogleUtil::apiClient([
            Drive::DRIVE,
            Sheets::SPREADSHEETS
        ]);


        $batchUpdateSpreadsheetRequest = new Sheets\BatchUpdateSpreadsheetRequest();
        $batchUpdateSpreadsheetRequest->setRequests($request);

        (new Sheets($googleClient))
            ->spreadsheets
            ->batchUpdate($summaryDashboard->file_id, $batchUpdateSpreadsheetRequest);

        $sheet->delete();
    }
}
