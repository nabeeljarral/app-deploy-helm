<?php

namespace App\Services\Dashboard\DTO;

use App\Abstractions\DataTransferObject;
use App\Models\User;

class CreateReportDto extends DataTransferObject
{
    public int $workspace_id;
    public int $template_id;
    public string $type;
    public ?int $configuration_id = null;
    public ?string $name = null;
    public ?string $country = null;
    public ?string $owner_name = null;
    public ?string $owner_email = null;
    public ?User $user = null;
    public ?string $city = null;
}
