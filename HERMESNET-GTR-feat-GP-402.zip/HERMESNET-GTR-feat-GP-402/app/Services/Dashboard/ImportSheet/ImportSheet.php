<?php

namespace App\Services\Dashboard\ImportSheet;

use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardSheet;
use App\Models\Dashboard\DashboardUnprotectedRange;
use App\Models\Dashboard\DashboardUser;
use App\Services\User\Enums\UserRole;
use App\Utils\GoogleUtil;
use Illuminate\Support\Collection;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Google\Service\Drive;
use Google\Service\Sheets;
use Google\Service\Sheets\ExtendedValue;
use PhpOffice\PhpSpreadsheet\Cell\Cell;
use App\Models\User;

/**
 *
 */
class ImportSheet implements Runnable
{
    /**
     * @var Dashboard|mixed|null
     */
    private Dashboard $dashboard;

    /**
     * @var null|Collection<DashboardUnprotectedRange>
     */
    private ?Collection $unprotectedRanges = null;

    /**
     * @var int|null
     */
    private ?int $minRow = null;

    /**
     * @var int|null
     */
    private ?int $maxRow = null;

    /**
     * @var int|null
     */
    private ?int $minCol = null;

    /**
     * @var int|null
     */
    private ?int $maxCol = null;

    /**
     * @var string
     */
    private string $uploaderRole;

    /**
     * @param DashboardSheet $dashboardSheet
     * @param string $localFileId
     * @param User $uploader
     */
    public function __construct(
        private DashboardSheet $dashboardSheet,
        private string $localFileId,
        private User $uploader,
    )
    {
        $this->dashboard = $this->dashboardSheet->dashboard;
        $this->uploaderRole = $this->getUploaderRole();
    }

    /**
     * @return void
     * @throws \PhpOffice\PhpSpreadsheet\Reader\Exception
     */
    public function run(): void
    {
        $this->setUnprotectedRanges();

        $requests = $this->prepareRequests();
        if (empty($requests)) {
            throw new \DomainException("permission denied");
        }

        $googleClient = GoogleUtil::apiClient([Drive::DRIVE]);

        $batchUpdateRequest = new Sheets\BatchUpdateSpreadsheetRequest();
        $batchUpdateRequest->setRequests($requests);

        $response = (new Sheets($googleClient))
            ->spreadsheets
            ->batchUpdate($this->dashboard->file_id, $batchUpdateRequest);
    }

    /**
     * @return void
     */
    private function setUnprotectedRanges(): void
    {
        if (!UserRole::isContributor($this->uploaderRole)) {
            return;
        }

        $dshProtection = $this->dashboardSheet->dashboardProtection;
        if ($dshProtection) {
            $this->unprotectedRanges = $dshProtection->unprotectedRanges;
        }

        if (is_a($this->unprotectedRanges, Collection::class)) {
            $this->minRow = $this->unprotectedRanges->min("start_row_id");
            $this->maxRow = $this->unprotectedRanges->max("end_row_id");

            $this->minCol = $this->unprotectedRanges->min("start_column_id");
            $this->maxCol = $this->unprotectedRanges->max("end_column_id");
        }
    }

    /**
     * @return Sheets\Request[]
     * @throws \PhpOffice\PhpSpreadsheet\Reader\Exception
     */
    private function prepareRequests(): array
    {
        $requests = [];

        $fileName = storage_path("app/import/" . $this->localFileId . ".xlsx");

        $reader = IOFactory::createReader(IOFactory::READER_XLSX);
        $spreadsheet = $reader->load($fileName);
        $activeSheet = $spreadsheet->getActiveSheet();

        $gridProperties = $this->dashboardSheet->getGridProperties();

        $rowIterator = $activeSheet->getRowIterator();
        $rowIndex = 0;
        foreach ($rowIterator as $row) {
            ++$rowIndex;

            if (UserRole::isContributor($this->uploaderRole)) {
                if (!is_int($this->minRow) || ($rowIndex < $this->minRow)) {
                    continue;
                }

                if (!is_int($this->maxRow) || ($rowIndex > $this->maxRow)) {
                    continue;
                }
            }

            $cellIterator = $row->getCellIterator();
            $cellIndex = 0;

            foreach ($cellIterator as $cell) {
                ++$cellIndex;

                if (UserRole::isContributor($this->uploaderRole)) {
                    if (!is_int($this->minCol) || ($cellIndex-1 < $this->minCol)) {
                        continue;
                    }

                    if (!is_int($this->maxCol) || ($cellIndex-1 > $this->maxCol)) {
                        continue;
                    }
                }



                if (!$this->isAvailableForWrite($rowIndex, $cellIndex, $cell->getFormattedValue())) {
                    continue;
                }

                $gridRange = new Sheets\GridRange([
                    'sheetId'          => $this->dashboardSheet->sheet_id,
                    'startRowIndex'    => $rowIndex - 1,
                    'endRowIndex'      => $rowIndex,
                    'startColumnIndex' => $cellIndex - 1,
                    'endColumnIndex'   => $cellIndex,
                ]);

                $userEnteredValue = $this->castCellValue($cell);

                $cellData = new Sheets\CellData();
                $cellData->setUserEnteredValue($userEnteredValue);

                $repeatCellRequest = new Sheets\RepeatCellRequest();
                $repeatCellRequest->setRange($gridRange);
                $repeatCellRequest->setCell($cellData);
                $repeatCellRequest->setFields("userEnteredValue");

                $request = new Sheets\Request();
                $request->setRepeatCell($repeatCellRequest);

                $requests[] = $request;

                if ($cellIndex >= $gridProperties->getColumnCount()) break;
            }

            if ($rowIndex >= $gridProperties->getRowCount()) break;
        }
        return $requests;
    }

    /**
     * @return string
     */
    private function getUploaderRole(): string
    {
        $userMaxRole = $this->uploader->getMaxRole();

        if ($userMaxRole === UserRole::ENVIRONMENT_OWNER) {
            return UserRole::ENVIRONMENT_OWNER;
        }

        $permissions = DashboardUser::where('user_id', $this->uploader->id)
            ->where("environment_id", $this->dashboard->environment_id)
            ->where("dashboard_id", $this->dashboard->id)
            ->get();

        if ($permissions->isEmpty()) {
            throw new \DomainException("permission denied");
        }

        return UserRole::getMaxRoleOf($permissions->pluck("role")->toArray());
    }

    /**
     * @param int $rowIndex
     * @param int $cellIndex
     * @param $v
     * @return bool
     */
    protected function isAvailableForWrite(int $rowIndex, int $cellIndex, $v = null): bool
    {
        if (!UserRole::isContributor($this->uploaderRole)) {
            return true;
        }

        if (!$this->unprotectedRanges || $this->unprotectedRanges->isEmpty()) {
            return false;
        }

        $result = false;

        //++$rowIndex;
        --$cellIndex;

        foreach ($this->unprotectedRanges as $range) {

            $result = (
                $rowIndex >= $range->start_row_id
                && $rowIndex <= $range->end_row_id
                && $cellIndex >= $range->start_column_id
                && $cellIndex <= $range->end_column_id
            );

            if ($result) {
                break;
            }
        }

        return $result;
    }


    /**
     * @param Cell $cell
     * @return ExtendedValue
     */
    private function castCellValue(Cell $cell): ExtendedValue
    {
        $extendedValue = new ExtendedValue();

        if ($cell->isFormula()) {
            $extendedValue->setFormulaValue($cell->getValue());
            return $extendedValue;
        }

        $cellValue = $cell->getFormattedValue();
        if (!$cellValue) {
            $extendedValue->setStringValue($cellValue);
            return $extendedValue;
        }

        $cellValue = trim($cellValue);


        $floatVal = filter_var(
            str_replace(',', '', $cellValue),
            FILTER_VALIDATE_FLOAT
        );
        if (is_float($floatVal)) {
            $extendedValue->setNumberValue($floatVal);
            return $extendedValue;
        }

        $extendedValue->setStringValue($cellValue);
        return $extendedValue;
    }
}
