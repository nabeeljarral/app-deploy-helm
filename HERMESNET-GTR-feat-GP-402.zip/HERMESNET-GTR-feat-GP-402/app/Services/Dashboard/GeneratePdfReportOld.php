<?php

namespace App\Services\Dashboard;

use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Models\PrintConfTemplate;
use App\Utils\UrlUtil;
use GuzzleHttp\Client;
use GuzzleHttp\RequestOptions;
use Illuminate\Support\Facades\Response;
use Psr\Http\Message\ResponseInterface;

/**
 *
 */
class GeneratePdfReportOld implements Runnable
{
    /**
     * @param Dashboard $dashboard
     */
    public function __construct(
        private Dashboard $dashboard
    )
    {

    }

    /**
     * @return mixed|\Symfony\Component\HttpFoundation\StreamedResponse
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function run()
    {
        $fileName = $this->dashboard->id . '.pdf';

        $response = $this->generateFile();

        return Response::stream(
            function () use ($response) {
                echo $response->getBody();
            },
            200,
            [
                'Content-Disposition' => 'inline; filename="' . $fileName . '"',
                'Content-Type'        => 'application/pdf'
            ]
        );
    }

    /**
     * @param array $templateConfig
     * @return ResponseInterface
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    private function generateFile(): ResponseInterface
    {
        $url = env("PRINT_MODULE_URL") . "/get_pdf";
        $client = new Client();

        return $client->post($url, [
            RequestOptions::QUERY => [
                'sheetId' => $this->dashboard->file_id, //google drive file id
            ]
        ]);
    }
}
