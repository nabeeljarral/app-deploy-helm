<?php

namespace App\Services\Dashboard\Create;

use App\Abstractions\Runnable;
use App\Models\ConfigurationItem;
use App\Models\Dashboard\Dashboard;
use App\Models\Template\Template;
use App\Models\Template\TemplateConfiguration;
use App\Models\Template\TemplateItem;
use App\Services\Dashboard\Enums\DashboardType;
use Illuminate\Support\Collection;

/**
 *
 */
class CreateReportItems implements Runnable
{
    /**
     * @param Dashboard $report
     * @param TemplateConfiguration|Template $configuration
     */
    public function __construct(
        private Dashboard                      $report,
        private TemplateConfiguration|Template $configuration
    )
    {

    }

    /**
     * @return void
     */
    public function run(): void
    {
        $items = $this->getItems();
        $this->createReportItems($items);
    }

    /**
     * @return Collection<ConfigurationItem>|Collection<TemplateItem>
     */
    private function getItems(): Collection
    {
        if ($this->configuration->is_general || $this->isCreateFormTemplate()) {
            $template_id = $this->isCreateFormTemplate()
                ? $this->configuration->id
                : $this->configuration->template_id;

            $items = TemplateItem::where("template_id", $template_id)->get();
        } else {
            $items = ConfigurationItem::where("configuration_id", $this->configuration->id)->get();
        }

        return $items;
    }

    /**
     * @param Collection<ConfigurationItem>|Collection<TemplateItem> $items
     * @return void
     */
    private function createReportItems(Collection $items): void
    {
        /* @var TemplateItem|ConfigurationItem $item */
        foreach ($items as $item) {
            if ($this->configuration->is_general || $this->isCreateFormTemplate()) {
                ConfigurationItem::create([
                    'report_id'   => $this->report->id,
                    'item_id'     => $item->id,
                    'is_included' => $this->report->type === DashboardType::SUMMARY_DASHBOARD,
                    'content'     => $item->content,
                ]);
            } else {
                $data = $item->toArray();
                $data['configuration_id'] = null;
                $data['report_id'] = $this->report->id;
                ConfigurationItem::create($data);
            }
        }
    }

    /**
     * @return bool
     */
    protected function isCreateFormTemplate(): bool
    {
        return $this->configuration instanceof Template;
    }
}
