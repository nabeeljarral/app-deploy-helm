<?php

namespace App\Services\Dashboard\Create;

use App\Abstractions\Queue\DispatchAction;
use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardSheet;
use App\Models\Environment;
use App\Models\Template\Template;
use App\Models\Template\TemplateConfiguration;
use App\Services\Dashboard\DTO\CreateReportDto;
use App\Services\Dashboard\Enums\DashboardType;
use App\Services\Dashboard\Enums\ReportStatus;
use App\Services\Dashboard\Enums\SheetType;
use App\Services\Dashboard\Permissions\ImplementDashboardProtection;
use App\Services\PrintConfiguration\CreateReportPrintConfigurations;
use App\Services\Template\Enums\TemplateCategory;
use App\Services\User\DTO\InviteUserDto;
use App\Services\User\Enums\UserRole;
use App\Services\User\Invite\InviteUserProcedure;
use App\Utils\AvatarUtil;
use App\Utils\GoogleUtil;
use App\Utils\LoggerUtil;
use Google\Client;
use Google\Service\Drive;
use Google\Service\Sheets;

/**
 *
 */
class CreateReportProcedure implements Runnable
{
    /**
     * @var Environment
     */
    private Environment $environment;

    /**
     * @var Template
     */
    private Template $template;

    /**
     * @var Client
     */
    private Client $googleClient;

    /**
     * @var Dashboard
     */
    private Dashboard $report;

    /**
     * @param CreateReportDto $dto
     */
    public function __construct(
        private CreateReportDto $dto
    )
    {

    }

    /**
     * @return Dashboard
     * @throws \Google\Exception
     * @throws \Exception
     */
    public function run(): Dashboard
    {
        $this->environment = Environment::findOrFail($this->dto->workspace_id);
        $this->template = Template::findOrFail($this->dto->template_id);
        $this->googleClient = GoogleUtil::apiClient([Drive::DRIVE]);

        $this->setConfigurationIdIfEmpty();

        try {
            $this->createReport();
        } catch (\Exception $exception) {
            if (isset($this->report)) {
                $this->report->delete();
            }

            throw $exception;
        }

        $this->createReportItems();
        $this->createReportSheets();
        $this->dashboardProtection();
        $this->inviteReportOwner();
        $this->createPrintConfigurations();

        return $this->report;
    }

    /**
     * @return Dashboard
     */
    private function createReport(): Dashboard
    {
        $this->report = Dashboard::create([
            'name'               => $this->dto->name,
            'type'               => $this->dto->type,
            'country'            => $this->dto->country,
            'city'               => $this->dto->city,
            'environment_id'     => $this->dto->workspace_id,
            'index_sheet'        => $this->template->index_sheet ?? config("project.dashboard.index_sheet"),
            'global_template_id' => $this->dto->template_id,
            'configuration_id'   => $this->dto->configuration_id,
            'color'              => AvatarUtil::randomColorHex(),
            'status'             => $this->getReportStatus(),
        ]);

        if ($this->template->gd_file_id) {
            $driveService = new Drive($this->googleClient);
            $file = new Drive\DriveFile();
            $file->setName($this->gdFileName ?? $this->dto->type);
            $file->setParents([$this->environment->folder_id]);
            $driveFile = $driveService->files->copy($this->template->gd_file_id, $file);

            $this->report->file_id = $driveFile->getId();
            $this->report->save();
        }

        return $this->report;
    }

    /**
     * @task GP-209 Disable report structure definition for a template
     * @return int
     */
    public function getReportStatus(): int
    {
        if ($this->template->category !== TemplateCategory::COMPLEX) {
            return ReportStatus::DEFINED;
        }

        if ($this->template->type === DashboardType::DASHBOARD) {
            return ReportStatus::DRAFT;
        }

        return $this->template->allow_report_structure_definition
            ? ReportStatus::DRAFT
            : ReportStatus::DEFINED;
    }

    /**
     * @return void
     */
    private function createReportItems(): void
    {
        if ($this->template->category !== TemplateCategory::COMPLEX) {
            return;
        }

        if ($this->dto->configuration_id) {
            $configuration = TemplateConfiguration::find($this->dto->configuration_id);
        }

        if (!isset($configuration)) {
            $configuration = $this->template;
        }

        (new CreateReportItems($this->report, $configuration))->run();
    }

    /**
     * @return void
     */
    private function createReportSheets(): void
    {
        if (!$this->report->file_id) {
            return;
        }

        $spreadsheetService = new Sheets($this->googleClient);
        $spreadsheet = $spreadsheetService->spreadsheets->get($this->report->file_id);

        foreach ($spreadsheet->getSheets() as $sheet) {
            $sheetProperties = $sheet->getProperties();

            $gridProperties = [
                "columnCount" => $sheetProperties->getGridProperties()->getColumnCount(),
                "rowCount"    => $sheetProperties->getGridProperties()->getRowCount(),
            ];

            DashboardSheet::create([
                "dashboard_id"    => $this->report->id,
                "type"            => SheetType::REGULAR,
                "sheet_title"     => $sheetProperties->getTitle(),
                "sheet_id"        => $sheetProperties->getSheetId(),
                "sheet_type"      => $sheetProperties->getSheetType(),
                "grid_properties" => $gridProperties
            ]);
        }
    }

    /**
     * @return void
     */
    private function dashboardProtection(): void
    {
        $implementProtection = new ImplementDashboardProtection($this->report);
        $implementProtection->setForce(true);
        DispatchAction::of($implementProtection)->afterCommit()->delay(5);
    }

    /**
     * @return void
     */
    private function inviteReportOwner(): void
    {
        if (!$this->dto->owner_name || !$this->dto->owner_email || !$this->dto->user) {
            return;
        }

        try {
            $dto = new InviteUserDto();
            $dto->setRole(UserRole::DASHBOARD_OWNER);
            $dto->setName($this->dto->owner_name);
            $dto->setEmail($this->dto->owner_email);
            $dto->setEnvironmentId($this->environment->id);
            $dto->setDashboardId($this->report->id);

            $inviteAction = new InviteUserProcedure($dto, $this->dto->user);
            DispatchAction::of($inviteAction)->afterCommit()->delay(5);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
        }
    }

    /**
     * @return void
     */
    private function setConfigurationIdIfEmpty(): void
    {
        if ($this->dto->configuration_id) {
            return;
        }

        if ($this->template->category === TemplateCategory::COMPLEX) {
            $configuration = $this->template->configurations()
                ->where('is_general', true)
                ->where('is_published', true)
                ->whereNull('organization_id')
                ->first();

            if ($configuration) {
                $this->dto->configuration_id = $configuration->id;
            }
        }
    }

    /**
     * @return void
     */
    private function createPrintConfigurations(): void
    {
        try {
            $createAction = new CreateReportPrintConfigurations($this->environment->organization_id, $this->report);
            DispatchAction::of($createAction)->afterCommit()->delay(5);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
        }
    }
}
