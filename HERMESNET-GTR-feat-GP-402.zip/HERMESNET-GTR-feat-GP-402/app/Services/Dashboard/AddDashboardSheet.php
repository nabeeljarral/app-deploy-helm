<?php

namespace App\Services\Dashboard;

use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardSheet;
use App\Services\Dashboard\Enums\SheetType;
use App\Utils\GoogleUtil;
use Google\Service\Drive;
use Google\Service\Sheets;

/**
 *
 */
class AddDashboardSheet implements Runnable
{
    /**
     * @var Dashboard
     */
    private Dashboard $dashboard;

    /**
     * @var string
     */
    private string $title;

    /**
     * @var string
     */
    private string $type;

    /**
     * @var bool
     */
    private bool $hidden = false;

    /**
     * @param Dashboard $dashboard
     * @param string $title
     * @param string $type
     */
    public function __construct(
        Dashboard $dashboard,
        string $title,
        string $type = SheetType::REGULAR
    )
    {
        $this->dashboard = $dashboard;
        $this->title = $title;
        $this->type = $type;
    }

    /**
     * @return DashboardSheet|mixed
     * @throws \Google\Exception
     */
    public function run()
    {
        $sheetResponse = $this->addSheet();
        $sheetProperties = $sheetResponse->getProperties();

        return DashboardSheet::create([
            "dashboard_id" => $this->dashboard->id,
            "type"         => $this->type,
            "sheet_title"  => $sheetProperties->getTitle(),
            "sheet_id"     => $sheetProperties->getSheetId(),
            "sheet_type"   => $sheetProperties->getSheetType(),
        ]);
    }

    /**
     * @return Sheets\AddSheetResponse
     * @throws \Google\Exception
     */
    private function addSheet(): Sheets\AddSheetResponse
    {
        $googleClient = GoogleUtil::apiClient([Drive::DRIVE]);
        $spreadsheetService = new Sheets($googleClient);

        $sheetsRequest = $this->prepareSheetsRequest();
        $batchUpdateSpreadsheetRequest = new Sheets\BatchUpdateSpreadsheetRequest();
        $batchUpdateSpreadsheetRequest->setRequests($sheetsRequest);

        $response = $spreadsheetService
            ->spreadsheets
            ->batchUpdate(
                $this->dashboard->file_id,
                $batchUpdateSpreadsheetRequest
            );

        $reply = $response->getReplies();
        if (empty($reply)) {
            throw new \RuntimeException("Sheet not created!");
        }

        return $reply[0]->getAddSheet();
    }

    /**
     * @return Sheets\Request
     */
    private function prepareSheetsRequest(): Sheets\Request
    {
        $sheetProps = new Sheets\SheetProperties([
            'title' => $this->title
        ]);
        $sheetProps->setHidden($this->hidden);

        $addSheetRequest = new Sheets\AddSheetRequest([
            'properties' => $sheetProps,
        ]);

        return new Sheets\Request([
            'addSheet' => $addSheetRequest
        ]);
    }

    /**
     * @param bool $hidden
     * @return $this
     */
    public function setHidden(bool $hidden): self
    {
        $this->hidden = $hidden;
        return $this;
    }
}
