<?php

namespace App\Services\Dashboard;

use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardSheet;
use App\Services\Dashboard\Enums\SheetType;
use App\Utils\GoogleUtil;
use Google\Service\Drive;
use Google\Service\Sheets;

/**
 *
 */
class SyncDashboardSheets implements Runnable
{
    /**
     * @param Dashboard $dashboard
     */
    public function __construct(
        private Dashboard $dashboard
    )
    {

    }

    /**
     * @return mixed|void
     */
    public function run()
    {
        $googleClient = GoogleUtil::apiClient([Drive::DRIVE]);
        $spreadsheetService = new Sheets($googleClient);
        $spreadsheet = $spreadsheetService->spreadsheets->get($this->dashboard->file_id);


        $sheets = $spreadsheet->getSheets();

        $dashboardSheets = $this->dashboard->sheets;

        foreach ($sheets as $sheet) {
            $properties = $sheet->getProperties();
            $dshSheet = $dashboardSheets->where("sheet_id", $properties->getSheetId())
                ->first();

            $gridProperties = [
                "columnCount" => $properties->getGridProperties()->getColumnCount(),
                "rowCount"    => $properties->getGridProperties()->getRowCount(),
            ];

            if (!$dshSheet) {
                DashboardSheet::create([
                    "dashboard_id"    => $this->dashboard->id,
                    "type"            => SheetType::REGULAR,
                    "sheet_title"     => $properties->getTitle(),
                    "sheet_id"        => $properties->getSheetId(),
                    "sheet_type"      => $properties->getSheetType(),
                    "grid_properties" => $gridProperties,
                ]);
            }else {
                $dshSheet->grid_properties = $gridProperties;
                $dshSheet->save();
            }
        }
    }

}
