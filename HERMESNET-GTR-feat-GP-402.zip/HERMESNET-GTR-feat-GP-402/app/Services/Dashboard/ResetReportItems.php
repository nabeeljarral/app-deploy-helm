<?php

namespace App\Services\Dashboard;

use App\Abstractions\Runnable;
use App\Models\ConfigurationItem;
use App\Models\Dashboard\Dashboard;
use App\Models\Template\TemplateItem;

/**
 *
 */
class ResetReportItems implements Runnable
{
    /**
     * @param Dashboard $report
     */
    public function __construct(private Dashboard $report)
    {
        if (!$this->report->configuration_id) {
            throw new \InvalidArgumentException("report configuration id cannot be empty");
        }
    }

    /**
     * @return void
     */
    public function run(): void
    {
        $reportItems = $this->report->items;
        if ($reportItems->isEmpty()) {
            return;
        }

        $reportConfiguration = $this->report->configuration;

        if ($reportConfiguration->is_general) {
            $configurationItems = TemplateItem::where("template_id", $reportConfiguration->template_id)->get();
        } else {
            $configurationItems = ConfigurationItem::where("configuration_id", $reportConfiguration->id)
                ->get();
        }

        foreach ($reportItems as $reportItem) {
            if ($reportConfiguration->is_general) {
                $item = $configurationItems->where("id", $reportItem->item_id)->first();
            } else {
                $item = $configurationItems->where("item_id", $reportItem->item_id)->first();
            }

            $reportItem->is_included = $item->is_included ?? true;
            $reportItem->reason_of_omission = $item->reason_of_omission ?? null;
            $reportItem->save();
        }
    }
}
