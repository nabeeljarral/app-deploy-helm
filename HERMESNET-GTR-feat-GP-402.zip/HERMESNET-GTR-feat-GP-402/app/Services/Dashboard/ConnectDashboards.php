<?php

namespace App\Services\Dashboard;

use App\Abstractions\Runnable;
use App\Models\Dashboard\DashboardSheet;
use App\Models\Dashboard\DashboardSheetRelations;


/**
 *
 */
class ConnectDashboards implements Runnable
{
    /**
     * @var DashboardSheet
     */
    private DashboardSheet $sourceSheet;

    /**
     * @var DashboardSheet
     */
    private DashboardSheet $destenationSheet;

    /**
     * @var string
     */
    private string $sourceRange;

    /**
     * @param DashboardSheet $sourceSheet
     * @param DashboardSheet $destenationSheet
     * @param string $sourceRange
     */
    public function __construct(
        DashboardSheet $sourceSheet,
        DashboardSheet $destenationSheet,
        string $sourceRange = "A1:Z300"
    )
    {
        $this->sourceSheet = $sourceSheet;
        $this->destenationSheet = $destenationSheet;
        $this->sourceRange = $sourceRange;
    }

    /**
     * @return DashboardSheetRelations
     */
    public function run(): DashboardSheetRelations
    {
        $environment = $this->sourceSheet
            ->dashboard
            ->environment;

        return DashboardSheetRelations::create([
            'environment_id'       => $environment->id,
            "source_sheet_id"      => $this->sourceSheet->id,
            "destination_sheet_id" => $this->destenationSheet->id,
            "source_range"         => $this->sourceRange,
            "last_updated_time"    => null,
        ]);
    }
}
