<?php

namespace App\Services\Dashboard;

use App\Abstractions\Runnable;
use App\Models\Dashboard\DashboardSheetRelations;
use App\Services\Google\CopySheetValueTo;
use App\Utils\LoggerUtil;
use Illuminate\Support\Carbon;

/**
 *
 */
class SyncDashboardRelation implements Runnable
{
    /**
     * @var DashboardSheetRelations
     */
    private DashboardSheetRelations $relations;

    /**
     * @param DashboardSheetRelations $relations
     */
    public function __construct(DashboardSheetRelations $relations)
    {
        $this->relations = $relations;
    }

    /**
     * @return void
     */
    public function run(): void
    {
        LoggerUtil::info("SyncDashboardRelation::run", ['relation' => $this->relations->id]);

        $sourceSheet = $this->relations->sourceSheet;
        $sourceDashboard = $sourceSheet->dashboard;

        $destinationSheet = $this->relations->destinationSheet;
        $destinationDashboard = $destinationSheet->dashboard;

        $copySheetValue = new CopySheetValueTo(
            $sourceDashboard->file_id,
            $sourceSheet->sheet_title,
            $destinationDashboard->file_id,
            $destinationSheet->sheet_id
        );
        $copySheetValue->setSourceRange($this->relations->source_range);
        $copySheetValue->run();

        $this->relations->last_updated_time = Carbon::now();
        $this->relations->save();
    }
}
