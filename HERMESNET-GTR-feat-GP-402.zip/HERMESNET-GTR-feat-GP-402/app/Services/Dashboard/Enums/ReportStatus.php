<?php

namespace App\Services\Dashboard\Enums;

final class ReportStatus
{
    public const DRAFT = 0;

    public const DEFINED = 1;
}
