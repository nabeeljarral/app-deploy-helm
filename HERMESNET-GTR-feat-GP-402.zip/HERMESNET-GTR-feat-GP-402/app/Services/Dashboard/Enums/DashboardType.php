<?php

namespace App\Services\Dashboard\Enums;

/**
 *
 */
final class DashboardType
{
    /**
     * TODO: rename to SUMMARY
     */
    const SUMMARY_DASHBOARD = "summary";

    /**
     * TODO: rename to DATA_COLLECTION
     */
    const DASHBOARD = "dashboard"; //Data Collection Report

    /**
     *
     */
    const AVAILABLE = [
        self::SUMMARY_DASHBOARD,
        self::DASHBOARD,
    ];

    /**
     * @param string $type
     * @return bool
     */
    public static function isValid(string $type): bool {
        return in_array($type, self::AVAILABLE);
    }
}
