<?php

namespace App\Services\Dashboard\Enums;

final class SheetType
{
    public const REGULAR = "regular";
    public const CONNECTED = "connected";
}
