<?php

namespace App\Services\Dashboard;

use App\Abstractions\Runnable;
use App\Models\ConfigurationItem;
use App\Models\Dashboard\Dashboard;
use App\Services\Dashboard\Enums\ReportStatus;

/**
 *
 */
class DefineDataCollectionsStructure implements Runnable
{

    /**
     * @param int[] $reports // report_ids
     * @param bool[] $items // [template_items.item_id => is_included]
     */
    public function __construct(
        private array $reports,
        private array $items,
    )
    {

    }

    /**
     * @return bool
     */
    public function run(): bool
    {
        try {
            \DB::beginTransaction();

            foreach ($this->items as $item_id => $is_included) {
                ConfigurationItem::query()
                    ->where('item_id', $item_id)
                    ->whereIn('report_id', $this->reports)
                    ->update([
                        'is_included' => $is_included
                    ]);
            }

            \DB::commit();

            Dashboard::query()
                ->whereIn('id', $this->reports)
                ->update([
                    'status' => ReportStatus::DEFINED
                ]);

            return true;
        } catch (\Exception) {

            \DB::rollBack();
            return false;
        }

    }
}
