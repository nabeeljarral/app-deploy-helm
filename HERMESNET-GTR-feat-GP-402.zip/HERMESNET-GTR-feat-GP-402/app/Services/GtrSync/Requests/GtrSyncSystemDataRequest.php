<?php

namespace App\Services\GtrSync\Requests;

use App\Abstractions\Runnable;
use App\Utils\LoggerUtil;
use GuzzleHttp\RequestOptions;
use Psr\Http\Message\ResponseInterface;

/**
 *
 */
class GtrSyncSystemDataRequest implements Runnable
{
    /**
     * @param array $data
     * @param string $dataKey
     */
    public function __construct(
        private array  $data,
        private string $dataKey,
    )
    {

    }

    /**
     * @return ResponseInterface
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function run(): ResponseInterface
    {
        LoggerUtil::info("[GTR SYNC] Sending data to GTR Sync System", [
            'data'     => $this->data,
            'data_key' => $this->dataKey
        ]);

        $client = new \GuzzleHttp\Client([
            'base_uri' => config("project.gtr_sync.base_uri"),
        ]);

        return $client->post(config("project.gtr_sync.system_data_endpoint"), [
            RequestOptions::JSON => [
                "ProjectId"    => config("project.gtr_sync.project_id"),
                $this->dataKey => $this->data
            ]
        ]);
    }
}
