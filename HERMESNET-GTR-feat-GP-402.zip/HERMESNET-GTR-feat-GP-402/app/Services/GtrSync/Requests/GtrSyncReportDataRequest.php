<?php

namespace App\Services\GtrSync\Requests;

use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Utils\GoogleUtil;
use App\Utils\LoggerUtil;
use Carbon\Carbon;
use Google\Service\Drive;
use GuzzleHttp\RequestOptions;
use Psr\Http\Message\ResponseInterface;

/**
 *
 */
class GtrSyncReportDataRequest implements Runnable
{
    /**
     * @param Dashboard $report
     */
    public function __construct(private Dashboard $report)
    {

    }

    /**
     * @return ResponseInterface|null
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function run(): ?ResponseInterface
    {
        LoggerUtil::info('GtrSyncReportDataRequest::run', [
            'report_id' => $this->report->id,
            'file_id'   => $this->report->file_id,
        ]);

        if (!$this->report->file_id) {
            return null;
        }

        $payload = $this->getRequestPayload();

        if (!$payload) {
            return null;
        }

        $lastModifiedTime = Carbon::createFromTimeString($this->getFile()->getModifiedTime());

        LoggerUtil::variable([
            'lastModifiedTime' => $lastModifiedTime?->toDateTimeString(),
            'gtr_last_sync_at' => $this->report->gtr_last_sync_at ? $this->report->gtr_last_sync_at->toDateTimeString() : null,
            'diffInSeconds'    => $this->report->gtr_last_sync_at && $lastModifiedTime ? $lastModifiedTime->diffInSeconds($this->report->gtr_last_sync_at) : null,
        ]);

        if ($this->report->gtr_last_sync_at && $lastModifiedTime->diffInSeconds($this->report->gtr_last_sync_at) <= 1) {
            return null;
        }

        $client = new \GuzzleHttp\Client([
            'base_uri' => config("project.gtr_sync.base_uri"),
        ]);

        $response = $client->post(config("project.gtr_sync.report_endpoint"), [
            RequestOptions::JSON => $payload
        ]);

        $this->report->update([
            'updated_at'       => $lastModifiedTime,
            'gtr_last_sync_at' => $lastModifiedTime,
        ], ['timestamps' => false]);

        return $response;
    }

    /**
     * @return array|null
     */
    private function getRequestPayload(): ?array
    {
        if (!$this->report->globalTemplate || !$this->report->globalTemplate->gtr_sync_config) {
            return null;
        }

        $workspace = $this->report->environment;
        $organization = $workspace->organization;

        $payload = $this->report->globalTemplate->gtr_sync_config ?? [];

        $payload['ProjectId'] = config('project.gtr_sync.project_id');
        $payload['SheetID'] = $this->report->file_id;

        $payload["Organization"] = [
            "OrganizationID"   => $organization->id,
            "OrganizationName" => $organization->name,
            "Country"          => $organization->country,
        ];

        $payload["Workspace"] = [
            "WorkspaceID"   => $workspace->id,
            "WorkspaceName" => $workspace->name,
        ];

        $payload["Report"] = [
            "ReportID"   => $this->report->id,
            "ReportName" => $this->report->name,
            "Country"    => $this->report->country,
            "City"       => $this->report->city,
        ];

        return $payload;
    }

    private function getFile(): Drive\DriveFile
    {
        $googleClient = GoogleUtil::apiClient([Drive::DRIVE]);

        $driveService = new Drive($googleClient);
        return $driveService
            ->files
            ->get($this->report->file_id, [
                'fields' => 'modifiedTime, createdTime'
            ]);
    }
}
