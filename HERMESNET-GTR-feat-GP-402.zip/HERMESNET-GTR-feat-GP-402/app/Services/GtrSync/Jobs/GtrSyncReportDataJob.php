<?php

namespace App\Services\GtrSync\Jobs;

use App\Abstractions\Queue\Job;
use App\Models\Dashboard\Dashboard;
use App\Services\GtrSync\Requests\GtrSyncReportDataRequest;
use App\Utils\LoggerUtil;
use Illuminate\Contracts\Queue\ShouldBeUnique;

/**
 *
 */
class GtrSyncReportDataJob extends Job implements ShouldBeUnique
{
    /**
     * @var int
     */
    public int $uniqueFor = 100;


    /**
     * @param int $report_id
     */
    public function __construct(public int $report_id)
    {

    }

    /**
     * @return string
     */
    public function uniqueId(): string
    {
        return get_class($this) . "::" . $this->report_id;
    }

    /**
     * @return void
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function handle(): void
    {
        LoggerUtil::info("[Report] GtrSyncReportDataJob::handle", ['id' => $this->report_id]);
        $report = Dashboard::where('id', $this->report_id)->first();
        (new GtrSyncReportDataRequest($report))->run();
    }
}
