<?php

namespace App\Services\User\Enums;

use phpseclib3\File\ASN1\Maps\NameConstraints;

/**
 *
 */
final class UserRole
{
    /**
     *
     */
    public const ENVIRONMENT_OWNER = "environment_owner";
    /**
     *
     */
    public const DASHBOARD_OWNER = "dashboard_owner";
    /**
     *
     */
    public const DASHBOARD_CONTRIBUTOR = "dashboard_contributor";

    /**
     *
     */
    private const ROLES_CONFIG = [
        self::ENVIRONMENT_OWNER     => [
            'title' => "Workspace Owner",
            'level' => 1,
        ],
        self::DASHBOARD_OWNER       => [
            'title' => "Report Owner",
            'level' => 2,
        ],
        self::DASHBOARD_CONTRIBUTOR => [
            'title' => "Report Contributor",
            'level' => 3,
        ],
    ];

    /**
     *
     */
    public const AVAILABLE = [self::ENVIRONMENT_OWNER, self::DASHBOARD_OWNER, self::DASHBOARD_CONTRIBUTOR];


    /**
     * @param string $role
     * @param bool $throwable
     * @return bool
     */
    public static function isValid(string $role, bool $throwable = true): bool
    {
        $isValid = in_array($role, self::AVAILABLE);

        if (!$isValid && $throwable) {
            throw new \DomainException("Undefined role: $role");
        }
        return $isValid;
    }

    /**
     * @param string $role
     * @return bool
     */
    public static function isEnvironmentOwner(string $role): bool
    {
        return $role === self::ENVIRONMENT_OWNER;
    }

    /**
     * @param string $role
     * @return bool
     */
    public static function isDashboardOwner(string $role): bool
    {
        return $role === self::DASHBOARD_OWNER;
    }

    /**
     * @param string $role
     * @return bool
     */
    public static function isContributor(string $role): bool
    {
        return $role === self::DASHBOARD_CONTRIBUTOR;
    }

    /**
     * @param string $needle
     * @param bool $includeNeedle
     * @return array
     */
    public static function getLowerLevelRoles(string $needle, bool $includeNeedle = false): array
    {

        $roleConfig = self::ROLES_CONFIG[$needle];

        $result = collect(self::ROLES_CONFIG)
            ->filter(function ($item) use ($roleConfig, $includeNeedle) {
                if ($includeNeedle) {
                    return $item['level'] >= $roleConfig['level'];
                }
                return $item['level'] > $roleConfig['level'];
            })
            ->toArray();

        return array_keys($result);
    }

    /**
     * @param string[] $roles
     * @return null|string
     */
    public static function getMaxRoleOf(array $roles, bool $throwable = true): ?string
    {
        $levels = [];

        if (empty($roles)) {
            if ($throwable) {
                throw new \InvalidArgumentException("roles argument can`t  be empty");
            }

            return null;
        }

        if (count($roles) === 1) {
            return $roles[0];
        }

        foreach ($roles as $role) {
            self::isValid($role);
            $levels[$role] = self::ROLES_CONFIG[$role]['level'];
        }

        $role = array_keys($levels, min($levels));

        return \Arr::first($role);
    }

    /**
     * @param string $x
     * @param string $y
     * @return bool
     */
    public static function isGranded(string $x, string $y): bool
    {
        self::isValid($x);
        self::isValid($y);
        return self::ROLES_CONFIG[$x]['level'] < self::ROLES_CONFIG[$y]['level'];
    }

    /**
     * @param string $x
     * @param string $y
     * @return bool
     */
    public static function isGrandedOrEqual(string $x, string $y): bool
    {
        self::isValid($x);
        self::isValid($y);
        return self::ROLES_CONFIG[$x]['level'] <= self::ROLES_CONFIG[$y]['level'];
    }

    /**
     * @param string $role
     * @return mixed
     */
    public static function getRoleTitle(string $role)
    {
        self::isValid($role);
        return self::ROLES_CONFIG[$role]['title'];
    }
}
