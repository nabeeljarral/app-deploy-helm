<?php

namespace App\Services\User\Enums;

final class UserStatus
{
    const ACTIVE = "active";
    const INACTIVE = "inactive";
    const CREATED = "created";
}
