<?php

namespace App\Services\User\Enums;

final class InvitedUserStatus
{
    public const ACTIVE = "active";
    public const COMPLETED = "completed";
}
