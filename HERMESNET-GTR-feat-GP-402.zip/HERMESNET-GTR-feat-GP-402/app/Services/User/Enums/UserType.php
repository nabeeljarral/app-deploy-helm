<?php

namespace App\Services\User\Enums;

final class UserType
{
    public const REGULAR = "regular";
    public const INVITED = "invited";
}
