<?php

namespace App\Services\User\Invite;

use App\Abstractions\Runnable;
use App\Mail\InviteUserMail;
use App\Models\InvitedUser;
use App\Models\User;
use App\Services\User\DTO\InviteUserDto;
use App\Services\User\Enums\InvitedUserStatus;
use App\Utils\AvatarUtil;
use Illuminate\Support\Facades\Mail;

/**
 *
 */
class SendInviteUser implements Runnable
{
    /**
     * @param User $invitedFrom
     * @param InviteUserDto $inviteDto
     */
    public function __construct(
        private User          $invitedFrom,
        private InviteUserDto $inviteDto
    )
    {
    }

    /**
     * @return mixed|void
     */
    public function run()
    {
        InvitedUser::where('email', $this->inviteDto->getEmail())->delete();

        $invitedUser = $this->createInvitedUser();

        $this->inviteDto->setId($invitedUser->id);

        $mail = new InviteUserMail($this->inviteDto, $this->invitedFrom);
        Mail::to($this->inviteDto->getEmail())->send($mail);
    }

    /**
     * @return InvitedUser
     */
    private function createInvitedUser(): InvitedUser
    {
        return InvitedUser::create([
            "status"          => InvitedUserStatus::ACTIVE,
            "invited_from"    => $this->invitedFrom->id,
            'organization_id' => $this->invitedFrom->organization_id,
            "name"            => $this->inviteDto->getName(),
            "role"            => $this->inviteDto->getRole(),
            "email"           => $this->inviteDto->getEmail(),
            "callback_url"    => $this->inviteDto->getCallbackUrl(),
            'color'           => AvatarUtil::randomColorHex(),
            "environment_id"  => $this->inviteDto->getEnvironmentId(),
            "dashboard_id"    => $this->inviteDto->getDashboardId(),
            "items_id"        => $this->inviteDto->getItemsId(),
        ]);
    }
}
