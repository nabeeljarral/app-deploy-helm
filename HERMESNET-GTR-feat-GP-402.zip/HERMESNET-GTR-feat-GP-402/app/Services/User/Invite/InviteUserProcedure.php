<?php

namespace App\Services\User\Invite;

use App\Abstractions\Queue\DispatchAction;
use App\Abstractions\Runnable;
use App\Mail\InviteUserMail;
use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardUser;
use App\Models\User;
use App\Services\Dashboard\Permissions\ImplementDashboardProtection;
use App\Services\Dashboard\Permissions\UpdateEnvDshProtections;
use App\Services\Dashboard\Permissions\UpdateOrgDshProtection;
use App\Services\User\DTO\InviteUserDto;
use App\Services\User\Enums\UserRole;
use App\Services\User\UserPermissions\CreateUserPermissions;
use App\Services\User\UserPermissions\SetReportItemsPermissions;
use App\Services\User\UserPermissions\UserPermissionDto;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\ValidationException;

/**
 *
 */
class InviteUserProcedure implements Runnable
{
    /**
     * @var User
     */
    private User $existsUser;

    /**
     * @var Collection<DashboardUser>
     */
    private Collection $permissions;

    /**
     * @var string
     */
    private string $previousRole;

    /**
     * @param InviteUserDto $dto
     * @param User $currentUser
     */
    public function __construct(
        private InviteUserDto $dto,
        private User          $currentUser
    )
    {

    }

    /**
     * @return void
     */
    public function run(): void
    {
        $user = User::where('email', $this->dto->getEmail())->first();
        if (!$user) {
            (new SendInviteUser($this->currentUser, $this->dto))->run();
            return;
        }
        $this->existsUser = $user;
        $this->previousRole = $user->role;

        $this->permissions = DashboardUser::query()
            ->where("environment_id", $this->dto->getEnvironmentId())
            ->where("user_id", $this->existsUser->id)
            ->get();

        $this->throwIfOutOfOrganization();

        if ($this->currentlyIsWorkspaceOwner()) {
            return;
        }

        $this->setReportItemsPermissions();

        if ($this->currentlyIsHigherRole()) {
            return;
        }

        $this->createPermissions();
        $this->sendEmail();
        $this->dashboardProtection();

        if ($this->dto->getRole() === UserRole::ENVIRONMENT_OWNER) {
            DashboardUser::where("user_id", $this->currentUser->id)
                ->where("role", "<>", UserRole::ENVIRONMENT_OWNER)
                ->delete();

            $this->currentUser->role = UserRole::ENVIRONMENT_OWNER;
            $this->currentUser->save();
        }
    }

    /**
     * @return void
     */
    private function createPermissions(): void
    {
        $userPermissions = new UserPermissionDto();
        $userPermissions->setRole($this->dto->getRole());
        $userPermissions->setEnvironmentId($this->dto->getEnvironmentId());
        $userPermissions->setDashboardId($this->dto->getDashboardId());

        $createPermissions = new CreateUserPermissions(
            user: $this->existsUser,
            permissionDto: $userPermissions
        );
        $createPermissions->run();
    }

    /**
     * @return void
     */
    private function sendEmail(): void
    {
        $this->dto->setExistUser(true);
        $this->dto->setName($this->existsUser->name);
        $this->dto->setEmail($this->existsUser->email);
        $mail = new InviteUserMail($this->dto, $this->currentUser);
        Mail::to($this->dto->getEmail())->send($mail);
    }

    /**
     * @return void
     */
    private function dashboardProtection(): void
    {
        if (
            $this->previousRole != UserRole::ENVIRONMENT_OWNER
            && $this->dto->getRole() === UserRole::ENVIRONMENT_OWNER
        ) {
            (new UpdateOrgDshProtection($this->currentUser->organization_id))->run();
            return;
        }

        if ($this->dto->getDashboardId()) {
            $dashboard = Dashboard::where('id', $this->dto->getDashboardId())->firstOrFail();
            $implementProtection = new ImplementDashboardProtection($dashboard);
            $implementProtection->setForce(true);
            DispatchAction::of($implementProtection)->afterCommit()->delay(5);
        } else {
            (new UpdateEnvDshProtections($this->dto->getEnvironmentId()))->run();
        }
    }

    /**
     * @return void
     */
    private function setReportItemsPermissions(): void
    {
        if (
            $this->dto->getRole() !== UserRole::DASHBOARD_CONTRIBUTOR
            || empty($this->dto->getItemsId())
            || !$this->dto->getDashboardId()
        ) {
            return;
        }

        (new SetReportItemsPermissions(
            user: $this->existsUser,
            report_id: $this->dto->getDashboardId(),
            items_id: $this->dto->getItemsId(),
        ))->run();
    }

    /**
     * @return void
     */
    private function throwIfOutOfOrganization(): void
    {
        if ($this->existsUser->organization_id != $this->currentUser->organization_id) {
            throw ValidationException::withMessages([
                'email' => 'The email has already been taken.'
            ]);
        }
    }

    /**
     * @return bool
     */
    private function currentlyIsWorkspaceOwner(): bool
    {
        $roles = $this->permissions->pluck('role')->toArray();
        $roles[] = $this->existsUser->getMaxRole();
        return in_array(UserRole::ENVIRONMENT_OWNER, $roles);
    }

    /**
     * @return bool
     */
    private function currentlyIsHigherRole(): bool
    {
        if ($this->dto->getRole() !== UserRole::ENVIRONMENT_OWNER && $this->permissions->isEmpty()) {
            return false;
        }

        $roles = $this->permissions
            ->where("dashboard_id", $this->dto->getDashboardId())
            ->pluck("role")->toArray();

        if (empty($roles)) {
            return false;
        }

        return UserRole::isGrandedOrEqual(UserRole::getMaxRoleOf($roles), $this->dto->getRole());
    }
}
