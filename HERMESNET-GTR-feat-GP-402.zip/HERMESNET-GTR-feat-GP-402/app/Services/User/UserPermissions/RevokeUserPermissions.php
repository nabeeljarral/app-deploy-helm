<?php

namespace App\Services\User\UserPermissions;

use App\Abstractions\Queue\DispatchAction;
use App\Abstractions\Runnable;
use App\Actions\Organization\RevokeOrgFolderPermissions;
use App\Models\Dashboard\DashboardUser;
use App\Models\User;
use App\Models\Views\UsersWithPermissionsView;
use App\Services\User\Enums\UserRole;
use App\Services\User\Enums\UserType;
use App\Utils\GoogleUtil;
use App\Utils\LoggerUtil;
use Carbon\Carbon;
use Google\Service\Drive;

/**
 *
 */
class RevokeUserPermissions implements Runnable
{

    /**
     * @var bool
     */
    protected bool $withOrgFolderPermissions = true;


    /**
     * @param User $user
     * @param UserPermissionDto $permissionDto
     */
    public function __construct(
        private User $user,
        private UserPermissionDto $permissionDto
    )
    {

    }

    /**
     * @return bool
     */
    public function run(): bool
    {
        $dashboardUser = $this->getDashboardUser();

        $this->removeGoogleDrivePermissions($dashboardUser);

        $dashboardUser->delete();

        if ($this->withOrgFolderPermissions) {
            $this->revokeOrgFolderPerms();
        }

        $this->refreshUserPermissions();

        return true;
    }

    /**
     * Remove Google Drive Permissions
     * if role is ENVIRONMENT_OWNER remove environment folder permissions
     * else remove dashboard file permissions
     * @param DashboardUser $dashboardUser
     * @return void
     * @throws \Google\Exception
     */
    private function removeGoogleDrivePermissions(DashboardUser $dashboardUser): void
    {
        if (!$this->user->google_email) {
            return;
        }

        $googleClient = GoogleUtil::apiClient();
        $driveService = new Drive($googleClient);
        $driveService->getClient()->setUseBatch(true);
        $batch = $driveService->createBatch();

        if (UserRole::isEnvironmentOwner($this->permissionDto->getRole())) {
            $fileId = $dashboardUser->environment->folder_id;
        } else {
            $fileId = $dashboardUser->dashboard->file_id;
        }

        $request = $driveService->permissions->delete($fileId, $dashboardUser->permissions_id);
        $batch->add($request, 'dsh_user_' . $dashboardUser->id);
        $batch->execute();
    }

    /**
     * @param bool $withOrgFolderPermissions
     */
    public function setWithOrgFolderPermissions(bool $withOrgFolderPermissions): void
    {
        $this->withOrgFolderPermissions = $withOrgFolderPermissions;
    }

    /**
     * @return DashboardUser
     */
    private function getDashboardUser(): DashboardUser
    {
        LoggerUtil::info("RevokeUserPermissions::run", ['user_id' => $this->user->id, 'role' => $this->permissionDto->getRole()]);

        $dashboardUser = DashboardUser::where('user_id', $this->user->id)
            ->where('role', $this->permissionDto->getRole())
            ->where("environment_id", $this->permissionDto->getEnvironmentId());

        if (!UserRole::isEnvironmentOwner($this->permissionDto->getRole())) {
            $dashboardUser->where('dashboard_id', $this->permissionDto->getDashboardId());
        }
        return $dashboardUser->first();
    }

    /**
     * @return void
     */
    private function revokeOrgFolderPerms(): void
    {
        if (!$this->user->google_email) {
            return;
        }

        if (UserRole::isEnvironmentOwner($this->permissionDto->getRole())) {
            $createOrgPermissions = new RevokeOrgFolderPermissions($this->user);
            $createOrgPermissions->run();
        }
    }

    /**
     * @return void
     */
    private function refreshUserPermissions(): void
    {
        if (!$this->user->google_email) {
            return;
        }

        $userMaxRole = $this->user->getMaxRole();
        if ($userMaxRole && $userMaxRole === UserRole::ENVIRONMENT_OWNER) {
            return;
        }

        $userPermissions = DashboardUser::where("user_id", $this->user->id)
            ->get();

        if ($userPermissions->isEmpty()) {
            return;
        }

        $executionTime = Carbon::now();
        foreach ($userPermissions as $item) {
            $executionTime->addSeconds(5);
            $action = new RefreshUserPermissions($item);
            DispatchAction::of($action)->delay($executionTime);
        }
    }
}
