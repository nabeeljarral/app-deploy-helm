<?php

namespace App\Services\User\UserPermissions;

use App\Abstractions\Queue\DispatchAction;
use App\Abstractions\Runnable;
use App\Actions\Organization\CreateOrgFolderPermissions;
use App\Models\Dashboard\Dashboard;
use App\Models\Environment;
use App\Models\User;
use App\Services\Dashboard\Permissions\AddDashboardUser;
use App\Services\User\Enums\UserRole;
use App\Utils\LoggerUtil;

/**
 *
 */
class CreateUserPermissions implements Runnable
{
    /**
     * @param User $user
     * @param UserPermissionDto $permissionDto
     */
    public function __construct(
        private User $user,
        private UserPermissionDto $permissionDto
    )
    {

    }

    /**
     * @return void
     */
    public function run(): void
    {
        LoggerUtil::info("CreateUserPermissions::run", ['user_id' => $this->user->id, 'role' => $this->permissionDto->getRole()]);

        $environment = Environment::where('id', $this->permissionDto->getEnvironmentId())->firstOrFail();
        $action = new AddDashboardUser(
            user: $this->user,
            environment: $environment,
            role: $this->permissionDto->getRole(),
        );

        if (!UserRole::isEnvironmentOwner($this->permissionDto->getRole())) {
            $dashboard = Dashboard::whereId($this->permissionDto->getDashboardId())->firstOrFail();
            $action->setDashboard($dashboard);
        }
        $action->run();

        if ($this->permissionDto->getRole() === UserRole::ENVIRONMENT_OWNER) {
            $createOrgPermissions = new CreateOrgFolderPermissions($this->user);
            DispatchAction::of($createOrgPermissions)->afterCommit()->delay(5);
        }
    }
}
