<?php

namespace App\Services\User\UserPermissions;

use App\Abstractions\Queue\DispatchAction;
use App\Abstractions\Runnable;
use App\Models\Dashboard\DashboardUser;
use App\Models\User;
use App\Services\User\Enums\UserRole;
use App\Utils\LoggerUtil;
use Illuminate\Support\Collection;

/**
 *
 */
class RefreshAllUserPermissions implements Runnable
{
    /**
     * @var Collection
     */
    private Collection $dshPermissions;

    /**
     * @param User $user
     * @param int|null $targetWorkspaceId
     * @param int|null $targetReportId
     */
    public function __construct(
        private User $user,
        private ?int $targetWorkspaceId = null,
        private ?int $targetReportId = null
    )
    {

    }

    /**
     * @return void
     * @throws \Exception
     */
    public function run(): void
    {
        $this->dshPermissions = DashboardUser::where('user_id', $this->user->id)->get();
        if ($this->dshPermissions->isEmpty()) {
            return;
        }


        $this->refreshTargetEntity();


        $execTime = now()->addSeconds(10);
        foreach ($this->dshPermissions as $dshPermission) {
            DispatchAction::of(new RefreshUserPermissions($dshPermission))->delay($execTime);
            $execTime = $execTime->addSeconds(10);
        }

    }

    /**
     * @return void
     * @throws \Exception
     */
    private function refreshTargetEntity(): void
    {
        if (!$this->targetReportId && !$this->targetWorkspaceId) {
            return;
        }

        $permission = $this->user->getMaxRole() === UserRole::ENVIRONMENT_OWNER
            ? $this->dshPermissions->where('environment_id', $this->targetWorkspaceId)->first()
            : $this->dshPermissions->where('dashboard_id', $this->targetReportId)->first();

        if (!$permission) {
            return;
        }

        (new RefreshUserPermissions($permission))->run();

        LoggerUtil::info("RefreshAllUserPermissions::refreshTargetEntity", ['id' => $permission->id]);

        $this->dshPermissions = $this->dshPermissions->filter(function ($dshPermission) use ($permission) {
            return $dshPermission->id !== $permission->id;
        });
    }
}
