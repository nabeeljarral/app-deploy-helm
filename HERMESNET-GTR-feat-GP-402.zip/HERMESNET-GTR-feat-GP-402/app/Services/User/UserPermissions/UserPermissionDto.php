<?php

namespace App\Services\User\UserPermissions;

use App\Services\User\Enums\UserRole;
use Illuminate\Contracts\Support\Arrayable;

/**
 *
 */
class UserPermissionDto implements Arrayable
{
    protected string $role;

    /**
     * @var int|null
     */
    protected ?int $environment_id = null;

    /**
     * @var int|null
     */
    protected ?int $dashboard_id = null;

    /**
     * @return string
     */
    public function getRole(): string
    {
        return $this->role;
    }

    /**
     * @param string $role
     */
    public function setRole(string $role): void
    {
        if (in_array($role, UserRole::AVAILABLE)) {
            $this->role = $role;
        } else {
            throw new \InvalidArgumentException("invalid role");
        }
    }

    /**
     * @return int|null
     */
    public function getEnvironmentId(): ?int
    {
        return $this->environment_id;
    }

    /**
     * @param int|null $environment_id
     */
    public function setEnvironmentId(?int $environment_id): void
    {
        $this->environment_id = $environment_id;
    }

    /**
     * @return int|null
     */
    public function getDashboardId(): ?int
    {
        return $this->dashboard_id;
    }

    /**
     * @param int|null $dashboard_id
     */
    public function setDashboardId(?int $dashboard_id): void
    {
        $this->dashboard_id = $dashboard_id;
    }

    public function toArray()
    {
        return [
            'environment_id' => $this->getEnvironmentId(),
            'dashboard_id'   => $this->getDashboardId(),
        ];
    }

}
