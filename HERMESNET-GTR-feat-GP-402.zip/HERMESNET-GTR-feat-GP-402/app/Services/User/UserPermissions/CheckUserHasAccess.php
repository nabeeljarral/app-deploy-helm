<?php

namespace App\Services\User\UserPermissions;

use App\Models\Dashboard\DashboardUser;
use App\Models\User;
use App\Services\User\Enums\UserRole;

class CheckUserHasAccess
{
    public function __construct(
        private User $user,
        private int $environmentId,
        private ?int $dashboardId = null,
    )
    {

    }

    public function check():bool {

        if ($this->user->is_admin === true) {
            return  true;
        }

        if (
            $this->user->getMaxRole() === UserRole::ENVIRONMENT_OWNER
            || $this->user->isOrganizationOwner()
        ) {
            return true;
        }

        $query = DashboardUser::where("user_id", $this->user->id)
            ->where("environment_id", $this->environmentId);

        if ($this->dashboardId) {
            $query->where("dashboard_id", $this->dashboardId);
        }

        return $query->exists();
    }

}
