<?php

namespace App\Services\User\UserPermissions;

use App\Abstractions\Queue\DispatchAction;
use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardUser;
use App\Models\Environment;
use App\Services\Dashboard\Permissions\ImplementDashboardProtection;
use App\Services\Dashboard\Permissions\SaveDashboardProtection;
use App\Services\Dashboard\Permissions\UpdateEnvDshProtections;
use App\Services\Dashboard\Permissions\UpdateOrgDshProtection;
use App\Services\User\Enums\UserRole;
use App\Utils\LoggerUtil;
use App\Models\User;
use Carbon\Carbon;

/**
 *
 */
class UpdateUserPermissions implements Runnable
{
    /**
     * @var User
     */
    protected User $user;

    /**
     * @param DashboardUser $currentPermissions
     * @param UserPermissionDto $newPermissionDto
     */
    public function __construct(
        private DashboardUser $currentPermissions,
        private UserPermissionDto $newPermissionDto,
    )
    {

    }

    /**
     * @return void
     */
    public function run(): void
    {
        LoggerUtil::info("UpdateUserPermissions:run", [
            'user_id'      => $this->currentPermissions->user_id,
            'current_role' => $this->currentPermissions->role,
            'new_role'     => $this->newPermissionDto->getRole(),
        ]);

        if (!$this->isDirty()) {
            return;
        }

        $this->user = $this->currentPermissions->user;

        $this->revoke();
        sleep(3);
        $this->create();

        $this->implementDashboardProtection();

        if ($this->newPermissionDto->getRole() === UserRole::ENVIRONMENT_OWNER) {
            DashboardUser::where("user_id", $this->user->id)
                ->where("role", "<>", UserRole::ENVIRONMENT_OWNER)
                ->delete();

            $this->user->role = UserRole::ENVIRONMENT_OWNER;
            $this->user->save();
        }
    }

    /**
     * @return void
     */
    private function revoke(): void
    {
        $revokeAction = new RevokeUserPermissions(
            user: $this->user,
            permissionDto: $this->currentPermissions->getPermissionDto()
        );
        if (UserRole::isEnvironmentOwner($this->newPermissionDto->getRole())) {
            $revokeAction->setWithOrgFolderPermissions(false);
        }
        $revokeAction->run();
    }

    /**
     * @return void
     */
    private function create(): void
    {
        $createAction = new CreateUserPermissions(
            user: $this->user,
            permissionDto: $this->newPermissionDto,
        );
        $createAction->run();
    }

    /**
     * @return void
     */
    public function implementDashboardProtection(): void
    {
        if ($this->newPermissionDto->getRole() === UserRole::ENVIRONMENT_OWNER) {
            $environment = Environment::where('id', $this->newPermissionDto->getEnvironmentId())
                ->firstOrFail();

            (new UpdateOrgDshProtection($environment->organization_id))->run();
            return;
        }

        if ($this->newPermissionDto->getDashboardId()) {
            $dashboard = Dashboard::where('id', $this->newPermissionDto->getDashboardId())->firstOrFail();
            $implementProtection = new ImplementDashboardProtection($dashboard);
            $implementProtection->setForce(true);
            DispatchAction::of($implementProtection)->afterCommit()->delay(5);
        } else {
            (new UpdateEnvDshProtections($this->newPermissionDto->getEnvironmentId()))->run();
        }
    }

    /**
     * @return bool
     */
    private function isDirty(): bool
    {
        return $this->currentPermissions->role != $this->newPermissionDto->getRole()
            || $this->currentPermissions->environment_id != $this->newPermissionDto->getEnvironmentId()
            || $this->currentPermissions->dashboard_id != $this->newPermissionDto->getDashboardId();
    }
}
