<?php

namespace App\Services\User\UserPermissions;

use App\Abstractions\Runnable;
use App\Models\Dashboard\DashboardUser;
use App\Services\Google\Enums\GoogleDriveFileRole;
use App\Services\Google\Permissions\CreateFilePermissions;
use App\Services\User\Enums\UserRole;
use App\Utils\LoggerUtil;

/**
 *
 */
class RefreshUserPermissions implements Runnable
{
    /**
     * @param DashboardUser $dashboardUser
     */
    public function __construct(
        private DashboardUser $dashboardUser
    )
    {

    }

    /**
     * @return void
     * @throws \Exception
     */
    public function run(): void
    {
        LoggerUtil::info("RefreshUserPermissions::run", ['id' => $this->dashboardUser->id]);

        if (UserRole::isEnvironmentOwner($this->dashboardUser->role)) {
            $fileId = $this->dashboardUser->environment->folder_id;
        } else {
            $fileId = $this->dashboardUser->dashboard->file_id;
        }

        $action = new CreateFilePermissions(
            $fileId,
            GoogleDriveFileRole::WRITER,
            $this->dashboardUser->user->google_email,
        );

        $filePermissions = $action->run();
        $permissions_id = $filePermissions->getId();

        $this->dashboardUser->permissions_id = $permissions_id;
        $this->dashboardUser->save();
    }
}
