<?php

namespace App\Services\User\UserPermissions;

use App\Abstractions\Runnable;
use App\Models\Dashboard\DashboardUser;
use App\Models\User;
use App\Services\User\Enums\UserRole;

class CheckCanManagePermission implements Runnable
{
    public function __construct(
        private DashboardUser $permission,
        private User $currentUser
    )
    {

    }

    public function run(): bool
    {
        $organization = $this->currentUser->organization;

        if (
            $this->currentUser->getMaxRole() === UserRole::ENVIRONMENT_OWNER
            || $this->currentUser->id === $organization->user_id
        ) {
            return true;
        }

        $currentUserPermissions = DashboardUser::where("user_id", $this->currentUser->id)
            ->where("environment_id", $this->permission->environment_id)
            ->get();

        if ($currentUserPermissions->isEmpty()) {
            return false;
        }

        $dashboardRoles = $currentUserPermissions->where("dashboard_id", $this->permission->dashboard_id)
            ->pluck("role")
            ->toArray();

        if (empty($dashboardRoles)) {
            return false;
        }

        return UserRole::isGrandedOrEqual(UserRole::getMaxRoleOf($dashboardRoles), $this->permission->role);
    }
}
