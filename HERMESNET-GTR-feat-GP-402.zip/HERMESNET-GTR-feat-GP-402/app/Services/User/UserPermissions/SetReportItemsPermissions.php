<?php

namespace App\Services\User\UserPermissions;

use App\Abstractions\Runnable;
use App\Models\Dashboard\ReportItemPermissions;
use App\Models\User;

/**
 *
 */
class SetReportItemsPermissions implements Runnable
{
    protected array $items_id;

    /**
     * @param User $user
     * @param int $report_id
     * @param array $items_id
     */
    public function __construct(
        protected User  $user,
        protected int   $report_id,
        array $items_id,
    )
    {
        $this->items_id = array_values(array_unique($items_id));
    }

    /**
     * @return ReportItemPermissions
     */
    public function run(): ?ReportItemPermissions
    {
        if (empty($this->items_id)) {
            return null;
        }

        $permissions = ReportItemPermissions::where("user_id", $this->user->id)
            ->where('report_id', $this->report_id)
            ->first();

        if ($permissions) {
            //$items_ids = array_merge($permissions->items_id, $this->items_id);
            //$permissions->items_id = array_unique($items_ids);
            $permissions->items_id = $this->items_id;
            $permissions->save();
            return $permissions;
        }

        return ReportItemPermissions::create([
            'user_id'   => $this->user->id,
            'report_id' => $this->report_id,
            'items_id'  => $this->items_id,
        ]);
    }
}
