<?php

namespace App\Services\User;

use App\Abstractions\Runnable;
use App\Models\Dashboard\DashboardUser;
use App\Models\User;
use App\Services\User\UserPermissions\RevokeUserPermissions;
use App\Utils\LoggerUtil;

/**
 *
 */
class RemoveUser implements Runnable
{

    /**
     * @param User $user
     */
    public function __construct(
        private User $user
    )
    {
    }

    /**
     * @return bool
     */
    public function run(): bool
    {
        LoggerUtil::info("RemoveUser::run", ['user_id' => $this->user->id]);

        $this->revokePermissions();

        return $this->user->delete();
    }

    /**
     * @return void
     */
    private function revokePermissions(): void
    {
        $userPermissions = DashboardUser::where("user_id", $this->user->id)->get();
        foreach ($userPermissions as $permission) {
            try {
                $action = new RevokeUserPermissions($this->user, $permission->getPermissionDto());
                $action->setWithOrgFolderPermissions(true);
                $action->run();
            }
            catch (\Exception $exception) {

            }
        }
    }
}
