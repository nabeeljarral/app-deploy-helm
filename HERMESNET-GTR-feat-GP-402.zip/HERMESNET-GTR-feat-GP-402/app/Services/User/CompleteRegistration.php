<?php

namespace App\Services\User;

use App\Abstractions\Queue\DispatchAction;
use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Models\InvitedUser;
use App\Models\User;
use App\Services\Dashboard\Permissions\ImplementDashboardProtection;
use App\Services\Dashboard\Permissions\UpdateOrgDshProtection;
use App\Services\User\Enums\UserRole;
use App\Services\User\UserPermissions\CreateUserPermissions;
use App\Services\User\UserPermissions\SetReportItemsPermissions;
use App\Services\User\UserPermissions\UserPermissionDto;
use App\Utils\LoggerUtil;

/**
 * Complete Invited Uer Registration
 */
class CompleteRegistration implements Runnable
{
    /**
     * @var InvitedUser
     */
    private InvitedUser $invitedUser;

    /**
     * @var User
     */
    private User $user;

    /**
     * @param InvitedUser $invitedUser
     * @param User $user
     */
    public function __construct(
        InvitedUser $invitedUser,
        User        $user,
    )
    {

        $this->invitedUser = $invitedUser;
        $this->user = $user;
    }

    /**
     * @return void
     */
    public function run(): void
    {
        LoggerUtil::info("CompleteRegistration::run", [
            'user_id' => $this->user->id,
        ]);

        $userPermissions = new UserPermissionDto();
        $userPermissions->setRole($this->invitedUser->role);
        $userPermissions->setEnvironmentId($this->invitedUser->environment_id);
        $userPermissions->setDashboardId($this->invitedUser->dashboard_id);

        $createPermissions = new CreateUserPermissions(
            user: $this->user,
            permissionDto: $userPermissions
        );
        $createPermissions->run();

        $this->implementDshProtection($userPermissions);
        $this->createReportItemsPermission();

        $this->invitedUser->delete();
    }

    /**
     * @return void
     */
    private function createReportItemsPermission(): void
    {
        if (empty($this->invitedUser->items_id) && !$this->invitedUser->dashboard_id) {
            return;
        }
        (new SetReportItemsPermissions(
            user: $this->user,
            report_id: $this->invitedUser->dashboard_id,
            items_id: $this->invitedUser->items_id)
        )->run();
    }

    /**
     * @param UserPermissionDto $userPermissions
     * @return void
     */
    private function implementDshProtection(UserPermissionDto $userPermissions): void
    {
        if (!$this->user->google_email) {
            return;
        }

        if ($userPermissions->getRole() === UserRole::ENVIRONMENT_OWNER) {
            (new UpdateOrgDshProtection($this->invitedUser->organization_id))->run();
            return;
        }

        $dashboard = Dashboard::where('id', $userPermissions->getDashboardId())->first();
        if (!$dashboard) {
            return;
        }

        $implementProtections = new ImplementDashboardProtection($dashboard);
        $implementProtections->setForce(true);
        DispatchAction::of($implementProtections)->delay(5);
    }
}
