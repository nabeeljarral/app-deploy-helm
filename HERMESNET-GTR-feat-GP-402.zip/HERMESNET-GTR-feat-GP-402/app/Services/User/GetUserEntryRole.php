<?php

namespace App\Services\User;

use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardUser;
use App\Models\Environment;
use App\Models\User;
use App\Services\User\Enums\UserRole;
use Illuminate\Support\Collection;

class GetUserEntryRole implements Runnable
{
    /**
     * @var Collection<DashboardUser>
     */
    private Collection $permission;

    /**
     * @param User $user
     * @param Environment|Dashboard|null $entry
     * @param bool $initialRole
     */
    public function __construct(
        private User                       $user,
        private null|Environment|Dashboard $entry = null,
        protected bool                     $initialRole = false,
    )
    {

    }

    /**
     * @param User $user
     * @param Environment|Dashboard|null $entry
     * @param bool $initialRole
     * @return string|null
     */
    public static function get(
        User                       $user,
        null|Environment|Dashboard $entry = null,
        bool                       $initialRole = false
    ): ?string
    {
        return (new self($user, $entry, $initialRole))->run();
    }

    /**
     * @return string|null
     */
    public function run(): ?string
    {
        $this->permission = DashboardUser::where("user_id", $this->user->id)->get();
        if ($this->permission->isEmpty()) {
            return $this->getInitialRole();
        }

        if (!$this->entry) {
            return $this->getMaxRole();
        }

        if ($this->entry instanceof (Environment::class)) {
            $role = $this->workspaceRole();
        } else {
            $role = $this->reportRole();
        }

        return $role ?? $this->getInitialRole();
    }

    /**
     * @return string|null
     */
    private function getInitialRole(): ?string
    {
        return $this->initialRole ? $this->user->role : null;
    }

    /**
     * @return string|null
     */
    private function getMaxRole(): ?string
    {
        $roles = $this->permission
            ->pluck("role")
            ->toArray();
        $maxRole = UserRole::getMaxRoleOf($roles, false);

        return $maxRole ?? $this->getInitialRole();
    }

    /**
     * @return string|null
     */
    private function workspaceRole(): ?string
    {
        $roles = $this->permission
            ->where('environment_id', $this->getWorkspaceId())
            ->pluck("role")
            ->toArray();
        return UserRole::getMaxRoleOf($roles, false);
    }

    /**
     * @return string|null
     */
    private function reportRole(): ?string
    {
        $workspaceRole = $this->workspaceRole();
        if ($workspaceRole === UserRole::ENVIRONMENT_OWNER) {
            return $workspaceRole;
        }

        $roles = $this->permission
            ->where('dashboard_id', $this->entry->id)
            ->pluck("role")
            ->toArray();

        return UserRole::getMaxRoleOf($roles, false);
    }

    /**
     * @return int
     */
    private function getWorkspaceId(): int
    {
        if ($this->entry instanceof Environment) {
            return $this->entry->id;
        } else {
            return $this->entry->environment_id;
        }
    }
}
