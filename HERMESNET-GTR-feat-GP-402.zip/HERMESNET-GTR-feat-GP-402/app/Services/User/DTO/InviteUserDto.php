<?php

namespace App\Services\User\DTO;

use App\Abstractions\DataTransferObject;
use App\Services\User\Enums\UserRole;
use App\Utils\UrlUtil;
use Illuminate\Support\Facades\Crypt;

/**
 *
 */
class InviteUserDto extends DataTransferObject
{

    /**
     * @var int|null
     */
    protected ?int $id = null;

    /**
     * @var string
     */
    protected string $name;

    /**
     * @var string
     */
    protected string $email;

    /**
     * @var string
     */
    protected string $role;

    /**
     * @var int|null
     */
    protected ?int $environment_id = null;

    /**
     * @var int|null
     */
    protected ?int $dashboard_id = null;

    /**
     * @var bool
     */
    protected bool $exist_user = false;

    /**
     * @var array
     */
    protected array $items_id = [];

    /**
     * @param array $attributes
     * @return static
     */
    public static function of(array $attributes): static
    {
        $self = new static();

        $self->setName(\Arr::get($attributes, "name"));
        $self->setEmail(\Arr::get($attributes, "email"));
        $self->setRole(\Arr::get($attributes, "role"));
        $self->setEnvironmentId(\Arr::get($attributes, "environment_id"));
        $self->setDashboardId(\Arr::get($attributes, "dashboard_id"));
        $self->setExistUser(\Arr::get($attributes, "exist_user", false));
        $self->setItemsId(\Arr::get($attributes, "items_id", []));

        return $self;
    }

    /**
     * @return array
     */
    public function toArray(): array
    {
        return [
            'id'             => $this->getId(),
            'name'           => $this->getName(),
            'email'          => $this->getEmail(),
            'role'           => $this->getRole(),
            'role_title'     => UserRole::getRoleTitle($this->getRole()),
            'environment_id' => $this->getEnvironmentId(),
            'dashboard_id'   => $this->getDashboardId(),
            'exists_user'    => $this->isExistUser(),
            'callback_url'   => $this->getCallbackUrl(),
            'login_url'      => $this->getLoginUrl(),
            'items_id'       => $this->items_id,
        ];
    }

    /**
     * @return int|null
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @param int|null $id
     */
    public function setId(?int $id): void
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @return string
     */
    public function getEmail(): string
    {
        return $this->email;
    }

    /**
     * @param string $email
     */
    public function setEmail(string $email): void
    {
        $this->email = $email;
    }

    /**
     * @return string
     */
    public function getRole(): string
    {
        return $this->role;
    }


    /**
     * @param string $role
     */
    public function setRole(string $role): void
    {
        $this->role = $role;
    }

    /**
     * @return int|null
     */
    public function getEnvironmentId(): ?int
    {
        return $this->environment_id;
    }

    /**
     * @param int|null $environment_id
     */
    public function setEnvironmentId(?int $environment_id): void
    {
        $this->environment_id = $environment_id;
    }

    /**
     * @return int|null
     */
    public function getDashboardId(): ?int
    {
        return $this->dashboard_id;
    }

    /**
     * @param int|null $dashboard_id
     */
    public function setDashboardId(?int $dashboard_id): void
    {
        $this->dashboard_id = $dashboard_id;
    }

    /**
     * @return bool
     */
    public function isExistUser(): bool
    {
        return $this->exist_user;
    }

    /**
     * @param bool $exist_user
     */
    public function setExistUser(bool $exist_user): void
    {
        $this->exist_user = $exist_user;
    }

    /**
     * @return string
     */
    public function getCallbackUrl(): string
    {
        $state = Crypt::encrypt($this->getEmail());
        return UrlUtil::of(config("app.url"))
            ->join("/auth/invite-callback")
            ->setQueryPrams([
                'state' => $state
            ])
            ->getValue();
    }

    /**
     * @return string
     */
    public function getLoginUrl(): string
    {
        return UrlUtil::of(config("app.url"))
            ->join("/auth/login")
            ->getValue();
    }

    /**
     * @param mixed $items_id
     * @return void
     */
    public function setItemsId(mixed $items_id): void
    {
        if (is_array($items_id)) {
            $this->items_id = $items_id;
        }
    }

    /**
     * @return array
     */
    public function getItemsId(): array
    {
        return $this->items_id;
    }
}
