<?php

namespace App\Services\PrintConfiguration\Enums;

final class LinkSource
{
    public const GOOGLE_SHEET = "google_sheet";
    public const ITEM_CONTENT = "item_content";
}
