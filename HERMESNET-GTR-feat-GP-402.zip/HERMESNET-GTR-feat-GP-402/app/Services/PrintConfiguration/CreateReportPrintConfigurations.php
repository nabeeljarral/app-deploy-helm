<?php

namespace App\Services\PrintConfiguration;

use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardProtection;
use App\Models\Dashboard\DashboardUnprotectedRange;
use App\Models\Dashboard\DashboardUser;
use App\Models\Template\Template;
use App\Models\User;
use App\Models\Views\UsersWithPermissionsView;
use App\Services\Google\Enums\GoogleDriveFileRole;
use App\Services\Google\Permissions\ProtectedRange\ProtectSheet;
use App\Services\PrintConfiguration\Templates\CustomPrintConfiguration;
use App\Services\User\Enums\UserRole;
use App\Services\User\Enums\UserType;
use App\Transformers\PrintConfiguration\PrintConfTemplateTransformer;
use App\Utils\GoogleUtil;
use App\Utils\LoggerUtil;
use Google\Service\Drive;
use Google\Service\Sheets;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Spatie\Fractalistic\ArraySerializer;

/**
 * Create Print Configurations for Report
 */
class CreateReportPrintConfigurations implements Runnable
{
    /**
     * @var int
     */
    private int $organization_id;


    /**
     * @var Dashboard
     */
    private Dashboard $dashboard;

    /**
     * @var Template
     */
    private Template $template;

    /**
     * @var CustomPrintConfiguration
     */
    private CustomPrintConfiguration $printConfiguration;

    /**
     * @param Dashboard $dashboard
     */
    public function __construct(
        int $organization_id,
        Dashboard $dashboard
    )
    {
        $this->organization_id = $organization_id;
        $this->dashboard = $dashboard;
        $this->template = $dashboard->globalTemplate;
        $this->printConfiguration = app(CustomPrintConfiguration::class);
    }

    /**
     * @return void
     * @throws \Exception
     */
    public function run(): void
    {
        logger()->info("CreateReportPrintConfigurations::run", ['dashboard_id' => $this->dashboard->id]);

        $printConfigurations = $this->template->printConfTemplates()
            ->where(function ($query) {
                $query->where("organization_id", null)
                    ->orWhere("organization_id", $this->organization_id);
            })->get();

        foreach ($printConfigurations as $printConfTemplate) {
            $printConfTemplate = fractal($printConfTemplate)
                ->transformWith(new PrintConfTemplateTransformer())
                ->parseIncludes('elements')
                ->serializeWith(ArraySerializer::class)
                ->toArray();

            $printConfTemplate['organization_id'] = $this->organization_id;
            $printConfTemplate['report_id'] = $this->dashboard->id;
            $printConfTemplate['print_conf_template_id'] = $printConfTemplate['id'];

            $clonedPrintConfTemplate = $this->printConfiguration->clonePrintConfTemplate($printConfTemplate, false);
        }
    }
}
