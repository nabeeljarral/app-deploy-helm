<?php

namespace App\Services\PrintConfiguration;

use App\Models\PrintConfTemplate;

class TemplateRepository
{
    public function createTemplate(array $data): PrintConfTemplate
    {
        $template = new PrintConfTemplate();
        $template->fill($data);
        $template->save();
        return $template;
    }

    public function getTemplateById($id){
        return PrintConfTemplate::find($id);
    }

    public function deleteTemplate($id){
            $template = PrintConfTemplate::find($id);
            return $template->delete();
    }

    public function deleteActiveBlankTemplate(): void
    {
        $template = PrintConfTemplate::where(['is_blank' => '1'])->first();
        if($template){
            $template->delete();
        }
    }

    public function getPrintConfTemplatesByTemplateId($id)
    {
        return PrintConfTemplate::where(['template_id' => $id])->get();
    }

    public function getPrintConfTemplatesByReportId($id)
    {
        return PrintConfTemplate::where(['report_id' => $id])->get();
    }
}
