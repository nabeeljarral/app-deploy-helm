<?php

namespace App\Services\PrintConfiguration\DTO;

class PrintingConfigurationDTO
{
    private array $templateDataConfig;

    private array $mandatoryFields;

    public function __construct(array $templateDataConfig, array $mandatoryFields)
    {
        $this->templateDataConfig = $templateDataConfig;
        $this->mandatoryFields = $mandatoryFields;
    }

    public function getTemplateDataConfig(): array
    {
        return $this->templateDataConfig;
    }

    public function setTemplateDataConfig(array $templateDataConfig): void
    {
        $this->templateDataConfig = $templateDataConfig;
    }

    public function getMandatoryFields(): array
    {
        return $this->mandatoryFields;
    }

    public function setMandatoryFields(array $mandatoryFields): void
    {
        $this->mandatoryFields = $mandatoryFields;
    }

}
