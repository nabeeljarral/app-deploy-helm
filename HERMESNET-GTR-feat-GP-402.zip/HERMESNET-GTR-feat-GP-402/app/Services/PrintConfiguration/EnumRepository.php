<?php

namespace App\Services\PrintConfiguration;

use App\Models\PrintConfEnum;

class EnumRepository
{
    public function createEnum(array $data)
    {
        return PrintConfEnum::create([
            'name'   => $data['name'],
            'values' => $data['values']
        ]);
    }

    public function getEnum($id)
    {
        return PrintConfEnum::find($id);
    }

    public function getEnumByName(string $name)
    {
        return PrintConfEnum::where(['name' => $name])->first();
    }

    public function updateEnumValue(string $name, array $values): void
    {
        $enum = $this->getEnumByName($name);
        $enum->values = $values;
        $enum->save();
    }
}
