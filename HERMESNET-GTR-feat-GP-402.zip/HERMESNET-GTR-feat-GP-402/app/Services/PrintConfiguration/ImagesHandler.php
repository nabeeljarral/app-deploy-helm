<?php

namespace App\Services\PrintConfiguration;

use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Storage;

class ImagesHandler
{
    public function saveImage(UploadedFile $image): string
    {
        try {
            $imageName = uniqid() . '.' . $image->extension();
            $image->storeAs('/public/images', $imageName);

            return env('APP_URL') . '/api/images/' . $imageName;
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }

    }
    public function cloneImage(string $url): string
    {
        try {
            $fileName = basename($url);
            $newFileName = uniqid() . '.' . pathinfo($url, \PATHINFO_EXTENSION);

            $sourcePath = storage_path('app/public/images/' . $fileName);
            $destinationPath = storage_path('app/public/images/' . $newFileName);
            File::copy($sourcePath, $destinationPath);

            return env('APP_URL') . '/api/images/' . $newFileName;
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    public function deleteImage(string $url): \Illuminate\Http\JsonResponse
    {
        try {
            $fileName = str_replace('/api/', '', parse_url($url, PHP_URL_PATH));

            $filePath = 'public/' . $fileName;
            Storage::delete($filePath);

            return response()->json(['message' => 'File deleted successfully']);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    public function getImage(string $fileName): \Illuminate\Http\Response| \Illuminate\Http\JsonResponse
    {

        $path = storage_path('app/public/images/' . $fileName);

        if (!file_exists($path)) {
            return response()->json(['error' => 'File not found'], 404);
        }

        $file = Storage::get('public/images/' . $fileName);
        $type = Storage::mimeType('public/images/' . $fileName);

        $response = Response::make($file, 200);
        $response->header('Content-Type', $type);

        return $response;
    }

}
