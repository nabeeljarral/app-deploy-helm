<?php

namespace App\Services\PrintConfiguration\Templates;

use App\Services\PrintConfiguration\EnumRepository;
use App\Services\PrintConfiguration\ImagesHandler;
use App\Services\PrintConfiguration\ParameterRepository;
use App\Utils\LoggerUtil;
use Exception;

class ParametersHandler
{
    public function __construct(
        protected ParameterRepository $parameterRepository,
        protected EnumRepository      $enumRepository,
        protected ImagesHandler $imagesHandler
    )
    {
    }

    /**
     * @throws Exception
     */
    public function saveElementParameters(array $parameters, int $elementId): void
    {
        try {
            foreach ($parameters as $parameter) {

                $enumId = null;
                if (isset($parameter['enum'])) {
                    $enumId = $parameter['enum']['id'];
                }
                $this->parameterRepository->createParameter($elementId, $parameter, $enumId);
            }
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

    }

    /**
     * @throws Exception
     */
    public function cloneElementParameters(array $parameters, int $elementId): void
    {
        try {
            foreach ($parameters as $parameter) {

                $enumId = null;
                if (isset($parameter['enum'])) {
                    $enumId = $parameter['enum']['id'];
                }

                if(strtolower($parameter['type']) === 'image' && isset($parameter['value'])){
                    $parameter['value'] = $this->imagesHandler->cloneImage($parameter['value']);
                }

                $this->parameterRepository->createParameter($elementId, $parameter, $enumId);
            }
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

    }

    /**
     * @throws Exception
     */
    public function updateParameters(array $updateData, $elementId): void
    {
        try {
            foreach ($updateData as $parameterData) {
                $parameter = $this->parameterRepository->getParameterByNameAndElementId($parameterData['name'], $elementId);
                if ($parameter) {
                    unset($parameterData['print_conf_element_id']);
                    $parameter->update($parameterData);
                } else {
                    $enumId = null;
                    if (isset($parameterData['enum'])) {
                        $enumId = $parameterData['enum']['id'];
                    }
                    $this->parameterRepository->createParameter($elementId, $parameterData, $enumId);
                }
            }
        } catch (Exception $e) {
            LoggerUtil::exception($e);
            throw new Exception($e->getMessage());
        }
    }

    public function saveParametersFromJson(array $parameters, int $elementId): void
    {
        foreach ($parameters as $parameter) {
            $enumId = null;
            if (isset($parameter['enum'])) {
                $enumId = $this->enumRepository->getEnumByName($parameter['enum'])->id;
            }
            $this->parameterRepository->createParameter($elementId, $parameter, $enumId);
        }
    }

    public function deleteImages($parameters): void
    {
        foreach ($parameters as $parameter){
            if(strtolower($parameter->type) === 'image' && isset($parameter->value)){
                $this->imagesHandler->deleteImage($parameter->value);
            }
        }
    }

}
