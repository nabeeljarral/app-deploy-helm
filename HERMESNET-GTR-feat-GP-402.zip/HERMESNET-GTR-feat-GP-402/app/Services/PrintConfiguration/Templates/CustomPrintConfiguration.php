<?php

namespace App\Services\PrintConfiguration\Templates;

use App\Models\PrintConfTemplate;
use App\Models\Template\Template;
use App\Services\PrintConfiguration\EnumRepository;
use App\Services\PrintConfiguration\TemplateRepository;
use App\Utils\LoggerUtil;
use Exception;
use Illuminate\Support\Facades\DB;

class CustomPrintConfiguration
{
    public function __construct(
        protected TemplateRepository $templateRepository,
        protected EnumRepository $enumRepository,
        protected ElementsHandler $elementsHandler
    )
    {
    }

    /**
     * @param Template $template
     * @param array $templateData
     * @return PrintConfTemplate
     * @throws Exception
     */
    public function saveCustomTemplate(Template $template, array $templateData): \Illuminate\Database\Eloquent\Model
    {
        try {
            DB::beginTransaction();
            $customTemplate = $template->printConfTemplates()->create($templateData);
            $this->saveTemplateEnums($templateData);
            if (isset($templateData['elements'])){
                $this->elementsHandler->saveTemplateElements($templateData['elements'], $customTemplate->id);
            }

            DB::commit();

            return $customTemplate;
        } catch (Exception $exception) {
            DB::rollBack();
            throw $exception;
        }
    }

    protected function saveTemplateEnums(array $templateData): void
    {
        if (isset($templateData['enums'])) {
            $enums = $templateData['enums'];
            foreach ($enums as $enum) {
                if (!$this->enumRepository->getEnumByName($enum['name'])) {
                    $this->enumRepository->createEnum($enum);
                }
            }
        }
    }

    public function deleteTemplate(PrintConfTemplate $template): void
    {
        try {
            $this->elementsHandler->deleteElementsImages($template->allElements);
            $template->delete();
        } catch (Exception $exception) {
            LoggerUtil::exception($exception);
        }

    }

    /**
     * @param PrintConfTemplate $printConfTemplate
     * @param array $updateData
     * @return PrintConfTemplate
     * @throws Exception
     */
    public function updatePrintConfTemplate(
        PrintConfTemplate $printConfTemplate,
        array $updateData
    ): PrintConfTemplate
    {
        try {
            $printConfTemplate->update($updateData);
            $templateElementsIds = $printConfTemplate->allElements->pluck('id')->toArray();
            $updatedElementsIds = $this->elementsHandler->updateOrCreateElements($updateData['elements'],
                $printConfTemplate->id);
            $idsToDelete = $this->elementsHandler->getIdsToDelete($updatedElementsIds, $templateElementsIds);
            $this->elementsHandler->BulkDeleteElementsByIds($idsToDelete);

            return $printConfTemplate;
        } catch (Exception $exception) {
            throw $exception;
        }
    }

    /**
     * @param array $printConfTemplate
     * @return PrintConfTemplate
     * @throws Exception
     */
    public function clonePrintConfTemplate(array $printConfTemplate, bool $copyMark = true): PrintConfTemplate
    {
        try {
            DB::beginTransaction();
            if ($copyMark) {
                $printConfTemplate['template_name'] .= '(copy)';
            }
            $customTemplate = $this->templateRepository->createTemplate([
                'template_name'          => $printConfTemplate['template_name'],
                'organization_id'        => $printConfTemplate['organization_id'],
                'template_id'            => $printConfTemplate['template_id'],
                'report_id'              => $printConfTemplate['report_id'] ?? null,
                'print_conf_template_id' => $printConfTemplate['print_conf_template_id'] ?? null,
                'is_blank'               => false
            ]);
            $this->elementsHandler->cloneTemplateElements($printConfTemplate['elements'], $customTemplate->id);

            DB::commit();

            return $customTemplate;
        } catch (Exception $exception) {
            DB::rollBack();
            throw $exception;
        }
    }

    public function updateElement(array $elementData)
    {
        return $this->elementsHandler->updateElement($elementData);
    }

    public function checkNameInTemplate(mixed $id, mixed $templateName)
    {
        $printConfigurationTemplates = $this->templateRepository->getPrintConfTemplatesByTemplateId($id);
        return $printConfigurationTemplates->contains('template_name', $templateName);
    }

    public function checkNameInReport($id, $templateName)
    {
        $printConfigurationTemplates = $this->templateRepository->getPrintConfTemplatesByReportId($id);
        return $printConfigurationTemplates->contains('template_name', $templateName);
    }
}
