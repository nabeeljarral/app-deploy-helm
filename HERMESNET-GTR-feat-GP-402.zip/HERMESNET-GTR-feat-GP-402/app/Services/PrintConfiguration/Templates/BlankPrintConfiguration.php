<?php

namespace App\Services\PrintConfiguration\Templates;

use App\Services\PrintConfiguration\EnumRepository;
use App\Services\PrintConfiguration\TemplateRepository;
use Exception;
use Illuminate\Support\Facades\DB;

class BlankPrintConfiguration
{
    public function __construct(
        protected TemplateRepository $templateRepository,
        protected EnumRepository $enumRepository,
        protected ElementsHandler $elementsHandler
    )
    {
    }

    /**
     * @throws Exception
     */
    public function updateBlankTemplate(array $templateData): string
    {
        $this->deletePreviousElements();
        return $this->saveBlankTemplate($templateData);
    }

    /**
     * @throws Exception
     */
    public function saveBlankTemplate(array $templateData): string
    {
        try {
            DB::beginTransaction();

            $newTemplate = $this->templateRepository->createTemplate( [
                'template_name' => 'blank-template-' . date('d-m-Y'),
                'is_blank'      => true
            ]);
            $this->saveTemplateEnums($templateData);
           $this->elementsHandler->saveElementsFromJson($templateData['elements'], $newTemplate->id);

            DB::commit();

            return 'Template Saved Successfully';
        } catch (Exception $exception) {
            DB::rollBack();
            throw $exception;
        }
    }

    protected function saveTemplateEnums(array $templateData): void
    {
        if (isset($templateData['enums'])) {
            $enums = $templateData['enums'];
            foreach ($enums as $enum) {
                $existingEnum = $this->enumRepository->getEnumByName($enum['name']);
                if (!$existingEnum) {
                    $this->enumRepository->createEnum($enum);
                } else {
                    $this->enumRepository->updateEnumValue($existingEnum->name, $enum['values']);
                }
            }
        }
    }

    public function deletePreviousElements(): void
    {
        $this->templateRepository->deleteActiveBlankTemplate();
    }
}
