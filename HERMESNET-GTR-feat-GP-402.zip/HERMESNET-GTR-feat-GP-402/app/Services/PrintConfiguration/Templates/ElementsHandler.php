<?php

namespace App\Services\PrintConfiguration\Templates;

use App\Services\PrintConfiguration\ElementRepository;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Exception;

class ElementsHandler
{
    public function __construct(
        protected ElementRepository $elementRepository,
        protected ParametersHandler $parametersHandler
    )
    {
    }

    public function saveTemplateElements(array $elements, int $templateId, int $elementId = null): string
    {
        try {
            foreach ($elements as $element) {
                $newElement = $this->elementRepository->createElement($templateId, $element, $elementId);
                $this->parametersHandler->saveElementParameters($element['parameters'], $newElement->id);

                if (array_key_exists('elements', $element) && count($element['elements']) > 0) {
                    $this->saveTemplateElements($element['elements'], $templateId, $newElement->id);
                }
            }

            return 'Elements Saved Successfully';
        } catch (Exception $exception) {
            return ResponseUtil::exception($exception);
        }

    }

    public function cloneTemplateElements(array $elements, int $templateId, int $elementId = null): string
    {
        try {
            foreach ($elements as $element) {
                $newElement = $this->elementRepository->createElement($templateId, $element, $elementId);
                $this->parametersHandler->cloneElementParameters($element['parameters'], $newElement->id);

                if (array_key_exists('elements', $element) && count($element['elements']) > 0) {
                    $this->cloneTemplateElements($element['elements'], $templateId, $newElement->id);
                }
            }

            return 'Elements Saved Successfully';
        } catch (Exception $exception) {
            return ResponseUtil::exception($exception);
        }

    }

    /**
     * @throws Exception
     */
    public function updateOrCreateElements(
        array $elements,
        int   $templateId,
        int   $parentElementId = null,
        array $templateElementsIds = []
    ): array
    {

        try {
            foreach ($elements as $element) {
                $parentId = null;

                $existingElement = $this->elementRepository->getElementById($element['id']);
                if ($existingElement && $existingElement->print_conf_template_id === $templateId) {
                    $element['print_conf_element_id'] = $parentElementId;
                    $existingElement->update($element);
                    $this->parametersHandler->updateParameters($element['parameters'], $existingElement->id);
                    $templateElementsIds[] = $existingElement->id;
                    $parentId = $existingElement->id;
                } else {
                    $newElement = $this->elementRepository->createElement($templateId, $element, $parentElementId);
                    $this->parametersHandler->saveElementParameters($element['parameters'], $newElement->id);
                    $templateElementsIds[] = $newElement->id;
                    $parentId = $newElement->id;
                }

                if (array_key_exists('elements', $element) && count($element['elements']) > 0) {
                    $templateElementsIds = $this->updateOrCreateElements($element['elements'], $templateId, $parentId, $templateElementsIds);
                }
            }
            return $templateElementsIds;
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

    }

    public function getIdsToDelete(array $updateElementsIds, array $templateElementsIds): array
    {
        return array_diff(
            $templateElementsIds,
            $updateElementsIds
        );
    }

    public function BulkDeleteElementsByIds(array $idsToDelete): void
    {
        $this->elementRepository->bulkDeleteElementsById($idsToDelete);
    }


    public function saveElementsFromJson(array $elements, int $templateId): string
    {
        foreach ($elements as $index => $element) {
            $newElement = $this->elementRepository->createElementFromJson($templateId, $element, $index);
            $this->parametersHandler->saveParametersFromJson($element['parameters'], $newElement->id);
        }

        return 'Elements Saved Successfully';
    }


    public function updateElement($elementData)
    {
        try {
            $element = $this->elementRepository->getElementById($elementData['id']);
            $element->update($elementData);
            $this->parametersHandler->updateParameters($elementData['parameters'], $element->id);

            if (array_key_exists('elements', $elementData) && count($elementData['elements']) > 0) {
                foreach ($elementData['elements'] as $nestedElement) {
                    $this->updateElement($nestedElement);
                }
            }

            return $element;
        } catch (Exception $exception) {
            LoggerUtil::exception($exception);
            return $exception->getMessage();
        }


    }

    public function deleteElementsImages($elements): void
    {
        foreach ($elements as $element){
            $this->parametersHandler->deleteImages($element->parameters);
        }
    }
}
