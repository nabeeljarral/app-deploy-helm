<?php

namespace App\Services\PrintConfiguration;

use App\Models\Dashboard\Dashboard;
use App\Models\PrintConfTemplate;
use App\Models\Views\ConfigurationItemsView;
use App\Presenters\Report\PrintReportItemsPresenter;
use App\Services\PrintConfiguration\DTO\PrintingConfigurationDTO;
use App\Services\PrintConfiguration\Enums\LinkSource;
use App\Utils\LoggerUtil;
use Illuminate\Database\Eloquent\Collection;

/**
 *
 */
class RequestDataGenerator
{
    /**
     * @var PrintConfTemplate|PrintConfTemplate[]|\LaravelIdea\Helper\App\Models\_IH_PrintConfTemplate_C|null
     */
    private PrintConfTemplate $template;
    /**
     * @var TemplateRepository
     */
    private TemplateRepository $templateRepository;

    /**
     * @var Dashboard|null
     */
    protected ?Dashboard $report = null;

    protected array $mandatoryFields = [];

    /**
     * @param int $id
     */
    public function __construct(int $id)
    {
        $this->templateRepository = new TemplateRepository();
        $this->template = $this->templateRepository->getTemplateById($id);
    }

    /**
     * @return PrintingConfigurationDTO
     */
    public function generateRequestData(): PrintingConfigurationDTO
    {
        $elements = $this->template->elements;

        $general = $elements->first(function ($item) {
            return $item['name'] === 'general';
        });

        $data = $this->getParameters($general->parameters);

        $elements = $elements->reject(function ($item) {
            return $item['name'] === 'general';
        });
        $data['items'] = $this->getItems($elements);

        /*
         * GP-139 Report structure along with printing configuration
         * */
        if (isset($this->report)) {
            $structure = $this->getReportStructure();
            if (!empty($structure)) {
                $data['structure'] = $structure;
            }
        }

        return new PrintingConfigurationDTO($data, $this->mandatoryFields);
    }

    /**
     * @param Collection $elements
     * @param array $data
     * @return array
     */
    protected function getItems(Collection $elements, array $data = []): array
    {
        foreach ($elements as $element) {
            $item = [];
            $item['$type'] = $element->name;
            $parameters = $this->getParameters($element->parameters);
            $item = array_merge($item, $parameters);

            if (isset($element->is_parent) && $element->is_parent !== '' && $element->is_parent !== 0) {
                $item['items'] = $this->getItems($element->elements);
            }

            $data[] = $item;
        }

        return $data;
    }

    /**
     * @return array
     */
    protected function getReportStructure(): array
    {
        try {
            return (new PrintReportItemsPresenter($this->report))->present();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return [];
        }
    }

    /**
     * @param Collection $parameters
     * @param array $array
     * @return array
     */
    protected function getParameters(Collection $parameters, array $array = []): array
    {
        foreach ($parameters as $parameter) {
            if ($parameter->link_source === LinkSource::ITEM_CONTENT) {
                $array[$parameter->name] = $this->getItemContent($parameter->value);
                continue;
            }

            if($parameter->is_mandatory && !isset($parameter->value) && $parameter->value !== ''){
                $this->mandatoryFields[] = $parameter->title;
            }

            if (isset($parameter->value) && $parameter->value !== '') {
                $array[$parameter->name] = $parameter->value;
            }
        }

        return $array;
    }

    /**
     * @param Dashboard $report
     * @return void
     */
    public function withReportStructure(Dashboard $report): void
    {
        $this->report = $report;
    }

    /**
     * @param int $item_id
     * @return string
     */
    private function getItemContent(int $item_id): string
    {
        $item = ConfigurationItemsView::query()
            ->where('item_id', '=', $item_id);

        if ($this->report) {
            $item->where('report_id', $this->report->id);
        }
        $item = $item->first();
        return $item ? $item->content : '';
    }

}
