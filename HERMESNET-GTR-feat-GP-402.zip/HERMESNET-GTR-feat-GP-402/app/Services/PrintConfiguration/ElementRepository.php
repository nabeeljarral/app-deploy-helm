<?php

namespace App\Services\PrintConfiguration;

use App\Models\PrintConfElement;
use Illuminate\Support\Arr;

class ElementRepository
{
    public function createElement(int $templateId, array $data, int $elementId = null){

        $newElement = new PrintConfElement();
        $newElement->name = $data['name'];
        $newElement->title = $data['title'];
        $newElement->order_number = $data['order_number'];
        $newElement->is_parent = $data['is_parent'];
        $newElement->is_mandatory = $data['is_mandatory'];
        $newElement->is_single = $data['is_single'];
        $newElement->is_default = $data['is_default'];
        $newElement->is_embeddable = $data['is_embeddable'];
        $newElement->embeds = $data['embeds'];
        $newElement->default_embeds = $data['default_embeds'];

        $newElement->print_conf_template_id = $templateId;
        $newElement->print_conf_element_id = $elementId;

        $newElement->save();

        return $newElement;
    }

    public function createElementFromJson(int $templateId, array $data, $order_number, int $elementId = null){

        $newElement = new PrintConfElement();
        $newElement->name = $data['name'];
        $newElement->title = $data['title'];
        $newElement->order_number = $order_number;

        $newElement->is_mandatory = Arr::get($data, 'mandatory', false);
        $newElement->is_single = Arr::get($data, 'single', false);
        $newElement->is_default = Arr::get($data, 'default', false);
        $newElement->is_embeddable = Arr::get($data, 'embeddable', true);
        $newElement->embeds = Arr::get($data, 'embeds', null);
        $newElement->default_embeds = Arr::get($data, 'default_embeds', null);

        if(strtolower($data['name']) === 'column' || strtolower($data['name']) === 'columns'){
            $newElement->is_parent = true;
        } else {
            $newElement->is_parent = false;
        }

        $newElement->print_conf_template_id = $templateId;
        $newElement->print_conf_element_id = $elementId;

        $newElement->save();

        return $newElement;
    }
    public function getElementParameters(int $id){

    }

    public function getElementById($id){
        return PrintConfElement::find($id);
    }

    public function updateElement($id, array $data){

    }

    public function deleteElement($element){
        return $element->delete();
    }

    public function bulkDeleteElementsById(array $idsToDelete)
    {
        return PrintConfElement::whereIn('id', $idsToDelete)->delete();
    }
}
