<?php

namespace App\Services\PrintConfiguration;

use App\Models\PrintConfParameter;
use Illuminate\Support\Arr;

class ParameterRepository
{
    public function createParameter(int $elementId, array $data, int $enumId = null): PrintConfParameter
    {
        $newParameter = new PrintConfParameter();
        $newParameter->name = $data['name'];
        $newParameter->type = $data['type'];
        $newParameter->print_conf_element_id = $elementId;
        $newParameter->print_conf_enum_id = $enumId;

        $newParameter->title = Arr::get($data, 'title', null);
        $newParameter->guidance = Arr::get($data, 'guidance', null);
        $newParameter->value = Arr::get($data, 'value', Arr::get($data, 'default_value', null));
        $newParameter->default_value = Arr::get($data, 'default_value', null);
        $newParameter->is_mandatory = Arr::get($data, 'mandatory', Arr::get($data, 'is_mandatory', false));
        $newParameter->identity = Arr::get($data, 'identity', false);
        $newParameter->link_source = Arr::get($data, 'link_source', null);

        $newParameter->save();

        return $newParameter;
    }

    public function getParameterById($id){
        return PrintConfParameter::find($id);
    }
    public function getParametersByElementId($id){
        return PrintConfParameter::where(['print_conf_element_id' => $id])->get();
    }

    public function updateParameter($id, array $data){

    }

    public function deleteParameter($id){

    }

    public function getParameterByNameAndElementId(string $name, mixed $elementId)
    {
       return  PrintConfParameter::where('name', $name)
            ->where('print_conf_element_id', $elementId)
            ->first();
    }
}
