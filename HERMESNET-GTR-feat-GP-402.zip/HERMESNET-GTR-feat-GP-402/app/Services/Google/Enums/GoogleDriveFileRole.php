<?php

namespace App\Services\Google\Enums;

/**
 * @see https://developers.google.com/drive/api/guides/manage-sharing
 * @see https://developers.google.com/drive/api/guides/ref-roles
 */
final class GoogleDriveFileRole
{
    public const READER = "reader";
    public const WRITER = "writer";
    public const COMMENTER = "commenter";
}
