<?php

namespace App\Services\Google;

use App\Abstractions\Runnable;
use App\Utils\GoogleUtil;
use Google\Service\Drive;
use Google\Service\Sheets;

/**
 *
 */
class FetchFileSheets implements Runnable
{
    /**
     * @param string $fileId
     */
    public function __construct(private string $fileId)
    {
    }

    /**
     * @return Sheets\Sheet[]
     * @throws \Google\Exception
     */
    public function run(): array
    {
        $client = GoogleUtil::apiClient([Drive::DRIVE]);
        $spreadsheetService = new Sheets($client);
        $spreadsheet = $spreadsheetService->spreadsheets->get($this->fileId);

        return $spreadsheet->getSheets();
    }
}
