<?php

namespace App\Services\Google;

use App\Abstractions\Runnable;
use App\Utils\GoogleUtil;
use Google\Client;
use Google\Service\Drive;
use Google\Service\Sheets;
use Google\Service\Sheets\ExtendedValue;
use Google\Service\Sheets\GridRange;
use Google\Service\Sheets\RowData;

/**
 *
 */
class CopySheetValueTo implements Runnable
{
    /**
     * @var string
     */
    private string $sourceRange = "A:Z";

    /**
     * @var string
     */
    private string $sourceFileId;

    /**
     * @var string
     */
    private string $sourceSheetName;

    /**
     * @var string
     */
    private string $destenationFileId;

    /**
     * @var string
     */
    private string $destenationSheetId;

    /**
     * @var Client
     */
    private Client $googleClient;

    /**
     * @var array Sheets\Request[]
     */
    private array $requests = [];

    /**
     * @param string $sourceFileId
     * @param string $sourceSheetName
     * @param string $destenationFileId
     * @param string $destenationSheetId
     */
    public function __construct(
        string $sourceFileId,
        string $sourceSheetName,
        string $destenationFileId,
        string $destenationSheetId,
    )
    {

        $this->sourceFileId = $sourceFileId;
        $this->sourceSheetName = $sourceSheetName;
        $this->destenationFileId = $destenationFileId;
        $this->destenationSheetId = $destenationSheetId;
    }

    /**
     * @return Sheets\BatchUpdateSpreadsheetResponse
     */
    public function run(): Sheets\BatchUpdateSpreadsheetResponse
    {
        $this->googleClient = GoogleUtil::apiClient([Drive::DRIVE]);

        $sourceSheet = $this->getSourceSheet();

        $rowData = $sourceSheet->getData()[0]->getRowData();
        $this->prepareCellRequests($rowData);
        $this->prepareMergeCellsRequests($sourceSheet->getMerges());

        $batchUpdateRequest = new Sheets\BatchUpdateSpreadsheetRequest();
        $batchUpdateRequest->setRequests($this->requests);

        $spreadsheetService = new Sheets($this->googleClient);

        return $spreadsheetService->spreadsheets->batchUpdate($this->destenationFileId, $batchUpdateRequest);
    }

    /**
     * @param RowData[] $rowData
     * @return void
     */
    private function prepareCellRequests(array $rowData): void
    {
        foreach ($rowData as $row => $data) {
            $value = $data->getValues();
            if (!is_iterable($value)) {
                continue;
            }
            foreach ($value as $column => $item) {
                #dd($item->toSimpleObject());
                $gridRange = new Sheets\GridRange([
                    'sheetId'          => $this->destenationSheetId,
                    'startRowIndex'    => $row,
                    'endRowIndex'      => $row + 1,
                    'startColumnIndex' => $column,
                    'endColumnIndex'   => $column + 1,
                ]);

                $userEnteredValue = $item->getEffectiveValue();
                if (!$userEnteredValue || !empty($userEnteredValue->getErrorValue())) {
                    $userEnteredValue = new ExtendedValue();
                }
                $item->setUserEnteredValue($userEnteredValue);

                $repeatCellRequest = new Sheets\RepeatCellRequest();
                $repeatCellRequest->setRange($gridRange);
                $repeatCellRequest->setCell($item);
                $repeatCellRequest->setFields("*");

                $request = new Sheets\Request();
                $request->setRepeatCell($repeatCellRequest);

                $this->requests[] = $request;
            }
        }
    }

    /**
     * @param GridRange[] $merges
     * @return void
     */
    private function prepareMergeCellsRequests(array $merges): void
    {
        foreach ($merges as $merge) {
            $mergeRequest = new Sheets\MergeCellsRequest();
            $merge->setSheetId($this->destenationSheetId);
            $mergeRequest->setRange($merge);

            $request = new Sheets\Request();
            $request->setMergeCells($mergeRequest);

            $this->requests[] = $request;
        }
    }

    /**
     * @return Sheets\Sheet
     */
    private function getSourceSheet(): Sheets\Sheet
    {
        $spreadsheetService = new Sheets($this->googleClient);

        $spreadsheet = $spreadsheetService->spreadsheets->get($this->sourceFileId, [
            'includeGridData' => true,
            'ranges'          => $this->sourceSheetName . "!" . $this->sourceRange,
        ]);
        return $spreadsheet->getSheets()[0];
    }

    /**
     * @param string $sourceRange
     */
    public function setSourceRange(string $sourceRange): void
    {
        $this->sourceRange = $sourceRange;
    }
}
