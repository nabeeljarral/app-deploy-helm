<?php

namespace App\Services\Google;

use App\Abstractions\Runnable;
use App\Utils\GoogleUtil;
use Google\Service\Drive;
use Google\Service\Sheets;

/**
 *
 */
class ValidateSheetRange implements Runnable
{
    /**
     * @var \Exception
     */
    private \Exception $exception;

    /**
     * @param string $file_id
     * @param string $range
     */
    public function __construct(
        private string $file_id,
        private string $range,
    )
    {
    }

    /**
     * @return bool
     */
    public function run(): bool
    {
        try {
            $client = GoogleUtil::apiClient([Drive::DRIVE]);
            $spreadsheetService = new Sheets($client);

            $spreadsheet = $spreadsheetService->spreadsheets->get($this->file_id, [
                'includeGridData' => true,
                'ranges'          => $this->range
            ]);

            $sheets = $spreadsheet->getSheets();
            if (empty($sheets)) {
                return false;
            }

            $rows = $sheets[0]->getData()[0]->getRowData();

            return count($rows) > 0;
        } catch (\Exception $exception) {
            $this->exception = $exception;
            return false;
        }
    }

    /**
     * @return string|null
     */
    public function getMessage(): mixed
    {
        if (!isset($this->exception)) {
            return null;
        }

        $rawMessage = $this->exception->getMessage();

        $message = json_decode($rawMessage, true);
        if ($message) {
            return $message;
        }

        return $rawMessage;
    }
}
