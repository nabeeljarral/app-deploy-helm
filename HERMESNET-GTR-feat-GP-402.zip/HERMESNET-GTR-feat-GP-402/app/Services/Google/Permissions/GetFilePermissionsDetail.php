<?php

namespace App\Services\Google\Permissions;

use App\Abstractions\Runnable;
use App\Utils\GoogleUtil;
use Google\Service\Drive;

/**
 *
 */
class GetFilePermissionsDetail implements Runnable
{
    /**
     * @var string
     */
    private string $fileId;

    /**
     * @var string
     */
    private string $permissionsId;

    /**
     * @param string $fileId
     * @param string $permissionsId
     */
    public function __construct(
        string $fileId,
        string $permissionsId
    )
    {
        $this->fileId = $fileId;
        $this->permissionsId = $permissionsId;
    }

    /**
     * @return array|mixed|null
     */
    public function run()
    {
        $googleClient = GoogleUtil::apiClient();
        $driveService = new Drive($googleClient);
        $driveService->getClient()->setUseBatch(true);

        $request = $driveService->permissions->get($this->fileId, $this->permissionsId);

        $batch = $driveService->createBatch();
        $batch->add($request, 'user');

        return $batch->execute();
    }
}
