<?php

namespace App\Services\Google\Permissions\ProtectedRange;

use App\Abstractions\Runnable;
use App\Utils\ArrayUtil;
use App\Utils\GoogleUtil;
use Google\Service\Drive;
use Google\Service\Sheets;

/**
 *
 */
class ProtectSheet implements Runnable
{
    /**
     * @var null|Sheets\GridRange[]
     */
    private ?array $unprotectedRange = null;

    /**
     * @var string[]
     */
    private array $editors;

    /**
     * @var bool
     */
    private bool $warningOnly = false;

    /**
     * @var string|null
     */
    private ?string $description = null;

    /**
     * @var string|null
     */
    private ?string $protectedRangeId = null;

    /**
     * @param string $file_id
     * @param string $sheetId
     */
    public function __construct(
        private string $file_id,
        private string $sheetId
    )
    {

    }

    /**
     * @return Sheets\AddProtectedRangeResponse
     */
    public function run(): Sheets\AddProtectedRangeResponse
    {
        $googleClient = GoogleUtil::apiClient([
            Drive::DRIVE,
            Sheets::SPREADSHEETS
        ]);

        $spreadsheetService = new Sheets($googleClient);
        $request = $this->getProtectedRangeRequest();

        $batchUpdateSpreadsheetRequest = new Sheets\BatchUpdateSpreadsheetRequest();
        $batchUpdateSpreadsheetRequest->setRequests($request);
        $response = $spreadsheetService->spreadsheets->batchUpdate($this->file_id, $batchUpdateSpreadsheetRequest);

        return $response->getReplies()[0]->getAddProtectedRange();
    }

    /**
     * @return Sheets\Request
     */
    public function getProtectedRangeRequest(): Sheets\Request
    {
        $protectedRange = new Sheets\ProtectedRange();
        $protectedRange->setRange(
            new Sheets\GridRange(["sheetId" => $this->sheetId])
        );

        if ($this->unprotectedRange) {
            $protectedRange->setUnprotectedRanges($this->unprotectedRange);
        }

        $protectedRange->setWarningOnly($this->warningOnly);

        if (!empty($this->editors)) {
            $editors = $this->getEditorsEntity();
            $protectedRange->setEditors($editors);
        }

        if ($this->description) {
            $protectedRange->setDescription($this->description);
        }

        $request = new Sheets\Request();

        if ($this->protectedRangeId) {
            $protectedRange->setProtectedRangeId($this->protectedRangeId);

            $updateRequest = new Sheets\UpdateProtectedRangeRequest();
            $updateRequest->setProtectedRange($protectedRange);
            $updateRequest->setFields("*");

            $request->setUpdateProtectedRange($updateRequest);
        } else {
            $addRequest = new Sheets\AddProtectedRangeRequest();
            $addRequest->setProtectedRange($protectedRange);
            $request->setAddProtectedRange($addRequest);
        }


        return $request;
    }


    /**
     * @return Sheets\Editors
     */
    private function getEditorsEntity(): Sheets\Editors
    {
        return new Sheets\Editors(
            [
                'users' => $this->editors,
            ]
        );
    }


    /**
     * @param array $unprotectedRange
     * @return void
     * @throws \Exception
     */
    private function validateUnprotectedRange(array $unprotectedRange): void
    {
        if (!ArrayUtil::isArrayInstanceOf($unprotectedRange, Sheets\GridRange::class)) {
            throw new \DomainException("an array of GridRange::class must be provided");
        }
    }

    /**
     * @param Sheets\GridRange[] $unprotectedRange
     * @return void
     * @throws \Exception
     */
    public function setUnprotectedRange(array $unprotectedRange): void
    {
        $this->validateUnprotectedRange($unprotectedRange);
        $this->unprotectedRange = $unprotectedRange;
    }

    /**
     * array of email addresses
     * @param string[] $editors
     */
    public function setEditors(array $editors): void
    {
        $this->editors = $editors;
    }


    /**
     * @param bool $warningOnly
     */
    public function setWarningOnly(bool $warningOnly): void
    {
        $this->warningOnly = $warningOnly;
    }

    /**
     * @param string $description
     */
    public function setDescription(string $description): void
    {
        $this->description = $description;
    }

    /**
     * @param string|null $protectedRangeId
     * @return void
     */
    public function setProtectedRangeId(?string $protectedRangeId): void
    {
        $this->protectedRangeId = $protectedRangeId;
    }
}
