<?php

namespace App\Services\Google\Permissions;

use App\Abstractions\Runnable;
use App\Utils\GoogleUtil;
use Google\Service\Drive;

/**
 *
 */
class CreateFilePermissions implements Runnable
{
    /**
     * @var string
     */
    private string $fileId;

    /**
     * @var string
     */
    private string $role;

    /**
     * @var string
     */
    private string $type = "user";

    /**
     * @var string
     */
    private string $email;

    /**
     * @param string $fileId
     * @param string $role
     * @param string $email
     */
    public function __construct(string $fileId, string $role, string $email)
    {
        $this->fileId = $fileId;
        $this->role = $role;
        $this->email = $email;
    }

    /**
     * @return Drive\Permission
     */
    public function run(): Drive\Permission
    {
        $googleClient = GoogleUtil::apiClient();
        $driveService = new Drive($googleClient);
        $driveService->getClient()->setUseBatch(true);

        $userPermission = new Drive\Permission([
            'type'         => $this->type,
            'role'         => $this->role,
            'emailAddress' => $this->email         
        ]);

        $request = $driveService->permissions->create($this->fileId, $userPermission, ['sendNotificationEmail' => false]);

        $batch = $driveService->createBatch();
        $batch->add($request, 'user');

        $response = $batch->execute();

        $response = $response['response-user'];

        if ($response instanceof \Exception) {
            throw $response;
        }

        return $response;
    }

    /**
     * @param string $type
     */
    public function setType(string $type): void
    {
        $this->type = $type;
    }
}
