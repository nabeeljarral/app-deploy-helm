<?php

namespace App\Services\Google\Permissions;

use App\Abstractions\Runnable;
use App\Utils\GoogleUtil;
use Google\Service\Drive;

/**
 *
 */
class RevokeFilePermissions implements Runnable
{
    /**
     * @var string
     */
    private string $fileId;

    /**
     * @var string
     */
    private string $permissionsId;

    /**
     * @param string $fileId
     * @param string $permissionsId
     */
    public function __construct(
        string $fileId,
        string $permissionsId
    )
    {
        $this->fileId = $fileId;
        $this->permissionsId = $permissionsId;
    }

    /**
     * @return bool
     */
    public function run(): bool
    {
        $googleClient = GoogleUtil::apiClient();
        $driveService = new Drive($googleClient);
        $driveService->getClient()->setUseBatch(true);

        $request = $driveService->permissions->delete($this->fileId, $this->permissionsId);

        $batch = $driveService->createBatch();
        $batch->add($request, 'user');

        $response = $batch->execute();
        return true;
    }
}
