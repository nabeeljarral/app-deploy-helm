<?php

namespace App\Services\Google\Permissions;

use App\Abstractions\Runnable;
use App\Utils\GoogleUtil;
use Google\Service\Drive;
use Google\Service\Drive\PermissionList;

/**
 *
 */
class GetFilePermissionsList implements Runnable
{
    /**
     * @var string
     */
    private string $fileId;

    /**
     * @param string $fileId
     */
    public function __construct(
        string $fileId
    )
    {
        $this->fileId = $fileId;
    }

    /**
     * @return PermissionList
     */
    public function run(): Pe\rmissionList
    {
        $googleClient = GoogleUtil::apiClient();
        $driveService = new Drive($googleClient);
        $driveService->getClient()->setUseBatch(true);

        $request = $driveService->permissions->listPermissions($this->fileId);

        $batch = $driveService->createBatch();
        $batch->add($request, 'user');

        $response = $batch->execute();

        return $response['response-user'];
    }
}
