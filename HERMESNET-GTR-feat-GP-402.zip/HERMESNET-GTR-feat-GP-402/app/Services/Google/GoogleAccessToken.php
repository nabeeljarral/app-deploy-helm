<?php

namespace App\Services\Google;

use App\Utils\GoogleUtil;
use Illuminate\Support\Arr;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\Validator;

/**
 *
 */
class GoogleAccessToken
{
    /**
     * @var GoogleAccessToken|null
     */
    public static ?GoogleAccessToken $instance = null;

    /**
     * @var array
     */
    private array $tokenData;

    /**
     * @param array $response
     * @return void
     */
    public static function save(array $response): void
    {
        $validate = Validator::make(
            $response,
            [
                'access_token' => ['required', 'string'],
                'expires_in'   => ['required', 'int'],
            ]
        );

        if ($validate->fails()) {
            throw new \RuntimeException("Invalid google access token response!");
        }

        Redis::set("google_access_token", json_encode($response));
    }

    /**
     * @return static
     */
    public static function getInstance(): self
    {
        if (!self::$instance) {
            self::$instance = new static();
        }

        $tokenData = Redis::get("google_access_token");
        $tokenData = json_decode($tokenData, true);

        self::$instance->tokenData = $tokenData;

        return self::$instance;
    }

    /**
     * @return string
     */
    public function getToken(): string
    {
        if ($this->isExpire()) {
            $this->refresh();
        }

        return Arr::get($this->tokenData, "access_token");
    }

    /**
     * @return bool
     */
    public function isExpire(): bool
    {
        $expire_in = Carbon::createFromTimestamp(Arr::get($this->tokenData, "created"))
            ->addSeconds(Arr::get($this->tokenData, "expires_in"));

        return Carbon::now()->greaterThanOrEqualTo($expire_in);
    }

    /**
     * @return $this
     * @throws \Google\Exception
     */
    public function refresh(): self
    {
        $client = GoogleUtil::authClient();
//        $client->setApprovalPrompt("force");
        $tokenData = $client->refreshToken(Arr::get($this->tokenData, "refresh_token"));
        self::save($tokenData);
        $this->tokenData = $tokenData;
        return $this;
    }

    /**
     * @return array
     */
    public function getTokenData(): array
    {
        return $this->tokenData;
    }

    /**
     *
     */
    protected function __construct()
    {
    }

    /**
     * @return void
     */
    protected function __clone()
    {
    }

    /**
     * @return void
     */
    public function __wakeup()
    {
    }
}
