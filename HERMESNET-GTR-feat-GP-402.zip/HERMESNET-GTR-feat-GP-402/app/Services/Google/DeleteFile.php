<?php

namespace App\Services\Google;

use App\Abstractions\Runnable;
use App\Utils\GoogleUtil;
use Google\Service\Drive;

/**
 *
 */
class DeleteFile implements Runnable
{
    /**
     * @var string
     */
    private string $fileId;

    /**
     * @param string $fileId
     */
    public function __construct(string $fileId)
    {
        $this->fileId = $fileId;
    }

    /**
     * @return mixed|void
     */
    public function run()
    {
        $googleClient = GoogleUtil::apiClient([Drive::DRIVE]);

        $driveService = new Drive($googleClient);
        $driveService->files->delete($this->fileId);
    }
}
