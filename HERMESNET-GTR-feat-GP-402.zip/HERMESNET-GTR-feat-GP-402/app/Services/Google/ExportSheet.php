<?php

namespace App\Services\Google;

use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardSheet;
use App\Utils\GoogleUtil;
use Google\Service\Drive;
use GuzzleHttp\Psr7\Response;
use PhpOffice\PhpSpreadsheet\IOFactory;

/**
 *
 */
class ExportSheet implements Runnable
{
    /**
     * @var string
     */
    private string $fileName;

    /**
     * @var Dashboard|mixed|null
     */
    private Dashboard $dashboard;

    /**
     * @param DashboardSheet $dashboardSheet
     */
    public function __construct(
        private DashboardSheet $dashboardSheet
    )
    {
        $this->dashboard = $this->dashboardSheet->dashboard;
    }

    /**
     * @return mixed|void
     * @throws \PhpOffice\PhpSpreadsheet\Exception
     * @throws \PhpOffice\PhpSpreadsheet\Reader\Exception
     * @throws \PhpOffice\PhpSpreadsheet\Writer\Exception
     */
    public function run()
    {
        $this->fileName = uniqid('ds_' . $this->dashboardSheet->id . '_') . ".xlsx";
        $this->downloadFile();
        $this->removeSheets();
    }

    /**
     * @return string
     */
    public function getFilePath(): string
    {
        return storage_path("app/public/tmp/" . $this->fileName);
    }

    /**
     * @return void
     */
    private function downloadFile()
    {
        $client = GoogleUtil::apiClient([Drive::DRIVE]);
        $driveService = new Drive($client);

        /**
         * @var $response Response
         */
        $response = $driveService->files->export(
            $this->dashboard->file_id,
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        );
        \Storage::put("public/tmp/" . $this->fileName, $response->getBody());
    }

    /**
     * @return void
     * @throws \PhpOffice\PhpSpreadsheet\Exception
     * @throws \PhpOffice\PhpSpreadsheet\Reader\Exception
     * @throws \PhpOffice\PhpSpreadsheet\Writer\Exception
     */
    private function removeSheets()
    {
        $filePath = storage_path("app/public/tmp/" . $this->fileName);
        $reader = IOFactory::createReader(IOFactory::READER_XLSX);
        $spreadsheet = $reader->load($filePath);

        $sheets = $spreadsheet->getAllSheets();

        foreach ($sheets as $sheet) {
            if ($sheet->getTitle() === $this->dashboardSheet->sheet_title) {
                continue;
            }
            $index = $spreadsheet->getIndex($sheet);
            $spreadsheet->removeSheetByIndex($index);
        }

        $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
        $writer->save($filePath);

        $spreadsheet->disconnectWorksheets();
        unset($spreadsheet);
    }
}
