<?php

namespace App\Services\Template\Actions;

use App\Abstractions\Runnable;
use App\Models\Template\Template;
use App\Services\Dashboard\Enums\SheetType;
use App\Utils\GoogleUtil;
use Google\Service\Drive;
use Google\Service\Sheets;
use Illuminate\Support\Facades\Redis;

/**
 * fetch default template Google Drive Spreadsheet sheets properties
 */
class FetchTemplateSheets implements Runnable
{
    /**
     * @param Template $template
     */
    public function __construct(private Template $template)
    {

    }

    /**
     * @return array
     * @throws \Google\Exception
     */
    public function run(): array
    {
        $sheets = Redis::get('template_sheets.' . $this->template->id);
        if ($sheets) {
            $sheets = json_decode($sheets, true);
            if (is_array($sheets)) {
                return $sheets;
            }
        }

        $sheets = $this->prepareSheets();
        Redis::set('template_sheets.' . $this->template->id, json_encode($sheets), 'EX', 3600 * 24);
        return $sheets;
    }

    /**
     * @return array
     * @throws \Google\Exception
     */
    private function prepareSheets(): array
    {
        $data = [];
        if ($this->template->gd_preview_file_id) {
            $spreadsheet = $this->fetchPreviewSpreadsheet();
            foreach ($spreadsheet->getSheets() as $sheet) {
                $properties = $sheet->getProperties();

                $gridProperties = [
                    "columnCount" => $properties->getGridProperties()->getColumnCount(),
                    "rowCount"    => $properties->getGridProperties()->getRowCount(),
                ];
                $data[] = [
                    "type"            => SheetType::REGULAR,
                    "sheet_title"     => $properties->getTitle(),
                    "sheet_id"        => $properties->getSheetId(),
                    "sheet_type"      => $properties->getSheetType(),
                    "grid_properties" => $gridProperties,
                ];
            }
        }
        return $data;
    }

    /**
     * @return Sheets\Spreadsheet
     * @throws \Google\Exception
     */
    public function fetchPreviewSpreadsheet(): Sheets\Spreadsheet
    {
        $googleClient = GoogleUtil::apiClient([Drive::DRIVE]);
        $spreadsheetService = new Sheets($googleClient);
        return $spreadsheetService->spreadsheets->get($this->template->gd_preview_file_id);
    }
}
