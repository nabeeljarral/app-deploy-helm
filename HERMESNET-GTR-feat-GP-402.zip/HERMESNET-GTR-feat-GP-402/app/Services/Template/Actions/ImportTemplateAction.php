<?php

namespace App\Services\Template\Actions;

use App\Abstractions\Runnable;
use App\Admin\Http\Requests\Templates\SaveTemplateRequest;
use App\Admin\Services\Template\ReplaceTemplateItemsCrossLinks;
use App\Models\Template\Template;
use App\Models\Template\TemplateConfiguration;
use App\Models\Template\TemplateItem;
use App\Services\Template\Enums\TemplateCategory;
use Illuminate\Http\UploadedFile;

/**
 *
 */
class ImportTemplateAction implements Runnable
{
    /**
     * @var array
     */
    private array $importData;

    /**
     * <old_item_id> => <new_item_id>
     * @var array<int, int>
     */
    private array $itemIdRatio = [];

    /**
     * @var Template
     */
    private Template $template;

    /**
     * @param UploadedFile $file
     * @param string|null $name
     */
    public function __construct(
        private UploadedFile $file,
        private ?string      $name = null,
    )
    {

    }

    /**
     * @return Template
     * @throws \Exception
     */
    public function run(): Template
    {
        try {
            \DB::beginTransaction();
            $this->importData = $this->decodeFile();

            $this->importTemplate();
            $this->importTemplateItems();
            $this->importTemplateAnalytics();
            $this->importTemplateOptions();
            $this->importTemplateConfigurations();

            if (!empty($this->itemIdRatio)) {
                (new ReplaceTemplateItemsCrossLinks($this->template, $this->itemIdRatio))->run();
            }

            \DB::commit();
            return $this->template;
        } catch (\Exception $exception) {
            \DB::rollBack();
            throw $exception;
        }
    }

    /**
     * @return array
     */
    private function decodeFile(): array
    {
        $decoded = json_decode($this->getFileContent(), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new \RuntimeException('Invalid JSON file');
        }

        return $decoded;
    }

    /**
     * @return string
     */
    private function getFileContent(): string
    {
        $content = $this->file->getContent();
        $importData = json_decode($content, true);
        if (!$importData) {
            return $content;
        }

        $service_origin = \Arr::get($importData, 'service_origin');
        if (!$service_origin) {
            return $content;
        }

        return str_replace($service_origin, $this->getAppHost(), $content);
    }

    /**
     * @return string
     */
    private function getAppHost(): string
    {
        $service_origin = config('app.url');
        return parse_url($service_origin, PHP_URL_HOST);
    }

    /**
     * @return void
     */
    private function importTemplate(): void
    {
        $this->importData['name'] = $this->getTemplateName();
        $this->importData['is_published'] = false;
        $this->importData['use_with_any_summary'] = false;
        $this->importData['allow_aggregation_view'] = \Arr::get($this->importData, 'allow_aggregation_view', false);
        $this->importData['is_trial'] = false;
        $this->importData['is_public'] = false;

        $data = \Validator::validate($this->importData, $this->validateTemplateRules());
        $this->template = Template::create($data);
    }

    /**
     * @return array[]
     */
    private function validateTemplateRules(): array
    {
        return [
            'name'                              => ["required", "string"],
            "description"                       => ["nullable", "string"],
            "category"                          => ["required", "string"],
            "type"                              => ["required", "string"],
            "is_public"                         => ["bool"],
            "is_trial"                          => ["bool"],
            "use_with_any_summary"              => ["bool"],
            'gd_file_id'                        => ['nullable', "string"],
            'index_sheet'                       => ['nullable', "string"],
            'gd_preview_file_id'                => ['nullable', "string"],
            'hidden_connected_sheet'            => ['bool'],
            'allow_aggregation_view'            => ['bool'],
            'allow_report_structure_definition' => ['bool'],
            'data_sheet'                        => ['nullable', "string"],
            'guidance'                          => ['nullable', "string"],
            'gtr_sync_config'                   => ['nullable', 'array'],
        ];
    }

    /**
     * @return string
     */
    private function getTemplateName(): string
    {
        $name = $this->name ?? \Arr::get($this->importData, 'name');
        if (!$name) {
            $name = $this->file->getClientOriginalName();
        }
        $exists = Template::where('name', $name)->count();
        if ($exists > 0) {
            $name = $name . ' (' . now()->format('M d, Y h:m') . ')';
        }

        return $name;
    }

    /**
     * @return void
     */
    private function importTemplateItems(): void
    {
        $items = \Arr::get($this->importData, 'items', []);
        if (empty($items) || $this->template->category != TemplateCategory::COMPLEX) {
            return;
        }

        $items = \Validator::validate($items, [
            '*.id'                  => ['required', 'integer'],
            '*.parent_item_id'      => ['nullable', 'integer'],
            '*.name'                => ['required', 'string'],
            '*.mandatory'           => ['boolean'],
            '*.requirements'        => ['nullable', 'string'],
            '*.recommendations'     => ['nullable', 'string'],
            '*.guidance'            => ['nullable', 'string'],
            '*.content'             => ['nullable', 'string'],
            '*.use_google_sheet'    => ['boolean'],
            '*.include_in_printing' => ['boolean'],
            '*.sheet_name'          => ['nullable', 'string'],
            '*.sheet_height'        => ['nullable', 'string'],
            '*.order_number'        => ['nullable', 'integer'],
        ]);

        $items = $this->flatItemsToNested($items);
        $this->createItems($items);
    }

    /**
     * @param array $items
     * @param int|null $parent_item_id
     * @return array
     */
    private function flatItemsToNested(array $items, ?int $parent_item_id = null): array
    {
        $result = [];
        $collection = collect($items)->where('parent_item_id', $parent_item_id)->sortBy('order_number');
        foreach ($collection as $item) {
            $item['nestedItems'] = $this->flatItemsToNested($items, $item['id']);
            $result[] = $item;
        }
        return $result;
    }

    /**
     * @param array $items
     * @param TemplateItem|null $parentItem
     * @return void
     */
    private function createItems(array $items, ?TemplateItem $parentItem = null): void
    {
        foreach ($items as $itemData) {
            $itemData['template_id'] = $this->template->id;
            if ($parentItem) {
                $itemData['parent_item_id'] = $parentItem->id;
            }

            $item = TemplateItem::create($itemData);
            $this->itemIdRatio[$itemData['id']] = $item->id;
            if (!empty($itemData['nestedItems'])) {
                $this->createItems($itemData['nestedItems'], $item);
            }
        }
    }

    /**
     * @return void
     */
    private function importTemplateAnalytics(): void
    {
        $analytics = \Arr::get($this->importData, 'analytics', []);
        if (empty($analytics)) {
            return;
        }

        $analytics = \Validator::validate($analytics, [
            "*.name"                    => ["required", "string"],
            "*.sheet_name"              => ["nullable", "string"],
            "*.icon"                    => ["nullable", 'string'],
            "*.looker_embedding_url"    => ["nullable", "string"],
            "*.looker_embedding_config" => ["nullable", "array"],
        ]);

        foreach ($analytics as $analytic) {
            $this->template->analytics()->create($analytic);
        }
    }

    /**
     * @return void
     */
    private function importTemplateOptions(): void
    {
        $options = \Arr::get($this->importData, 'options', []);
        if (empty($options)) {
            return;
        }
        $options = \Validator::validate($options, [
            "*.name"         => ["required", "string"],
            "*.guidance"     => ["required", "string"],
            "*.icon"         => ["nullable", 'string'],
            "*.is_trial"     => ["required", "boolean"],
            "*.is_published" => ["required", "boolean"],
        ]);
        foreach ($options as $option) {
            $this->template->complianceLevels()->create($option);
        }
    }

    /**
     * @return void
     */
    private function importTemplateConfigurations(): void
    {
        $configurations = \Arr::get($this->importData, 'configurations', []);
        if (empty($configurations) || $this->template->category != TemplateCategory::COMPLEX) {
            return;
        }

        $configurations = \Validator::validate(array_values($configurations), [
            '*.name'         => ['required', 'string'],
            '*.guidance'     => ['nullable', 'string'],
            '*.is_general'   => ['bool'],
            '*.is_published' => ['bool'],
            '*.items'        => ['nullable', 'array'],
        ]);

        foreach ($configurations as $configurationData) {
            $configurationData['template_id'] = $this->template->id;
            $templateConfiguration = $this->template
                ->configurations()
                ->create($configurationData);

            if ($templateConfiguration->is_general || empty($this->itemIdRatio)) {
                continue;
            }

            $configurationItems = \Arr::get($configurationData, 'items', []);
            if (empty($configurationItems)) {
                continue;
            }

            $this->importConfigurationItems($templateConfiguration, $configurationItems);
        }
    }

    /**
     * @param TemplateConfiguration $templateConfiguration
     * @param array $configurationItems
     * @return void
     */
    private function importConfigurationItems(TemplateConfiguration $templateConfiguration, array $configurationItems): void
    {
        $configurationItems = \Validator::validate($configurationItems, [
            '*.item_id'            => ['required', 'int'],
            '*.reason_of_omission' => ['nullable', 'string'],
            '*.content'            => ['nullable', 'string'],
            '*.is_included'        => ['bool']
        ]);

        foreach ($configurationItems as $itemData) {
            if (isset($this->itemIdRatio[$itemData['item_id']])) {
                $itemData['configuration_id'] = $templateConfiguration->id;
                $itemData['item_id'] = $this->itemIdRatio[$itemData['item_id']];
                $templateConfiguration->items()->create($itemData);
            }
        }
    }


}
