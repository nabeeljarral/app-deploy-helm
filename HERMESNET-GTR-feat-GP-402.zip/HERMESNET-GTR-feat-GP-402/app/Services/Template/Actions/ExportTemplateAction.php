<?php

namespace App\Services\Template\Actions;

use App\Abstractions\Runnable;
use App\Models\Template\Template;
use Illuminate\Http\Response;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;

/**
 *
 */
class ExportTemplateAction implements Runnable
{
    /**
     * @var array
     */
    private array $data = [];

    /**
     * @param Template $template
     */
    public function __construct(private Template $template)
    {

    }

    /**
     * @return Response
     */
    public function run(): Response
    {
        $this->data = $this->template->toArray();
        $this->data['service_origin'] = $this->getServiceOrigin();

        $this->exportTemplateItems();
        $this->exportTemplateAnalytics();
        $this->exportTemplateOptions();
        $this->exportTemplateConfigurations();


        $response = new Response(json_encode($this->data));
        $disposition = $response->headers->makeDisposition(
            ResponseHeaderBag::DISPOSITION_ATTACHMENT,
            'template_' . $this->template->id . '.json'
        );

        $response->headers->set('Content-Disposition', $disposition);
        $response->headers->set('Content-Type', "application/json");

        return $response;
    }

    /**
     * @return string
     */
    private function getServiceOrigin(): string
    {
        $service_origin = config('app.url');
        return parse_url($service_origin, PHP_URL_HOST);
    }

    /**
     * @return void
     */
    private function exportTemplateItems(): void
    {
        $this->data['items'] = $this->template->items->toArray();
    }

    /**
     * @return void
     */
    private function exportTemplateAnalytics(): void
    {
        $this->data['analytics'] = $this->template->analytics->toArray();
    }

    /**
     * @return void
     */
    private function exportTemplateOptions(): void
    {
        $this->data['options'] = $this->template->complianceLevels->toArray();
    }

    /**
     * @return void
     */
    private function exportTemplateConfigurations(): void
    {
        $result = [];
        $configurations = $this->template->configurations()
            ->whereNull("organization_id")
            ->get();

        foreach ($configurations as $configuration) {
            $item = $configuration->toArray();
            $item['items'] = [];
            if ($configuration->is_general) {
                $result[] = $item;
                continue;
            }
            $configurationItems = $configuration->items->toArray();
            $item['items'] = $configurationItems;
            $result[] = $item;
        }

        $this->data['configurations'] = $result;
    }
}
