<?php

namespace App\Services\Template\Actions;

use App\Abstractions\Runnable;
use App\Models\Template\Template;
use App\Services\Google\FetchFileSheets;
use App\Services\Template\Enums\TemplateCategory;

class TemplatePublicationChecker implements Runnable
{
    public function __construct(
        private Template $template
    )
    {

    }

    /**
     * @return bool
     * @throws \Google\Exception
     * @throws \Google\Service\Exception
     */
    public function run(): bool
    {

        //TODO:...

        return true;
    }

    /**
     * @return bool
     * @throws \Google\Exception
     * @throws \Google\Service\Exception
     */
    private function defaultTemplate(): bool {
        if (!$this->template->gd_file_id) {
           throw new \DomainException("google drive file id is required");
        }

        try {
            (new FetchFileSheets($this->template->gd_file_id))->run();
        }
        catch (\Google\Service\Exception $exception) {
            $response = json_decode($exception->getMessage(), true);
            if (!$response) {
                throw $exception;
            }

            $message = \Arr::get($response, "error.message");
            if ($message) {
                throw new \DomainException("Google Drive Error: " . $message);
            }else {
                throw $exception;
            }
        }

        return  true;
    }
}
