<?php

namespace App\Services\Template\Actions;

use App\Abstractions\Runnable;
use App\Models\Template\Template;

class UpdateItemsStructure implements Runnable
{
    public function __construct(
        private Template $template,
        private array    $nestedItems,
        private string   $nestedItemsKey = 'nestedItems',
    )
    {

    }

    public function run(): void
    {
        $flatItems = [];
        $this->nestedToFlat($this->nestedItems, $flatItems);

        try {
            \DB::beginTransaction();
            foreach ($flatItems as $item) {
                $this->template->items()->where("id", $item["id"])->update($item);
            }
            \DB::commit();
        } catch (\Exception $e) {
            \DB::rollBack();
            throw $e;
        }
    }

    /**
     * @param array $items
     * @param array $result
     * @return void
     */
    private function nestedToFlat(array $items, array &$result): void
    {
        foreach ($items as $item) {
            $result[] = \Arr::only($item, ['id', 'parent_item_id', 'order_number']);

            $childItems = $item[$this->nestedItemsKey] ?? [];
            if (count($childItems) > 0) {
                $this->nestedToFlat($childItems, $result);
            }
        }
    }
}
