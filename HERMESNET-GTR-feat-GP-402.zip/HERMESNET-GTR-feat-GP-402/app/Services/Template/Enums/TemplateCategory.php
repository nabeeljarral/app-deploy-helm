<?php

namespace App\Services\Template\Enums;

final class TemplateCategory
{
    public const DEFAULT = "default";
    public const COMPLEX = "complex";
}
