<?php

namespace App\Services\Common\DTO;

use App\Abstractions\DataTransferObject;

class PaginationDto extends DataTransferObject
{
    public int $page = 1;

    public int $per_page = 10;
}
