<?php

namespace App\Services\Looker;

use App\Abstractions\Runnable;
use App\Models\Template\TemplateAnalytics;

/**
 *
 */
class ManuallySignedUrl implements Runnable
{
    /**
     * @param TemplateAnalytics $templateAnalytics
     * @param EmbeddingAttributes $attributes
     * @throws \Exception
     */
    public function __construct(
        private TemplateAnalytics   $templateAnalytics,
        private EmbeddingAttributes $attributes,
    )
    {
        $this->throwIfLookerNotSet();
    }

    /**
     * @return void
     * @throws \Exception
     */
    private function throwIfLookerNotSet(): void
    {
        if (!$this->templateAnalytics->looker_embedding_url) {
            throw new \Exception("Looker embedding url is not set");
        }

        if (!$this->templateAnalytics->looker_embedding_config) {
            throw new \Exception("Looker embedding config is not set");
        }
    }

    /**
     * @return string
     */
    public function run(): string
    {
        $config = $this->attributes->getConfig($this->templateAnalytics->looker_embedding_config);
        $config['signature'] = $this->getSignature($config);

        $querystring = "";
        foreach ($config as $key => $value) {
            if (strlen($querystring) > 0) {
                $querystring .= "&";
            }
            $querystring .= "$key=" . urlencode($value);
        }

        return "https://" . config('project.looker.host') . $this->getEmbedPath() . '?' . $querystring;
    }

    /**
     * @param array $config
     * @return string
     */
    private function getSignature(array $config): string
    {
        $needleFields = [
            'nonce'             => "",
            'time'              => "",
            'session_length'    => "",
            'external_user_id'  => "",
            'permissions'       => "",
            'models'            => "",
            'group_ids'         => "[]",
            'external_group_id' => "",
            'user_attributes'   => "",
            'access_filters'    => ""
        ];

        $stringToSign = config('project.looker.host') . "\n" . $this->getEmbedPath() . "\n";

        $stringToSign .= implode("\n", array_map(function ($field) use ($config, $needleFields) {
            return \Arr::get($config, $field, $needleFields[$field]);
        }, array_keys($needleFields)));

        $secret = config("project.looker.secret");
        return trim(base64_encode(hash_hmac("sha1", utf8_encode($stringToSign), $secret, $raw_output = true)));
    }

    /**
     * @return string
     */
    private function getEmbedPath(): string
    {
        $urlParts = parse_url($this->templateAnalytics->looker_embedding_url);

        $path = \Str::start($urlParts['path'], '/');
        $result = \Str::start($path, '/embed');

        if (!empty($urlParts['query'])) {
            $result .= '?' . urldecode($urlParts['query']);
        }

        return '/login/embed/' . urlencode($result);
    }
}
