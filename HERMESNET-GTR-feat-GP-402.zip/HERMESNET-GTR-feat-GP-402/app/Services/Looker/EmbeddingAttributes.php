<?php

namespace App\Services\Looker;

use App\Models\Dashboard\Dashboard;
use App\Models\User;

/**
 *
 */
class EmbeddingAttributes
{
    /**
     * @var array
     */
    private array $values = [];

    /**
     * @param Dashboard|null $report
     * @param User|null $user
     */
    public function __construct(
        private ?Dashboard $report = null,
        private ?User      $user = null
    )
    {
        $this->prepareValues();
    }

    /**
     * @param array $template
     * @return array
     */
    public function getConfig(array $template): array
    {
        $config = $this->resolveEmbeddingConfig($template);

        //check missed fields
        foreach (config("project.looker.embedded.config_template") as $key => $value) {
            $isExist = array_key_exists($key, $config);
            if ($key === "access_filters" && (!$isExist || empty($config[$key]))) {
                $config[$key] = new \stdClass();
                continue;
            }

            if (!$isExist) {
                $config[$key] = $value;
            }
        }

        $config['nonce'] = md5(uniqid());
        $config['time'] = time();

        return array_map(fn($value) => json_encode($value), $config);
    }

    /**
     * @param array $template
     * @return array
     */
    private function resolveEmbeddingConfig(array $template): array
    {
        $result = [];

        foreach ($template as $key => $value) {
            if (is_array($value)) {
                $result[$key] = \Arr::isAssoc($value)
                    ? $this->resolveEmbeddingConfig($value)
                    : $value;
                continue;
            }

            if (!is_string($value)) {
                $result[$key] = $value;
                continue;
            }

            $isAttribute = preg_match('/^\$[a-zA-Z0-9_]+\.([a-zA-Z0-9_]+)$/', $value, $matches);
            if (!$isAttribute) {
                $result[$key] = $value;
                continue;
            }

            $result[$key] = $this->getValue($value);
        }

        return $result;
    }

    /**
     * @return array
     */
    public static function getSchema(): array
    {
        return [
            "user"         => \Schema::getColumnListing('users'),
            "organization" => \Schema::getColumnListing('organizations'),
            "report"       => \Schema::getColumnListing('dashboards'),
            "workspace"    => \Schema::getColumnListing('environments'),
        ];
    }

    /**
     * @return void
     */
    private function prepareValues(): void
    {
        $schema = self::getSchema();
        $result = [
            "user"         => array_map(fn() => null, $schema["user"]),
            "organization" => array_map(fn() => null, $schema["organization"]),
            "report"       => array_map(fn() => null, $schema["report"]),
            "workspace"    => array_map(fn() => null, $schema["workspace"]),
        ];

        if ($this->report) {
            $result["report"] = $this->report->toArray();

            $workspace = $this->report->environment;
            if ($workspace) {
                $result["workspace"] = $workspace->toArray();
            }

            if ($workspace?->organization) {
                $result["organization"] = $workspace->organization->toArray();
            }
        }

        if ($this->user) {
            $result["user"] = $this->user->toArray();
        }

        $this->values = $result;
    }

    /**
     * @param string $key
     * @return mixed
     */
    public function getValue(string $key): mixed
    {
        $key = str_replace("$", "", $key);
        return \Arr::get($this->values, $key, null);
    }
}
