<?php

namespace App\Services\Looker;

use App\Utils\LoggerUtil;
use Carbon\Carbon;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Redis;
use Swagger\Client\Api\ApiAuthApi;
use Swagger\Client\Configuration;
use Swagger\Client\Model\AccessToken;
use Swagger\Client\Api\AuthApi;

/**
 *
 */
class Looker
{
    /**
     * @var string
     */
    private string $clientId;

    /**
     * @var string
     */
    private string $clientSecret;

    /**
     * @var Configuration
     */
    private Configuration $lookerConfiguration;

    /**
     * @var Client
     */
    private Client $authenticatedClient;

    /**
     * @var Carbon
     */
    private Carbon $tokenCreatedAt;

    /**
     * @var AccessToken
     */
    private AccessToken $accessToken;

    /**
     * @param Configuration|null $config
     * @throws \Swagger\Client\ApiException
     */
    public function __construct(?Configuration $config = null)
    {
        $this->setLookerConfig($config);
        $this->loadAccessToken();
        $this->login();
    }

    /**
     * @return void
     * @throws \Swagger\Client\ApiException
     */
    public function login(): void
    {
        if (!$this->isValidAccessToken()) {
            LoggerUtil::info("[Looker] Refreshing access token");

            $apiInstance = new ApiAuthApi(new Client(), $this->getLookerConfig());
            $result = $apiInstance->login($this->getClientId(), $this->getClientSecret());
            $this->saveAccessToken($result);
            $this->accessToken = $result;
        }

        $this->authenticatedClient = new Client([
            'verify'  => true,
            'headers' => [
                'Authorization' => 'token ' . $this->accessToken->getAccessToken(),
            ],
        ]);
    }

    /**
     * @return AuthApi
     */
    public function authApi(): AuthApi
    {
        return new AuthApi($this->authenticatedClient, $this->getLookerConfig());
    }

    /**
     * @return void
     */
    private function loadAccessToken(): void
    {
        $data = Redis::get($this->getCacheKey());
        if (!$data) {
            return;
        }

        $data = json_decode($data, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return;
        }

        if (isset($data["created_at"])) {
            $this->tokenCreatedAt = Carbon::createFromTimestamp($data["created_at"]);
        }

        $this->accessToken = new AccessToken($data);
    }

    /**
     * @param AccessToken $accessToken
     * @return void
     */
    public function saveAccessToken(AccessToken $accessToken): void
    {
        $data = [
            "access_token"  => $accessToken->getAccessToken(),
            "token_type"    => $accessToken->getTokenType(),
            "expires_in"    => $accessToken->getExpiresIn(),
            "refresh_token" => $accessToken->getRefreshToken(),
            "created_at"    => time(),
        ];

        Redis::set($this->getCacheKey(), json_encode($data));
    }

    /**
     * @return string
     */
    private function getCacheKey(): string
    {
        return 'looker_access_token:' . $this->getClientId();
    }

    /**
     * @return bool
     */
    public function isValidAccessToken(): bool
    {
        if (!isset($this->accessToken)) {
            return false;
        }

        if (!isset($this->tokenCreatedAt)) {
            return false;
        }

        return $this->tokenCreatedAt->addSeconds($this->accessToken->getExpiresIn())->isFuture();
    }

    /**
     * @return Configuration
     */
    public function getLookerConfig(): Configuration
    {
        return $this->lookerConfiguration;
    }

    /**
     * @param Configuration|null $config
     * @return $this
     */
    public function setLookerConfig(?Configuration $config = null): self
    {
        if (!$config) {
            $this->lookerConfiguration = new Configuration();
        }

        if ($this->lookerConfiguration->getHost()) {
            $this->lookerConfiguration->setHost(config('project.looker.api_host'));
        }

        return $this;
    }

    /**
     * @return string
     */
    public function getClientId(): string
    {
        if (!isset($this->clientId)) {
            return config('project.looker.client_id');
        }

        return $this->clientId;
    }

    /**
     * @param string $clientId
     * @return $this
     */
    public function setClientId(string $clientId): self
    {
        $this->clientId = $clientId;
        return $this;
    }

    /**
     * @return string
     */
    public function getClientSecret(): string
    {
        if (!isset($this->clientSecret)) {
            return config('project.looker.client_secret');
        }

        return $this->clientSecret;
    }

    /**
     * @param string $clientSecret
     * @return $this
     */
    public function setClientSecret(string $clientSecret): self
    {
        $this->clientSecret = $clientSecret;
        return $this;
    }

    /**
     * @param string $userAgent
     * @return $this
     */
    public function setUserAgent(string $userAgent): self
    {
        $this->lookerConfiguration->setUserAgent($userAgent);
        return $this;
    }
}
