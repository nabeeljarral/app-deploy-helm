<?php

namespace App\Services\Looker\EmbedSession;

use App\Abstractions\DataTransferObject;

class LookerEmbedSessionDto extends DataTransferObject
{
    public string $userAgent;
    public int $userId;
    public int $analyticsId;
    public ?int $reportId = null;
}
