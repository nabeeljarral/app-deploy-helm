<?php

namespace App\Services\Looker\EmbedSession;

use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Models\User;
use App\Models\Template\TemplateAnalytics;
use App\Services\Looker\EmbeddingAttributes;
use App\Services\Looker\Looker;
use Swagger\Client\Model\EmbedCookielessSessionAcquireResponse;
use \Swagger\Client\Model\EmbedCookielessSessionAcquire;

/**
 *
 */
class AcquireEmbedSession implements Runnable
{
    /**
     * @var TemplateAnalytics
     */
    private TemplateAnalytics $templateAnalytics;

    /**
     * @var EmbeddingAttributes
     */
    private EmbeddingAttributes $attributes;


    /**
     * @param Looker $looker
     * @param LookerEmbedSessionDto $dto
     * @throws \Exception
     */
    public function __construct(
        private Looker                $looker,
        private LookerEmbedSessionDto $dto,
    )
    {
        $this->templateAnalytics = TemplateAnalytics::query()->findOrFail($this->dto->analyticsId);

        if (!$this->templateAnalytics->looker_embedding_url) {
            throw new \Exception("Looker embedding url is not set");
        }

        if (!$this->templateAnalytics->looker_embedding_config) {
            throw new \Exception("Looker embedding config is not set");
        }

        $report = null;
        if ($this->dto->reportId) {
            $report = Dashboard::query()->where('id', $this->dto->reportId)->firstOrFail();
        }
        $user = User::query()->where('id', $this->dto->userId)->firstOrFail();

        $this->attributes = new EmbeddingAttributes($report, $user);
    }

    /**
     * @return EmbedCookielessSessionAcquireResponse
     * @throws \Swagger\Client\ApiException
     */
    public function run(): EmbedCookielessSessionAcquireResponse
    {
        $apiInstance = $this->looker->authApi();

        $userModel = $this->attributes->getConfig($this->templateAnalytics->looker_embedding_config);
        $body = new EmbedCookielessSessionAcquire($userModel);

        return $apiInstance->acquireEmbedCookielessSession($body);
    }
}
