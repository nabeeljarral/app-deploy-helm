<?php

namespace App\Services\Looker\EmbedSession;

use App\Services\Looker\Looker;
use App\Utils\LoggerUtil;
use Swagger\Client\Model\EmbedCookielessSessionGenerateTokens;
use Swagger\Client\Model\EmbedCookielessSessionAcquireResponse;

/**
 *
 */
class LookerEmbedSession
{
    /**
     * @var Looker
     */
    private Looker $looker;

    /**
     * @var EmbedCookielessSessionAcquireResponse
     */
    private EmbedCookielessSessionAcquireResponse $internalSession;

    /**
     * @param LookerEmbedSessionDto $dto
     */
    public function __construct(private LookerEmbedSessionDto $dto)
    {
        $this->looker = new Looker();
        $this->looker->setUserAgent($this->dto->userAgent);
        $this->loadInternalSession();
    }

    /**
     * @return array
     * @throws \Swagger\Client\ApiException
     */
    public function acquireEmbedSession(): array
    {
        $sessionResponse = (new AcquireEmbedSession($this->looker, $this->dto))->run();

        $this->storeInternalSession($sessionResponse);
        $this->internalSession = $sessionResponse;

        return $this->sessionResponseToArray($sessionResponse, ['session_reference_token']);
    }

    /**
     * @param string $apiToken
     * @param string $navigation_token
     * @return array
     * @throws \Swagger\Client\ApiException
     */
    public function generateEmbedTokens(string $apiToken, string $navigation_token): array
    {
        if (!isset($this->internalSession) || !$this->internalSession->getSessionReferenceToken()) {
            return [
                'session_reference_token_ttl' => 0,
            ];
        }

        $body = new EmbedCookielessSessionGenerateTokens([
            "api_token"               => $apiToken,
            "navigation_token"        => $navigation_token,
            "session_reference_token" => $this->internalSession->getSessionReferenceToken(),
        ]);

        $result = $this->looker
            ->authApi()
            ->generateTokensForCookielessSession($body);

        return [
            'api_token'                   => $result->getApiToken(),
            'api_token_ttl'               => $result->getApiTokenTtl(),
            'navigation_token'            => $result->getNavigationToken(),
            'navigation_token_ttl'        => $result->getNavigationTokenTtl(),
            'session_reference_token_ttl' => $result->getSessionReferenceTokenTtl(),
        ];
    }

    /**
     * @return string
     */
    private function getSessionCacheKey(): string
    {
        return "looker_embed_internal_session:" . $this->dto->userAgent . ":" . $this->dto->analyticsId;
    }

    /**
     * @return void
     */
    private function loadInternalSession(): void
    {
        $json = \Cache::get($this->getSessionCacheKey());
        $data = json_decode($json, true);

        if (empty($data)) {
            return;
        }

        $this->internalSession = new EmbedCookielessSessionAcquireResponse($data);
    }

    /**
     * @param EmbedCookielessSessionAcquireResponse $session
     * @return void
     */
    private function storeInternalSession(EmbedCookielessSessionAcquireResponse $session): void
    {
        $data = $this->sessionResponseToArray($session);
        \Cache::put($this->getSessionCacheKey(), json_encode($data), $session->getSessionReferenceTokenTtl());
    }

    /**
     * @param EmbedCookielessSessionAcquireResponse $session
     * @param array|null $except
     * @return array
     */
    private function sessionResponseToArray(EmbedCookielessSessionAcquireResponse $session, ?array $except = null): array
    {
        $data = [
            'api_token'                   => $session->getApiToken(),
            'api_token_ttl'               => $session->getApiTokenTtl(),
            'authentication_token'        => $session->getAuthenticationToken(),
            'authentication_token_ttl'    => $session->getAuthenticationTokenTtl(),
            'navigation_token'            => $session->getNavigationToken(),
            'navigation_token_ttl'        => $session->getNavigationTokenTtl(),
            'session_reference_token'     => $session->getSessionReferenceToken(),
            'session_reference_token_ttl' => $session->getSessionReferenceTokenTtl(),
        ];

        if ($except) {
            return \Arr::except($data, $except);
        }

        return $data;
    }
}
