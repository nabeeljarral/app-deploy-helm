<?php

namespace App\Presenters;

use App\Abstractions\Presenter;
use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardUser;
use App\Models\User;
use App\Services\User\Enums\UserRole;
use Illuminate\Support\Collection;

/**
 *
 */
class EnvironmentDashboardsPresenter implements Presenter
{
    /**
     * @var string|null
     */
    protected ?string $type = null;

    /**
     * @var bool
     */
    protected bool $ignoreMaxRole = false;

    /**
     * @param User $currentUser
     * @param int $environment_id
     */
    public function __construct(
        private User $currentUser,
        private int $environment_id

    )
    {

    }

    /**
     * @return Collection
     */
    public function present(): Collection
    {
        if (
            (!$this->ignoreMaxRole && $this->currentUser->getMaxRole() === UserRole::ENVIRONMENT_OWNER)
            || $this->currentUser->is_admin
        ) {

            $query = Dashboard::where('environment_id', $this->environment_id);
            if ($this->type) {
                $query->where('type', $this->type);
            }
            return  $query
                ->orderBy("type", 'DESC')
                ->orderBy("updated_at", 'DESC')->get();
        }

        $permissions = DashboardUser::where('environment_id', $this->environment_id)
            ->where('user_id', $this->currentUser->id)
            ->get();

        $result = Collection::empty();

        foreach ($permissions as $permission) {
            /**
             * User role in current dashboard/dashboards
             * @var $currentRole string
             */
            $currentRole = $permission->role;

            //if user is ENVIRONMENT_OWNER
            if ($permission->role === UserRole::ENVIRONMENT_OWNER || $this->currentUser->is_admin) {
                $items = Dashboard::where('environment_id', $this->environment_id);

                if ($this->type) {
                    $items->where('type', $this->type);
                }

                $items = $items->get();

                $items->map(function ($item) use ($currentRole) {
                    $item->current_role = $currentRole;
                });

                if (!$items->isEmpty()) {
                    $result->push(...$items);
                }

                continue;
            }

            $item = Dashboard::where('id', $permission->dashboard_id);
            if ($this->type) {
                $item->where('type', $this->type);
            }
            $item = $item->first();
            if ($item) {
                $item->current_role = $currentRole;
                $result->add($item);
            }
        }

        return $result
            ->unique("id")
            ->sortBy("type", SORT_REGULAR, true)
            ->sortBy("updated_at", SORT_REGULAR, true);
    }

    /**
     * @param string $type
     * @return void
     */
    public function setType(string $type): void
    {
        $this->type = $type;
    }

    /**
     * @param bool $ignoreMaxRole
     */
    public function setIgnoreMaxRole(bool $ignoreMaxRole): void
    {
        $this->ignoreMaxRole = $ignoreMaxRole;
    }
}
