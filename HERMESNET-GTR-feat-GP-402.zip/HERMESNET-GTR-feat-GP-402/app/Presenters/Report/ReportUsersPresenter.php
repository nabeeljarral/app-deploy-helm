<?php

namespace App\Presenters\Report;

use App\Abstractions\Presenter;
use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardUser;
use App\Models\Organization;
use App\Models\User;
use App\Services\User\Enums\UserRole;
use Illuminate\Database\Eloquent\Builder;

/**
 *
 */
class ReportUsersPresenter implements Presenter
{
    /**
     * @param Dashboard $dashboard
     */
    public function __construct(
        private Dashboard $dashboard
    )
    {

    }

    /**
     * @return iterable
     */
    public function present(): iterable
    {
        return User::where("organization_id", $this->dashboard->environment->organization_id)
            ->whereHas('dashboardUsers', function (Builder $query) {
                $query->where('role', UserRole::ENVIRONMENT_OWNER)
                    ->orWhere("dashboard_id", $this->dashboard->id);
            })
            ->get();
    }
}
