<?php

namespace App\Presenters\Report;

use App\Abstractions\Presenter;
use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\ReportItemPermissions;
use App\Models\Views\ConfigurationItemsView;
use App\Services\User\Enums\UserRole;
use App\Services\User\GetUserEntryRole;
use App\Transformers\Configuration\Item\NestedItemsTransformer;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use League\Fractal\TransformerAbstract;

/**
 *
 */
class ReportItemsNestedListPresenter implements Presenter
{
    /**
     * @var string[]
     */
    protected array $childrenScopes = [];

    /**
     * @var TransformerAbstract
     */
    protected TransformerAbstract $transformer;

    /**
     * @var string
     */
    protected string $relationName = "nestedItems";

    /**
     * @param Dashboard $report
     * @param bool $includedOnly
     * @param bool $checkPermissions
     */
    public function __construct(
        protected Dashboard $report,
        protected bool      $includedOnly = false,
        protected bool      $checkPermissions = false,
    )
    {

    }

    /**
     * @return array
     */
    public function present(): array
    {
        return [
            'items' => $this->getItems(),
            'meta'  => $this->getMeta(),
        ];
    }

    /**
     * @return array
     */
    public function getItems(): array
    {
        $transformer = $this->getTransformer();
        $items = $this->getItemsCollection();
        return fractal($items)
            ->transformWith($transformer)
            ->toArray();
    }

    /**
     * @return Collection
     */
    public function getItemsCollection(): Collection {
        $scopeQuery = $this->getItemsScopeQuery();
        ConfigurationItemsView::resolveRelationUsing($this->relationName, function (ConfigurationItemsView $model) use ($scopeQuery) {
            $query = $model->hasMany(ConfigurationItemsView::class, "parent_item_id", 'item_id');

            if (!empty($this->childrenScopes)) {
                $query->scopes($this->childrenScopes);
            }

            $query->with($this->relationName)
                ->where($scopeQuery)
                ->orderBy('order_number');

            return $query;
        });

        return ConfigurationItemsView::with($this->relationName)
            ->whereNull("parent_item_id")
            ->where($scopeQuery)
            ->orderBy('order_number')
            ->get();
    }

    /**
     * @return array
     */
    public function getMeta(): array
    {
        $meta = $this->report->items()
            ->selectRaw("count(*) as 'items_count'")
            ->selectRaw("count(is_included=1 or null) as 'included_items_count'")
            ->selectRaw("count(is_included=0 or null) as 'excluded_items_count'")
            ->first();

        return $meta->toArray();
    }

    /**
     * @return \Closure
     */
    public function getItemsScopeQuery(): \Closure
    {
        $availableItemsId = null;

        if ($this->checkPermissions && \Auth::check()) {
            $user = \Auth::user();
            $entryRole = GetUserEntryRole::get($user, $this->report);
            if ($entryRole === UserRole::DASHBOARD_CONTRIBUTOR) {
                $permissions = ReportItemPermissions::where('report_id', $this->report->id)
                    ->where("user_id", $user->id)
                    ->first();
                $availableItemsId = $permissions?->items_id ?? [];
            }
        }

        return function (Builder $query) use ($availableItemsId) {
            $query->where("report_id", $this->report->id);

            if ($this->includedOnly) {
                $query->where('is_included', true);
            }

            if ($this->checkPermissions && $availableItemsId) {
                $query->whereIn('id', $availableItemsId);
            }

            return $query;
        };
    }

    /**
     * @return TransformerAbstract
     */
    protected function getTransformer(): TransformerAbstract
    {
        if (isset($this->transformer)) {
            return $this->transformer;
        }

        return new NestedItemsTransformer();
    }


    /**
     * @param array $childrenScopes
     * @return void
     */
    public function setChildrenScopes(array $childrenScopes): void
    {
        $this->childrenScopes = $childrenScopes;
    }

    /**
     * @param TransformerAbstract $transformer
     * @return void
     */
    public function transformWith(TransformerAbstract $transformer): void
    {
        $this->transformer = $transformer;
    }

    /**
     * @param string $relationName
     * @return void
     */
    public function setRelationName(string $relationName): void
    {
        $this->relationName = $relationName;
    }
}
