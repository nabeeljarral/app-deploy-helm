<?php

namespace App\Presenters\Report;

use App\Abstractions\Presenter;
use App\Models\Dashboard\Dashboard;
use App\Models\Views\ConfigurationItemsView;
use App\Transformers\Configuration\Item\PrintingNestedItemsTransformer;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;

/**
 *
 */
class PrintReportItemsPresenter implements Presenter
{
    /**
     * @param Dashboard $report
     */
    public function __construct(private Dashboard $report)
    {
    }

    /**
     * @return array
     */
    public function present(): array
    {
        return fractal($this->getItems())
            ->transformWith(new PrintingNestedItemsTransformer())
            ->toArray();
    }

    /**
     * @return Collection
     */
    private function getItems(): Collection
    {
        $queryScope = function (Builder $query) {
            $query
                ->with("items")
                ->where("report_id", $this->report->id)
                ->where('is_included', true)
                ->where('include_in_printing', true)
                ->orderBy('order_number');
        };

        ConfigurationItemsView::resolveRelationUsing("items", function (ConfigurationItemsView $model) use ($queryScope) {
            $query = $model->hasMany(ConfigurationItemsView::class, "parent_item_id", 'item_id');
            $query->where($queryScope);
            return $query;
        });

        return ConfigurationItemsView::with("items")
            ->whereNull("parent_item_id")
            ->where($queryScope)
            ->get();
    }
}
