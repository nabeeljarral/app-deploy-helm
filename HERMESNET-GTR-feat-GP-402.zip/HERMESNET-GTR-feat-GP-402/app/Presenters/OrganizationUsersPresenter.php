<?php

namespace App\Presenters;

use App\Abstractions\Presenter;
use App\Models\Dashboard\DashboardUser;
use App\Models\User;
use App\Models\Views\UsersView;
use App\Models\Views\UsersWithPermissionsView;
use App\Services\User\Enums\UserRole;
use App\Utils\AvatarUtil;
use Illuminate\Support\Collection;

/**
 *
 */
class OrganizationUsersPresenter implements Presenter
{

    /**
     * @param User $currentUser
     */
    public function __construct(
        private User $currentUser
    )
    {

    }

    /**
     * @return Collection
     */
    public function present(): Collection
    {
        $currentUserPermissions = UsersWithPermissionsView::where('organization_id', $this->currentUser->organization_id)
            ->where("id", $this->currentUser->id)
            ->get();
        $curUserRoles = $currentUserPermissions->pluck("role")->toArray();
        $curUserMaxRole = (empty($curUserRoles))
            ? $this->currentUser->role
            : UserRole::getMaxRoleOf($curUserRoles);


        $availableUsersPermissions = UsersWithPermissionsView::where('organization_id', $this->currentUser->organization_id)
            ->orderBy("created_at", "ASC")
            ->get();

        //filter by max role in any  dashboards or environments
        $result = Collection::empty();

        /**
         * @var $item Collection
         */
        foreach ($availableUsersPermissions->groupBy(["id"]) as $item) {
            $maxRole = UserRole::getMaxRoleOf($item->pluck('role')->toArray());

            if (
                $curUserMaxRole != UserRole::ENVIRONMENT_OWNER
                && $maxRole != UserRole::ENVIRONMENT_OWNER
            ) {
                $item = $item->filter(function ($item) use ($currentUserPermissions){
                    $hasAccess = $currentUserPermissions->where("environment_id", $item->environment_id);
                    if ($hasAccess->count() > 0) {
                        return $item;
                    }
                });
            }

            if (!$item->isEmpty()) {
                $user = $item->where("role", $maxRole)->first();
                $user->role = $maxRole;
                $user->short_name = AvatarUtil::getShortName($user->name);
                $result->add($user);
            }
        }

        return $result->sortBy("created_at", SORT_ASC);
    }
}
