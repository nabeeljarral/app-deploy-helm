<?php

namespace App\Presenters;

use App\Abstractions\Presenter;
use App\Models\Environment;
use App\Models\User;
use App\Services\Common\DTO\PaginationDto;
use App\Services\Common\Serializer\DataArraySerializer;
use App\Services\User\Enums\UserRole;
use App\Transformers\EnvironmentTransformer;
use App\Utils\TransformersUtil;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Spatie\Fractalistic\ArraySerializer;

/**
 *
 */
class EnvironmentsPresenter implements Presenter
{
    /**
     * @var bool
     */
    protected bool $ignoreMaxRole = false;

    /**
     * @var PaginationDto|null
     */
    private ?PaginationDto $pagination;

    /**
     * @param User $user
     */
    public function __construct(
        private User $user
    )
    {
    }

    /**
     * @return Collection<Environment>
     */
    public function present(): iterable
    {
        $baseQuery = Environment::query()
            ->where('organization_id', $this->user->organization_id)
            ->withCount(['dashboards', 'dashboardUsers'])
            ->orderBy("updated_at", "DESC");

        if ($this->isCanSeeAllWorkspaces()) {
            return isset($this->pagination)
                ? $baseQuery->paginate(
                    perPage: $this->pagination->per_page,
                    page: $this->pagination->page
                )
                : $baseQuery->get();
        }

        $environments = $baseQuery
            ->select(["dsh_users.role as current_role", "environments.*"])
            ->join('dsh_users', 'environments.id', 'environment_id')
            ->where('dsh_users.user_id', $this->user->id)
            ->get();

        $result = Collection::empty();

        /**
         * @var $item Collection
         */
        foreach ($environments->groupBy("id") as $item) {
            $roles = $item->pluck("current_role")->toArray();
            $maxRole = UserRole::getMaxRoleOf($roles);

            $result->add($item->where('current_role', $maxRole)->first());
        }

        return isset($this->pagination)
            ? $result->paginate(
                perPage: $this->pagination->per_page,
                page: $this->pagination->page
            )
            : $result;
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function respond(Request $request): JsonResponse
    {
        $isPaginated = $request->boolean("paginated");
        if ($isPaginated) {
            $this->setPagination(PaginationDto::of($request->toArray()));
        }

        $transformer = new EnvironmentTransformer();
        $transformer->setIncludeCurrentRole(true);
        $transformer->setIncludeUsersCount(true);

        return fractal($this->present())
            ->withResourceName('data')
            ->transformWith($transformer)
            ->parseIncludes(TransformersUtil::getIncludesFromRequest($request))
            ->serializeWith($isPaginated ? DataArraySerializer::class : ArraySerializer::class)
            ->respond();
    }

    /**
     * @return bool
     */
    private function isCanSeeAllWorkspaces(): bool
    {
        return !$this->ignoreMaxRole
            && $this->user->getMaxRole() === UserRole::ENVIRONMENT_OWNER
            || $this->user->is_admin;
    }

    /**
     * @param bool $ignoreMaxRole
     * @return EnvironmentsPresenter
     */
    public function setIgnoreMaxRole(bool $ignoreMaxRole): static
    {
        $this->ignoreMaxRole = $ignoreMaxRole;
        return $this;
    }

    /**
     * @param PaginationDto|null $pagination
     * @return void
     */
    public function setPagination(?PaginationDto $pagination): void
    {
        $this->pagination = $pagination;
    }

}
