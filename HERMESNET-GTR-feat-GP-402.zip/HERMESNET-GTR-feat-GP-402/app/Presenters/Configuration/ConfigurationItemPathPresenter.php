<?php

namespace App\Presenters\Configuration;

use App\Abstractions\Presenter;
use App\Models\ConfigurationItem;
use App\Models\Views\ConfigurationItemsView;
use App\Transformers\Configuration\Item\ItemViewTransformer;

/**
 *
 */
class ConfigurationItemPathPresenter implements Presenter
{
    /**
     * @param ConfigurationItem $item
     */
    public function __construct(private ConfigurationItem $item)
    {

    }

    /**
     * @return iterable
     */
    public function present(): iterable
    {
        $result = [];
        $this->getPath($result, $this->item->item_id);
        return array_reverse($result);
    }

    /**
     * @param array $result
     * @param int $item_id
     * @return void
     */
    public function getPath(array &$result, int $item_id): void
    {
        $query = ConfigurationItemsView::where("item_id", $item_id);

        if ($this->item->report_id) {
            $query->where('report_id', $this->item->report_id);
        }else if ($this->item->configuration_id) {
            $query->where('configuration_id', $this->item->configuration_id);
        }

        $item = $query->first();

        if ($item) {
            $result[] = fractal($item)->transformWith(new ItemViewTransformer())->toArray();
        }

        if ($item->parent_item_id) {
            $this->getPath($result, $item->parent_item_id);
        }
    }
}
