<?php

namespace App\Presenters\Configuration;

use App\Abstractions\Presenter;
use App\Models\Template\Template;
use App\Models\Template\TemplateConfiguration;
use App\Models\Template\TemplateItem;
use App\Models\Views\ConfigurationItemsView;
use App\Transformers\Configuration\Item\NestedItemsTransformer;

/**
 *
 */
class ConfigurationItemsNestedListPresenter implements Presenter
{

    /**
     * @param TemplateConfiguration|Template $configuration
     */
    public function __construct(
        protected TemplateConfiguration|Template $configuration
    )
    {

    }

    /**
     * @return iterable
     */
    public function present(): iterable
    {
        $isTemplateItems = ($this->isGeneral() || $this->configuration->is_general);
        return [
            'items' => $isTemplateItems ? $this->getGeneralItems() : $this->getSaveItems(),
            'meta'  => $this->getMeta(),
        ];
    }

    /**
     * @return array
     */
    public function getSaveItems(): array
    {
        $transformer = new NestedItemsTransformer();
        $relationName = $transformer->getRelationName();

        ConfigurationItemsView::resolveRelationUsing($relationName, function (ConfigurationItemsView $model) use ($relationName) {
            return $model->hasMany(ConfigurationItemsView::class, "parent_item_id", 'item_id')
                ->with($relationName)
                ->where("configuration_id", $this->configuration->id)
                ->orderBy('order_number');
        });

        $items = ConfigurationItemsView::with($relationName)
            ->whereNull("parent_item_id")
            ->where("configuration_id", $this->configuration->id)
            ->orderBy('order_number')
            ->get();

        return fractal($items)
            ->transformWith($transformer)
            ->toArray();
    }

    /**
     * @return array
     */
    public function getGeneralItems(): array
    {
        $template_id = $this->configuration instanceof Template
            ? $this->configuration->id
            : $this->configuration->template_id;

        $items = TemplateItem::where("template_id", $template_id)
            ->whereNull("parent_item_id")
            ->orderBy('order_number')
            ->with("nestedItems")
            ->get();

        return fractal($items)
            ->transformWith(new \App\Transformers\Templates\NestedItemsTransformer())
            ->toArray();
    }

    /**
     * @return array
     */
    private function getMeta(): array
    {
        if ($this->isGeneral()) {
            if ($this->configuration instanceof Template) {
               $template = $this->configuration;
            }else {
                $template = $this->configuration->template;
            }

            $itemsCount = $template->items->count();
            return [
                'items_count'          => $itemsCount,
                'included_items_count' => $itemsCount,
                'excluded_items_count' => 0,
            ];
        }

        $meta = $this->configuration->items()
            ->selectRaw("count(*) as 'items_count'")
            ->selectRaw("count(is_included=1 or null) as 'included_items_count'")
            ->selectRaw("count(is_included=0 or null) as 'excluded_items_count'")
            ->first();

        return $meta->toArray();
    }


    /**
     * @return bool
     */
    private function isGeneral(): bool
    {
        return $this->configuration instanceof Template || $this->configuration->is_general;
    }
}
