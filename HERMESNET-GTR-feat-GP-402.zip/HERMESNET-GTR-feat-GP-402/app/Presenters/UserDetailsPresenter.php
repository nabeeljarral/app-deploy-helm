<?php

namespace App\Presenters;

use App\Abstractions\Presenter;
use App\Models\Dashboard\DashboardUser;
use App\Models\InvitedUser;
use App\Models\User;
use App\Services\User\Enums\UserRole;
use App\Services\User\Enums\UserType;
use App\Transformers\UserTransformer;
use App\Utils\AvatarUtil;
use Spatie\Fractalistic\ArraySerializer;

/**
 *
 */
class UserDetailsPresenter implements Presenter
{
    /**
     * @var string
     */
    private string $type = UserType::REGULAR;


    /**
     * @param User $currentUser
     * @param int $needleUserId
     */
    public function __construct(
        private User $currentUser,
        private int $needleUserId
    )
    {

    }


    /**
     * @return iterable
     */
    public function present(): iterable
    {
        if ($this->type === UserType::INVITED) {
            return $this->invitedUser();
        }

        $user = User::where('id', $this->needleUserId)->firstOrFail();

        $result = fractal($user)
            ->transformWith(new UserTransformer())
            ->serializeWith(ArraySerializer::class)
            ->toArray();

        $result['role'] = $user->getMaxRole() ?? $user->role;
        $result['short_name'] = AvatarUtil::getShortName($user->name);

        $permissionPresenter = new UserPermissionsPresenter(
            current: $this->currentUser,
            needle: $user
        );
        $result['permissions'] = $permissionPresenter->present();

        return $result;
    }

    /**
     * @return iterable
     */
    public function invitedUser(): iterable
    {
        $user = InvitedUser::where('id', $this->needleUserId)
            ->firstOrFail();

        $result = $user->toArray();
        $result['short_name'] = AvatarUtil::getShortName($user->name);

        $result['permissions'] = [
            [
                'id'               => null,
                'role'             => $user->role,
                'environment_id'   => $user->environment_id,
                'environment_name' => $user->environment_name,
                'dashboard_id'     => $user->dashboard_id,
                'dashboard_name'   => $user->dashboard_name,
            ]
        ];
        return $result;
    }

    /**
     * @param string $type
     */
    public function setType(string $type): void
    {
        $this->type = $type;
    }
}
