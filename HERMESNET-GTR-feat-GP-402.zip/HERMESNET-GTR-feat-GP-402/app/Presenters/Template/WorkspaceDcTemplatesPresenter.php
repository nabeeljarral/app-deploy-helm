<?php

namespace App\Presenters\Template;

use App\Abstractions\Presenter;
use App\Models\Environment;
use App\Models\Template\Template;
use App\Services\Dashboard\Enums\DashboardType;

/**
 * Workspace data collection templates presenter
 */
class WorkspaceDcTemplatesPresenter implements Presenter
{
    /**
     * @param Environment $workspace
     * @param string|null $category
     */
    public function __construct(
        protected Environment $workspace,
        protected ?string $category = null
    )
    {

    }

    /**
     * @return iterable
     */
    public function present(): iterable
    {
        $query = Template::query()
            ->where('is_archived', false)
            ->organizationTemplates($this->workspace->organization);

        if ($this->workspace->global_template_id) {
            $query->whereHas("relatedSummaries", function ($query) {
                $query->where("template_related_summary.summary_id", $this->workspace->global_template_id);
            })
                ->orWhere("use_with_any_summary", true);
        } else {
            $query->where("use_with_any_summary", true);
        }

        if ($this->category) {
            $query->where("category", $this->category);
        }

        return $query
            ->where("type", DashboardType::DASHBOARD)
            ->where("is_published", true)
            ->get();
    }

}
