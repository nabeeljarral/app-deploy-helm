<?php

namespace App\Presenters\Template;

use App\Abstractions\Presenter;
use App\Models\Template\TemplateItem;
use App\Transformers\Templates\TemplateItemTransformer;

/**
 *
 */
class TemplateItemPathPresenter implements Presenter
{
    /**
     * @param TemplateItem $item
     */
    public function __construct(protected TemplateItem $item)
    {

    }

    /**
     * @return iterable
     */
    public function present(): iterable
    {
        $result = [];
        $this->getPath($result, $this->item);
        return array_reverse($result);
    }

    /**
     * @param array $result
     * @param TemplateItem|null $item
     * @return void
     */
    public function getPath(array &$result, ?TemplateItem $item): void
    {
        if ($item) {
            $result[] = fractal($item)
                ->transformWith(new TemplateItemTransformer)
                ->toArray();
        }

        if ($item->parent_item_id) {
            $this->getPath($result, $item->parentItem);
        }
    }
}
