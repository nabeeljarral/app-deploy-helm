<?php

namespace App\Presenters;

use App\Abstractions\Presenter;
use App\Models\Dashboard\DashboardUser;
use App\Models\User;
use App\Services\User\Enums\UserRole;
use App\Transformers\UserPermissionsTransformer;
use Illuminate\Support\Collection;
use Spatie\Fractalistic\ArraySerializer;

class UserPermissionsPresenter implements Presenter
{
    public function __construct(
        private User $current,
        private User $needle,
    )
    {

    }

    public function present(): iterable
    {
        /**
         * @var $currentUserPerms Collection<DashboardUser>
         */
        $currentUserPerms = DashboardUser::where('user_id', $this->current->id)->get();

        /**
         * @var $needleUserPerms Collection<DashboardUser>
         */
        $needleUserPerms = DashboardUser::where('user_id', $this->needle->id)
            ->select('dsh_users.*')
            ->selectRaw('environments.name as environment_name')
            ->selectRaw('environments.color as environment_color')
            ->selectRaw("dashboards.name as dashboard_name")
            ->join('environments', 'environment_id', 'environments.id')
            ->leftJoin('dashboards', 'dashboard_id', 'dashboards.id')
            ->get();

        if ($this->current->getMaxRole() === UserRole::ENVIRONMENT_OWNER) {
            $result =  $needleUserPerms
                ->unique(function ($item) {
                    return $item['role'].$item['environment_id'].$item['dashboard_id'];
                });

            return $this->transform($result);
        }

        $result = $needleUserPerms->filter(function ($item) use ($currentUserPerms) {
            if ($item->role === UserRole::ENVIRONMENT_OWNER) {
                $canSee = $currentUserPerms->where('environment_id', $item->environment_id);
            } else {
                $canSee = $currentUserPerms->where('dashboard_id', $item->dashboard_id);
            }

            if ($canSee->count() > 0) {
                return $item;
            }
        });

        $result = $result
            ->unique(function ($item) {
                return $item['role'].$item['environment_id'].$item['dashboard_id'];
            });

        return $this->transform($result);
    }

    private function transform(Collection $items): array {
        return  fractal($items)
            ->transformWith(new UserPermissionsTransformer())
            ->serializeWith(ArraySerializer::class)
            ->toArray();
    }
}
