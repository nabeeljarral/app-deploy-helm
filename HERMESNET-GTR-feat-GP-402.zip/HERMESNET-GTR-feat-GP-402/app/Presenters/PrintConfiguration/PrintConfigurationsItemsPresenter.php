<?php

namespace App\Presenters\PrintConfiguration;

use App\Abstractions\Presenter;
use App\Models\Dashboard\Dashboard;
use App\Models\Template\Template;
use App\Models\Template\TemplateItem;
use App\Models\Views\ConfigurationItemsView;
use App\Presenters\Report\ReportItemsNestedListPresenter;
use Illuminate\Support\Collection;


/**
 *
 */
class PrintConfigurationsItemsPresenter implements Presenter
{
    /**
     * @var Template
     */
    private Template $template;

    /**
     * @var Dashboard
     */
    private ?Dashboard $report = null;

    /**
     * @param string $entity - template or report
     * @param int $entityId
     */
    public function __construct(
        private string $entity,
        private int    $entityId,
    )
    {
        if (!in_array($entity, ['template', 'report'])) {
            throw new \InvalidArgumentException('Invalid entity type');
        }

        if ($this->entity === 'report') {
            $this->report = Dashboard::findOrFail($this->entityId);
            $this->template = $this->report->globalTemplate;
        } else {
            $this->template = Template::findOrFail($this->entityId);
        }
    }

    /**
     * @return iterable
     */
    public function present(): iterable
    {
        $items = $this->getItems();
        return $this->prepareItems($items);
    }

    /**
     * @param Collection<ConfigurationItemsView|TemplateItem> $items
     * @return array
     */
    private function prepareItems(Collection $items): array
    {
        $result = [];
        foreach ($items as $entity) {
            if (!$this->isRichTextItem($entity)) {
                continue;
            }

            $item = $this->transformEntityItem($entity);

            if ($this->itemHasNestedItems($entity)) {
                $item['nestedItems'] = $this->prepareItems($entity->nestedItems);
            }

            $result[] = $item;
        }
        return $result;
    }

    /**
     * @param ConfigurationItemsView|TemplateItem $entity
     * @return array
     */
    public function transformEntityItem(ConfigurationItemsView|TemplateItem $entity): array
    {
        $template_item_id = ($entity instanceof ConfigurationItemsView) ? $entity->item_id : $entity->id;
        return [
            'id'               => (string)$entity->id,
            'template_item_id' => (string)$template_item_id,
            'name'             => $entity->name,
            'content'          => $entity->content,
            'is_included'      => (bool)$entity->is_included,
            'order_number'     => $entity->order_number,
            'use_google_sheet' => (bool)$entity->use_google_sheet,
            'nestedItems'      => [],
        ];
    }

    /**
     * @param ConfigurationItemsView|TemplateItem $item
     * @return bool
     */
    public function isRichTextItem(ConfigurationItemsView|TemplateItem $item): bool
    {
        if (!$item->use_google_sheet) {
            return true;
        }

        if ($this->itemHasNestedItems($item)) {
            foreach ($item->nestedItems as $nestedItem) {
                $use = $this->isRichTextItem($nestedItem);
                if ($use) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * @param ConfigurationItemsView|TemplateItem $item
     * @return bool
     */
    private function itemHasNestedItems(ConfigurationItemsView|TemplateItem $item): bool
    {
        return is_a($item->nestedItems, Collection::class) && !$item->nestedItems->isEmpty();
    }

    /**
     * @return Collection
     */
    private function getItems(): Collection
    {
        if ($this->entity === "template") {
            return $this->template->nestedItems;
        }

        $presenter = new ReportItemsNestedListPresenter($this->report, true, true);
        return $presenter->getItemsCollection();
    }
}
