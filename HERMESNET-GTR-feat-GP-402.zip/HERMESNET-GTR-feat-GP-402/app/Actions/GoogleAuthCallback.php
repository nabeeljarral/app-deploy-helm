<?php

namespace App\Actions;

use App\Abstractions\Runnable;
use App\Http\Requests\Auth\GoogleAuthCallbackRequest;
use Illuminate\Http\Request;
use Laravel\Socialite\Two\User as SocialiteUser;
use App\Models\User;

/**
 *
 */
class GoogleAuthCallback implements Runnable
{
    /**
     * @param int $state
     * @param SocialiteUser $socialiteUser
     */
    public function __construct(
        private int $state,
        private SocialiteUser $socialiteUser
    )
    {

    }

    /**
     * @return User|mixed|null
     */
    public function run()
    {
        $user = User::where("id", $this->state)->firstOrFail();

        if (is_null($user->google_email)) {
            $user->social_id = $this->socialiteUser->id;
            $user->social_type = "google";
            $user->google_email = $this->socialiteUser->email;

            $user->save();
            return $user;
        }

        if ($user->google_email == $this->socialiteUser->email) {
            return $user;
        }

        return null;
    }

}
