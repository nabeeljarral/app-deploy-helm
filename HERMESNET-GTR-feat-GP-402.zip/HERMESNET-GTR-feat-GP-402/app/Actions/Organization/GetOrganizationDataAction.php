<?php

namespace App\Actions\Organization;

use App\Abstractions\Runnable;
use App\Models\Organization;
use App\Models\User;
use App\Utils\LoggerUtil;

class GetOrganizationDataAction implements Runnable
{
    private int $userId;

    /**
     * @param int $userId
     */
    public function __construct(int $userId)
    {
        $this->userId = $userId;
    }


    public function run()
    {
        return $this->getOrganizationData();
    }


    /**
     * @return array
     */
    private function getOrganizationData() :array{
        try{
            $user = User::where('id' ,$this->userId)->firstOrFail();
            return $user->organization->toArray();
        }catch (\Exception $exception){
            LoggerUtil::exception($exception);
            return [];
        }
    }

}
