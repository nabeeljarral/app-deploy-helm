<?php

namespace App\Actions\Organization;

use App\Abstractions\Runnable;
use App\Models\OrgFolderPermissions;
use App\Models\User;
use App\Services\Google\Permissions\RevokeFilePermissions;
use App\Utils\LoggerUtil;

/**
 *
 */
class RevokeOrgFolderPermissions implements Runnable
{
    /**
     * @param User $user
     */
    public function __construct(
        private User $user
    )
    {

    }

    /**
     * @return bool
     */
    public function run(): bool
    {
        LoggerUtil::info("RevokeOrgFolderPermissions::run", ['user_id' => $this->user->id]);

        $folderPermissions = OrgFolderPermissions::where('organization_id', $this->user->organization_id)
            ->where('user_id', $this->user->id)
            ->firstOrFail();

        $revokeAction = new RevokeFilePermissions(
            fileId: $this->user->organization->drive_folder_id,
            permissionsId: $folderPermissions->permissions_id
        );
        $revokeAction->run();


        return $folderPermissions->delete();
    }
}
