<?php

namespace App\Actions\Organization;

use App\Abstractions\Runnable;
use App\Models\OrgFolderPermissions;
use App\Models\User;
use App\Services\Google\Enums\GoogleDriveFileRole;
use App\Services\Google\Permissions\CreateFilePermissions;
use App\Utils\LoggerUtil;

/**
 *
 */
class CreateOrgFolderPermissions implements Runnable
{
    /**
     * @param User $user
     */
    public function __construct(
        private User $user
    )
    {

    }

    /**
     * @return OrgFolderPermissions|null
     */
    public function run(): ?OrgFolderPermissions
    {
        LoggerUtil::info("CreateOrgFolderPermissions::run", ['user_id' => $this->user->id]);

        if ($this->alreadyExists() || !$this->user->google_email) {
            return null;
        }

        $folderPermissions = new OrgFolderPermissions();
        $folderPermissions->organization_id = $this->user->organization_id;
        $folderPermissions->user_id = $this->user->id;
        $folderPermissions->permissions_id = $this->createPermission();
        $folderPermissions->save();

        return $folderPermissions;
    }

    /**
     * @return string
     */
    private function createPermission(): string
    {
        $action = new CreateFilePermissions(
            fileId: $this->user->organization->drive_folder_id,
            role: GoogleDriveFileRole::WRITER,
            email: $this->user->google_email
        );

        $filePermissions = $action->run();

        return $filePermissions->getId();
    }

    /**
     * @return bool
     */
    public function alreadyExists(): bool
    {
        return OrgFolderPermissions::where("organization_id", $this->user->organization_id)
            ->where('user_id', $this->user->id)
            ->exists();
    }
}
