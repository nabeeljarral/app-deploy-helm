<?php

namespace App\Actions\Organization;

use App\Abstractions\Runnable;
use App\Models\Organization;
use App\Models\User;
use App\Utils\LoggerUtil;

class SaveOrganizationAction implements Runnable
{
    /**
     * @var array
     */

    private array $data;

    /**
     * @param array $data
     */
    public function __construct(array $data)
    {
        $this->data = $data;
    }

    public function run()
    {
        return $this->saveData();
    }

    /**
     * @return bool
     */
    private function saveData(): bool
    {
        try {
            $user = User::where("id", $this->data['user_id'])->firstOrFail();
            if (is_null($user))
                return false;

            if (!is_null($user->organization_id) && !is_null($organization = Organization::where('id', $user->organization_id)->first())) {
                $organization->organization_name = $this->data['name'];
                $organization->country = $this->data['country'];
                $organization->city = $this->data['city'];
                $organization->save();
            } else {
                $organization = new Organization();
                $organization->user_id = $this->data['user_id'];
                $organization->organization_name = $this->data['name'];
                $organization->country = $this->data['country'];
                $organization->city = $this->data['city'];
                $organization->is_trial_access = true;
                $organization->trial_expired_at = now()->addDays(config('project.subscription.trial.duration'));
                $organization->save();

                $user->organization_id = $organization->id;
                $user->save();
            }
            return true;
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return false;
        }
    }

}
