<?php

namespace App\Actions\Organization;

use App\Abstractions\Runnable;
use App\Models\User;
use App\Services\Google\Enums\GoogleDriveFileRole;
use App\Services\Google\Permissions\CreateFilePermissions;
use App\Utils\GoogleUtil;
use App\Utils\LoggerUtil;
use Google\Client;
use Google\Service\Drive;

/**
 *
 */
class CreateOrganizationFolder implements Runnable
{
    /**
     * @var User
     */
    private User $user;

    /**
     * @param User $user
     */
    public function __construct(User $user)
    {
        $this->user = $user;
    }

    /**
     * @return string
     */
    public function run(): string
    {
        LoggerUtil::info("CreateOrganizationFolder::run", ['user_id' => $this->user->id, 'organization_id' => $this->user->organization_id]);
        
        $folderName = config("project.google.drive.clients_folder_prefix") . $this->user->organization->id;

        $googleClient = GoogleUtil::apiClient([Drive::DRIVE]);

        $folderMeta = new Drive\DriveFile();
        $folderMeta->setName($folderName);
        $folderMeta->setMimeType(config('project.google.drive.meta.mime.folder'));
        $folderMeta->setParents([config('project.google.drive.clients_folder_id')]);

        $driveService = new Drive($googleClient);
        $clientFolder = $driveService->files->create($folderMeta);

        return $clientFolder->getId();
    }
}
