<?php

namespace App\Actions\DashBoard;

use App\Abstractions\Runnable;
use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardProtection;
use App\Utils\LoggerUtil;

class FetchDashboardTabsAction implements Runnable
{
    /**
     * @var int
     */
    protected int $environmentId;

    /**
     * @var int
     */
    protected int $dashboardId;

    /**
     * @var string
     */
    protected string $fileId;

    /**
     * @param int $environmentId
     * @param string $fileId
     */
    public function __construct(int $environmentId, string $fileId, int $dashboardId)
    {
        $this->environmentId = $environmentId;
        $this->fileId = $fileId;
        $this->dashboardId = $dashboardId;
    }


    public function run()
    {
        return $this->fetchDashboardTabs();
    }

    /**
     * @return void|null
     */
    private function fetchDashboardTabs(): array|null
    {
        try {
            $existRange = [];
            $dashboardsProtection = DashboardProtection::where('dashboard_id', $this->dashboardId)
                ->with('unprotectedRanges')
                ->with('sheet')
                ->get();
            foreach ($dashboardsProtection as $item) {
                if ($item->unprotectedRanges->count() > 0) {
                    array_push($existRange, [
                        'id' => $item->id,
                        'sheet_id' => $item->sheet_id,
                        'sheet' => $item->sheet,
                        'range' => $item->unprotectedRanges
                    ]);
                }
            }

            $dashboard = Dashboard::where('environment_id', $this->environmentId)
                ->where('file_id', $this->fileId)
                ->first();

            if (is_null($dashboard)) {
                $dashboard = [];
            }
            return [
                'dashboard_id' => $this->dashboardId,
                'existRange' => $existRange,
                'dashboards' => $dashboard->sheets->toArray(),
            ];
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return null;
        }
    }
}
