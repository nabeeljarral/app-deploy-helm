<?php

namespace App\Modules\Core\Validation;

final class ValidationResult
{
    public function __construct(
        public ValidationStatus $status = ValidationStatus::success,
        public array $data = [],

    )
    {
    }

    public function addData(mixed $data, string|int $key = null): void
    {
        if (empty($key)) {
            $this->data[] = $data;
        } else {
            $this->data[$key] = $data;
        }
    }

    public function setData(array $data): void
    {

    }

    public function isValid(): bool
    {
        return $this->status === ValidationStatus::success;
    }

    public function toArray(): array
    {
        return [
            'status' => $this->status->value,
            'data' => $this->data,
        ];
    }
}
