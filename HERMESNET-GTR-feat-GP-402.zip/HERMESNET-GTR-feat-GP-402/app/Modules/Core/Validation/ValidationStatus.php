<?php

namespace App\Modules\Core\Validation;

enum ValidationStatus: string
{
    case success = 'success';
    case error = 'error';
}
