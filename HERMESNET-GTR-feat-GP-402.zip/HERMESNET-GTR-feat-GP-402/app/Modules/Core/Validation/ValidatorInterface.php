<?php

namespace App\Modules\Core\Validation;

interface ValidatorInterface
{
    public function validate(mixed $data): ValidationResult;
}
