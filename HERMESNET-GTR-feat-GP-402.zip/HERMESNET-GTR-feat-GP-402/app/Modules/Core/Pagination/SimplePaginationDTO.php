<?php
namespace App\Modules\Core\Pagination;

final readonly class SimplePaginationDTO
{
    private int $count;
    private int $totalPages;

    public function __construct(
        public int $page,
        public int $perPage,
    )
    {}

    public function setCount(int $count): void
    {
        $this->count = $count;
    }

    public function getTotalPages(): int
    {
        if (! empty($this->totalPages)) {
            return $this->totalPages;
        }
        return $this->totalPages = ceil($this->count / $this->perPage);
    }


    public function toArray(): array
    {
        return [
            "count" => $this->count,
            "current_page" => $this->page,
            "per_page" => $this->perPage,
            "total_pages" => $this->getTotalPages(),
        ];
    }
}
