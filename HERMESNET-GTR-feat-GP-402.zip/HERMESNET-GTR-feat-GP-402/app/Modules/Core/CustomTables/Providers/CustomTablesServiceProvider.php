<?php

namespace App\Modules\Core\CustomTables\Providers;

use  App\Modules\Core\CustomTables\Repositories\CustomTableAnalyticsRepository;
use  App\Modules\Core\CustomTables\Repositories\CustomTableAnalyticsRepositoryInterface;
use Illuminate\Support\ServiceProvider;

class CustomTablesServiceProvider extends ServiceProvider
{
    public function boot()
    {

    }

    public function register(): void
    {
        $this->app->singleton(CustomTableAnalyticsRepositoryInterface::class, CustomTableAnalyticsRepository::class);
    }
}
