<?php

namespace App\Modules\Core\CustomTables\Repositories;

use App\Modules\Admin\Factors\Repositories\AdmFactorFieldsRepositoryInterface;
use App\Modules\Core\Database\DBService;
use App\Modules\Core\Database\AnalyticsSchema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Schema;

final readonly class CustomTableAnalyticsRepository implements CustomTableAnalyticsRepositoryInterface
{
    /**
     * Get fields for a report table creation as an array of Eloquent Scheme Blueprint field arrays
     * @param array $customTable Custom table data
     * @return array|null Eloquent Scheme Blueprint field array
     */
    protected function getFieldsForReportTable(array $customTable): ?array
    {
        // Keys is type that is stored in customTable['fields'][field]['type']
        // Values is eloquent schema blueprint field creation function name
        static $typeToEloquent = [
            'string' => 'string',
            'integer' => 'integer',
            'float' => 'float',
            'date' => 'date',
            'quarter' => 'date',
        ];

        // System fields
        $res = [
            'row_id' => fn(Blueprint $table) => $table->integer('row_id'),
            'report_id' => fn(Blueprint $table) => $table->integer('report_id'),
            'item_id' => fn(Blueprint $table) => $table->integer('item_id'),
        ];

        $fields = $customTable['fields'];
        $fieldsOrder = $customTable['fields_order'];

        $factorFields = DBService::inAppConnection(function($factorId)  {
            return app(AdmFactorFieldsRepositoryInterface::class)->getFactorFields($factorId, ['system_name', 'role']);
        }, $customTable['factor']);
        foreach ($factorFields as $field) {
            $res[$field['system_name']] = fn(Blueprint $table) => $table->text($field['system_name']);
        }

        foreach ($fieldsOrder as $field) {
            if (!empty($fields[$field])) {
                $res[$field] = fn(Blueprint $table) => $table->{$typeToEloquent[$fields[$field]['type']]}($field);
            }
        }

        return $res;
    }

    /**
     * Performs a simple prefixing of the table name with the analytics database name
     * @param string $tableName Table name. Ex: `custom_table`
     * @return string Prefixed table name. Ex: `report_data.custom_table`
     */
    protected function dbTableName(string $tableName): string
    {
        static $res = AnalyticsSchema::reportData->value; // Since enums can't be changed in runtime, we can "cache" it
        return $res . '.' . $tableName;
    }

    /**
     * Create a custom table in the analytics database
     * @param array $customTable Custom table data (mainly from `TemplateItem->custom_table_meta` )
     */
    public function createCustomTable(array $customTable): void
    {
        DBService::inAnalyticsConnection(function() use($customTable) {
            $tableName = self::dbTableName($customTable['system_name']);
            if( Schema::hasTable($tableName) ){ return; }

            Schema::create($tableName, function (Blueprint $table) use ($customTable) {
                foreach( $this->getFieldsForReportTable($customTable) as $colName => $colFn ){
                    $colFn($table);
                }
            });
        });
    }

    /**
     * Update a custom table in the analytics database
     * IT DOES NOT DROP OLD COLUMNS! (As yet there is no way to tell which should be dropped and which should be renamed. Each renamed column is treated as new one)
     * @param array $newCustomTable New custom table data
     * @param array $originalCustomTable Original custom table data
     */
    public function updateCustomTable(array $newCustomTable, array $originalCustomTable): void
    {
        if ($newCustomTable['system_name'] !== $originalCustomTable['system_name']) {
            $this->renameCustomTable($originalCustomTable['system_name'], $newCustomTable['system_name']);
        }

        $newFields = $this->getFieldsForReportTable($newCustomTable);
        $originalFields = $this->getFieldsForReportTable($originalCustomTable);

        $rowsToAddKeys = array_diff_key($newFields, $originalFields);

        if (!empty($rowsToAdd) ) {
            $tableName = self::dbTableName($newCustomTable['system_name']);
            Schema::table($tableName, function (Blueprint $table) use ($rowsToAddKeys, $newFields) {
                foreach ($rowsToAddKeys as $rowToAddKey) {
                    $newFields[$rowToAddKey]($table);
                }
            });
        }
    }

    /**
     * Rename a custom table in the analytics database
     * @param string $oldSystemName Old system name of the custom table
     * @param string $newSystemName New system name of the custom table
     */
    public function renameCustomTable(string $oldTableName, string $newTableName): void
    {
        Schema::rename(
            self::dbTableName($oldTableName),
            self::dbTableName($newTableName)
        );
    }

    /**
     * Delete a custom table from the analytics database
     * @param string $systemName System name of the custom table
     */
    public function deleteCustomTable(string $tableName): void
    {
        DBService::inAnalyticsConnection(function($tableName) {
            Schema::dropIfExists($tableName);
        }, self::dbTableName($tableName));
    }

    public function insertRow(string $tableName, int|string $reportId, int|string $itemId, int|string $rowId = -1, array $data): void
    {
        $nextRowId = $this->getNextRowId($tableName, $reportId, $itemId);
        $rowId = $rowId == -1 ? $nextRowId : ($rowId>=$nextRowId ? $nextRowId : $rowId);

        // Move all row_ids that are greater than or equal to the new row to +1
        if ($rowId >= 0) {
            DBService::inAnalyticsConnection(function($tableName, $reportId, $itemId, $rowId) {
                DB::table($tableName)
                    ->where('report_id', $reportId)
                    ->where('item_id', $itemId)
                    ->where('row_id', '>=', $rowId) // Target rows with row_id greater than or equal to the new row
                    ->increment('row_id'); // Increment row_id for all these rows
            }, self::dbTableName($tableName), $reportId, $itemId, $rowId);
        }

        DBService::inAnalyticsConnection(function($tableName, $data) {
            DB::table($tableName)->insert($data);
        },
        self::dbTableName($tableName),
        [
            'report_id' => $reportId,
            'item_id'   => $itemId,
            'row_id'    => $rowId,
            ...$data
        ]);
    }

    
    public function updateRow(string $tableName, int|string $reportId, int|string $itemId, int|string $rowId, array $data): void
    {
        DBService::inAnalyticsConnection(function($tableName) use($reportId, $itemId, $rowId, $data) {
            DB::table($tableName)
                ->where('report_id', $reportId)
                ->where('item_id', $itemId)
                ->where('row_id', $rowId)
                ->update($data);
        }, self::dbTableName($tableName));
    }

    /**
     * Get the next row ID for a custom table
     * @param string $tableName Name of the custom table
     * @return int Last row ID
     */
    public function getNextRowId(string $tableName, int|string $reportId, int|string $itemId): int
    {
        return DBService::inAnalyticsConnection(function($tableName) use($reportId, $itemId) {
            return DB::table($tableName)
                ->where('report_id', $reportId)
                ->where('item_id', $itemId)
                ->max('row_id') ?? 0;
                }, self::dbTableName($tableName)
            ) + 1;
    }

    /**
     * Reloads rows order in a custom table
     * @param string $tableName Name of the custom table
     */
    public function reloadRows(string $tableName, int|string $reportId, int|string $itemId): void
    {
        // Update all row_ids in one query based on the current order
        $tableName = self::dbTableName($tableName);
        DB::table($tableName)
            ->where('report_id', $reportId)
            ->where('item_id', $itemId)
            ->orderBy('row_id')
            ->chunkById(100, function ($rows) use (&$newRowId, $tableName) {
                foreach ($rows as $row) {
                    DB::table($tableName)
                        ->where('report_id', $row->report_id)
                        ->update(['row_id' => $newRowId++]);
                }
            });
    }

    /**
     * Delete a row from a custom table
     * @param string $tableName Name of the custom table
     * @param int $reportId Record ID of the row to delete
     */
    public function deleteRow(string $tableName, int|string $reportId, int|string $itemId, int|string $rowId): void
    {
        \Log::info('Deleting row', ['tableName' => $tableName, 'reportId' => $reportId, 'itemId' => $itemId, 'rowId' => $rowId]);
        DBService::inAnalyticsConnection(function($tableName) use($reportId, $itemId, $rowId) {
            DB::table($tableName)
                ->where('report_id', $reportId)
                ->where('item_id', $itemId)
                ->where('row_id', $rowId)
                ->delete();
            DB::table($tableName)
                ->where('report_id', $reportId)
                ->where('item_id', $itemId)
                ->where('row_id', '>', $rowId)
                ->decrement('row_id');
        }, self::dbTableName($tableName));

    }

    /**
     * Fetch rows from a custom table
     * @param string $tableName Name of the custom table
     * @param array $conditions Conditions to filter rows
     * @param array|string $columns Columns to fetch
     * @return array Rows
     */
    public function fetchRows(string $tableName, int|string $reportId, int|string $itemId, array|string $columns = ['*']): array
    {
        return DBService::inAnalyticsConnection(
        function($tableName) use($reportId, $itemId, $columns) {
            $query = DB::table($tableName)
                ->where('report_id', $reportId)
                ->where('item_id', $itemId);

            return $query->orderBy('row_id')
                ->get($columns)
                ->toArray();
        }, 
            self::dbTableName($tableName),
        );
    }

    /**
     * Upsert rows in a custom table
     * 
     * @param string $tableName Name of the custom table
     * @param int|string $reportId Record ID of the report
     * @param int|string $itemId Record ID of the item
     * @param array $rows Rows to upsert (associative array of row data, where the key is the name of column and the value is the value)
     * @param int $startingIndex Optional starting index of the rows to upsert. If not specified - upsert will start overwriting from the first row
     * @param int $endingIndex Optional ending index of the rows to upsert. If not specified - will overwrite everything after starting index. If specified - will overwrite only the rows between starting and ending indexes
     * @return bool
     */
    public function upsertRows(string $tableName, int|string $reportId, int|string $itemId, array $rows, int $startingIndex = 0, int $endingIndex = INF): bool
    {
        $startingIndex = max($startingIndex, 0);
        $endingIndex = min($endingIndex, $startingIndex + count($rows) - 1);

        DBService::inAnalyticsConnection(function () use ($tableName, $reportId, $itemId, $rows, $startingIndex, $endingIndex) {
            try{
                $tableName = self::dbTableName($tableName);

                $existingRows = DB::table($tableName)
                    ->where('report_id', $reportId)
                    ->where('item_id', $itemId)
                    ->whereBetween('row_id', [$startingIndex, $endingIndex])
                    ->get()
                    ->keyBy('row_id')
                    ->toArray();

                $insertRows = [];
                foreach ($rows as $index => $rowData) {
                    $rowId = $startingIndex + $index;

                    if (isset($existingRows[$rowId])) {
                        DB::table($tableName)
                            ->where('report_id', $reportId)
                            ->where('item_id', $itemId)
                            ->where('row_id', $rowId)
                            ->update($rowData);
                    } else {
                        $insertRows[] = [
                            'report_id' => $reportId,
                            'item_id'   => $itemId,
                            'row_id'    => $rowId,
                            ...$rowData,
                        ];
                    }
                }

                if (!empty($insertRows)) {
                    DB::table($tableName)->insert($insertRows);
                }

                $rowsCount = count($rows);
                DB::table($tableName)
                    ->where('report_id', $reportId)
                    ->where('item_id', $itemId)
                    ->where('row_id', '>', $endingIndex)
                    ->increment('row_id', $rowsCount);
            } catch(\Exception $e){
                \Log::warning('Error upserting rows', ['error' => $e->getMessage()]);
                return false;
            }
        });

        return true;
    }
}
