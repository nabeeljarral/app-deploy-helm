<?php

namespace App\Modules\Core\CustomTables\Repositories;

interface CustomTableAnalyticsRepositoryInterface
{
    public function createCustomTable(array $customTable): void;

    public function updateCustomTable(array $newCustomTable, array $originalCustomTable): void;

    public function renameCustomTable(string $oldTableName, string $newTableName): void;

    public function deleteCustomTable(string $tableName): void;

    public function insertRow(string $tableName, int|string $reportId, int|string $itemId, int|string $rowId = -1, array $data): void;

    public function updateRow(string $tableName, int|string $reportId, int|string $itemId, int|string $rowId, array $data): void;

    public function getNextRowId(string $tableName, int|string $reportId, int|string $itemId): int;

    public function reloadRows(string $tableName, int|string $reportId, int|string $itemId): void;

    public function deleteRow(string $tableName, int|string $reportId, int|string $itemId, int|string $rowId): void;

    public function fetchRows(string $tableName, int|string $reportId, int|string $itemId, array|string $columns = ['*']): array;

    public function upsertRows(string $tableName, int|string $reportId, int|string $itemId, array $rows, int $startingIndex=0, int $endingIndex=INF): bool;
}
