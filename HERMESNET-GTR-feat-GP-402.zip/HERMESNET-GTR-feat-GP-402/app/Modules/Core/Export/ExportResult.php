<?php

namespace App\Modules\Core\Export;

final readonly class ExportResult
{
    public function __construct(
        public string $path,
        public string $name,
        public string $type,
    )
    {
    }
}
