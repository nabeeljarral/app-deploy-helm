<?php

namespace App\Modules\Core\Models\Scopes;

use App\Modules\Core\Pagination\SimplePaginationDTO;

use Illuminate\Database\Eloquent\Builder;

/**
 * @method static Builder|self simplePagination(SimplePaginationDTO $simplePagination)
 */
trait SimplePaginationScope
{
    public function scopeSimplePagination(
        Builder $builder,
        SimplePaginationDTO $simplePagination,
    ): void
    {
        $builder
            ->take($simplePagination->perPage)
            ->offset($simplePagination->perPage * ($simplePagination->page - 1));
    }
}
