<?php
namespace App\Modules\Core\Entities\Enums;

enum TemplateItemType: int
{
    case richText = 0;
    case googleSheet = 1;
    case customTable = 2;
}
