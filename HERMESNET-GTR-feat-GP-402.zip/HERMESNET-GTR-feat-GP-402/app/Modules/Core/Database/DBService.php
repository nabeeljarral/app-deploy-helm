<?php

namespace App\Modules\Core\Database;

use Illuminate\Support\Facades\DB;

readonly final class DBService
{
    /**
     * Sets the default connection to the analytics database.
     */
    static public function setConnectionToAnalyticsDB(): void
    {
        DB::setDefaultConnection(DBConnections::analytics->value);
    }

    /**
     * Sets the default connection to the app database.
     */
    static public function setConnectionToAppDB(): void
    {
        DB::setDefaultConnection(DBConnections::app->value);
    }

    /**
     * Sets the search path for the analytics database.
     * Example: `DBService::setAnalyticsSchema(AnalyticsSchema::emissionFactors);`
     * 
     * @param AnalyticsSchema $analyticsSchema
     */
    static public function setAnalyticsSchema(AnalyticsSchema $analyticsSchema): void
    {
        config(['database.connections.'.DBConnections::analytics->value.'.search_path' => $analyticsSchema->value]);
    }

    /**
     * Calls the provided callback with the connection set to the analytics database.
     * The connection is then reset to the one used before.
     * 
     * @param callable $callback Callback to call with the connection set to the analytics database
     * @param mixed ...$callbackParameters Callback parameters
     * 
     * @return mixed Callback result
     */
    static public function inAnalyticsConnection(callable $callback, ...$callbackParameters): mixed
    {
        $currentConnection = DB::getDefaultConnection();

        self::setConnectionToAnalyticsDB();
        
        try{
            $res = $callback(...$callbackParameters);
        } catch (\Exception $e) {
            DB::setDefaultConnection($currentConnection);
            throw $e;
        }

        DB::setDefaultConnection($currentConnection);

        return $res;
    }

    /**
     * Calls the provided callback with the connection set to the app database.
     * The connection is then reset to the one used before.
     * 
     * @param callable $callback Callback to call with the connection set to the app database
     * @param mixed ...$callbackParameters Callback parameters
     * 
     * @return mixed Callback result
     */
    static public function inAppConnection(callable $callback, ...$callbackParameters): mixed
    {
        $currentConnection = DB::getDefaultConnection();

        self::setConnectionToAppDB();

        try{
            $res = $callback(...$callbackParameters);
        } catch (\Exception $e) {
            DB::setDefaultConnection($currentConnection);
            throw $e;
        }

        DB::setDefaultConnection($currentConnection);

        return $res;
    }
}
