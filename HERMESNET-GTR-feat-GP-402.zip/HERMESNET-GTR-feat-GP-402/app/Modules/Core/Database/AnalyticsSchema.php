<?php

namespace App\Modules\Core\Database;

enum AnalyticsSchema: string
{
    case emissionFactors = 'emission_factors';
    case reportData = 'report_data';
}
