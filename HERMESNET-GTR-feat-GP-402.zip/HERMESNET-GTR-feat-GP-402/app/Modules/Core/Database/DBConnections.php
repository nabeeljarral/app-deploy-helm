<?php

namespace App\Modules\Core\Database;

enum DBConnections: string
{
    case app = 'mysql';
    case analytics = 'db2';
}
