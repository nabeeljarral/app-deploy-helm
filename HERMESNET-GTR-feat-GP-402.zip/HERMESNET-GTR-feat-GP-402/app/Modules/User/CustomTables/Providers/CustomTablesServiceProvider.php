<?php

namespace App\Modules\User\CustomTables\Providers;

use App\Modules\User\CustomTables\Repositories\CustomTableRepository;
use App\Modules\User\CustomTables\Repositories\CustomTableRepositoryInterface;
use Illuminate\Support\ServiceProvider;

class CustomTablesServiceProvider extends ServiceProvider
{
    public function boot()
    {

    }

    public function register(): void
    {
        $this->app->singleton(CustomTableRepositoryInterface::class, CustomTableRepository::class);
    }
}
