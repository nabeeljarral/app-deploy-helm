<?php

namespace App\Modules\User\CustomTables\Repositories;

interface CustomTableRepositoryInterface
{
    public function getFactorColumns(\App\Models\Template\TemplateItem|int $templateItem, string|array $cols = 'system_name', bool $pluck = true);
    
    public function getTemplateItemColumns(\App\Models\Template\TemplateItem|int $templateItem, bool $pluck = true);

    public function getReportColumns(\App\Models\Template\TemplateItem|int $templateItem);

    public function getReportData(int|string $reportId, int|string $itemId);

    public function getFactorTable(int|string $itemId);

    public function updateReportData(int|string $reportId, int|string $itemId, array $rows);
}
