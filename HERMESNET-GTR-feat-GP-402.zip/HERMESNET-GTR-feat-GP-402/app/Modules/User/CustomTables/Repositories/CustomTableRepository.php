<?php

namespace App\Modules\User\CustomTables\Repositories;

use App\Models\Template\TemplateItem;
use App\Modules\Admin\Factors\Entities\Enums\FactorFieldRole;
use App\Modules\Admin\Factors\Models\AdmFactorFieldModel;
use App\Modules\Admin\Factors\Repositories\AdmFactorsRepositoryInterface;
use App\Modules\Core\CustomTables\Repositories\CustomTableAnalyticsRepositoryInterface;
use App\Modules\Core\Database\AnalyticsSchema;
use App\Modules\Core\Database\DBConnections;
use App\Modules\Core\Entities\Enums\TemplateItemType;
use App\Utils\ResponseUtil;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

final readonly class CustomTableRepository implements CustomTableRepositoryInterface
{
    public function __construct(
        private CustomTableAnalyticsRepositoryInterface $customTableAnalyticsRepository,
        private AdmFactorsRepositoryInterface $factorsRepository,
    )
    {

    }

    protected function isRowValid(TemplateItem|int $templateItem, array $row): bool
    {
        if( is_int($templateItem) ){
            $templateItem = TemplateItem::find($templateItem);
            if( !$templateItem ){
                \Log::error('Attempted to access NULL template item');
                return false;
            }

            if( $templateItem->content_type!=TemplateItemType::customTable->value ){
                \Log::error('Attempted to access non-custom table template item');
                return false;
            }
        }

        $fields = array_keys(array_filter($templateItem->custom_table_meta['fields'], fn($field) => $field['flags']['required']));
        foreach( $fields as $key => $value ){
            if (!array_key_exists($value, $row)) {
                return false;
            }

            if (!isset($row[$value])) {
                return false;
            }
        }

        $fields = array_filter(
            $this->getFactorColumns(
                $templateItem, ['system_name', 'role'], false),
                fn($field) => $field['role'] === FactorFieldRole::parameter->value || $field['role'] === FactorFieldRole::factor->value
            );

        foreach( $fields as $field ){
            if (!array_key_exists($field['system_name'], $row)) {
                return false;
            }

            if (!isset($row[$field['system_name']])) {
                return false;
            }
        }

        return true;
    }

    /**
     * Get an array with the values of a given key for factors.
     *
     * @param  \App\Models\Template\TemplateItem  $templateItem
     * @param  string|array $value Keys
     * @return array Values
     */
    public function getFactorColumns(TemplateItem|int $templateItem, string|array $cols = 'system_name', bool $pluck = true): array
    {
        if( is_int($templateItem) ){
            $templateItem = TemplateItem::find($templateItem);
            if( !$templateItem ){
                return [];
            }
        }

        $factorId = $templateItem->custom_table_meta['factor'] ?? null;
        if (!$factorId) {
            return [];
        }

        $fields = AdmFactorFieldModel::where('factor_id', $factorId)
            ->orderBy('position')
            ->get($cols);

        return $pluck ? $fields->pluck($cols)->toArray() : $fields->toArray();
    }

    public function getTemplateItemColumns(TemplateItem|int $templateItem, bool $pluck = true): array
    {
        if( is_int($templateItem) ){
            $templateItem = TemplateItem::find($templateItem);
            if( !$templateItem ){
                return [];
            }
        }

        return $templateItem->custom_table_meta[$pluck ? 'fields_order' : 'fields'];
    }

    public function getReportColumns(TemplateItem|int $templateItem){
        return array_merge(
            array_filter($this->getTemplateItemColumns($templateItem), fn($field) => $field !== 'factor'),
            $this->getFactorColumns($templateItem)
        );
    }

    public function getReportData(string|int $reportId, string|int $itemId)
    {
        $templateItem = TemplateItem::where('id', $itemId)
            ->where('content_type', TemplateItemType::customTable->value)
            ->first();

        if( !$templateItem ){ return ResponseUtil::error('Attempted to fetch report data for non-existing template.'); }
        $customTable = $templateItem->custom_table_meta ?? [];

        $reportData = $this->customTableAnalyticsRepository->fetchRows(
            $customTable['system_name'],
            $reportId,
            $itemId,
            $this->getReportColumns($templateItem)
        );

        return $reportData;
    }

    public function getFactorTable(int|string $itemId)
    {
        $cacheKey = "customTablegetFactorTableValue_$itemId";
        if( Cache::has($cacheKey) ) {
            return Cache::get($cacheKey);
        }

        $templateItem = TemplateItem::find($itemId);
        if( !$templateItem ) {
            return ['error' => 'Template item not found'];
        }

        $factorId = $templateItem->custom_table_meta['factor'] ?? null;

        $result = DB::connection(DBConnections::analytics->value)
            ->table(AnalyticsSchema::emissionFactors->value . '.' . $this->factorsRepository->getFactorSystemName($factorId))
            ->distinct()
            ->get($this->getFactorColumns($templateItem, 'system_name'));

        Cache::put($cacheKey, $result, 300); // 5 minutes
        return $result;
    }

    /**
     * Update report data.
     * 
     * @param int|string $reportId Id of the report
     * @param int|string $itemId Id of the template item
     * @param array $row Row data
     * @return string[]
     */
    public function updateReportData(int|string $reportId, int|string $itemId, array $rows)
    {
        $templateItem = TemplateItem::find($itemId);
        if (!$templateItem) {
            return ['error' => 'Template item not found'];
        }
        $tableName = $templateItem ->custom_table_meta['system_name'] ?? null;
        if (!$tableName) {
            return ['error' => 'Invalid system name'];
        }

        foreach ($rows as $row) {
            $rowId = $row['row_id'];
            $action = $row['action'];
            $row = $row['data'];

            if( $action!='delete' && !$this->isRowValid($templateItem, $row) ){
                return ['error' => 'Invalid row data'];
            }

            switch( $action ){
                case 'insert':
                    $this->customTableAnalyticsRepository
                        ->insertRow($tableName, $reportId, $itemId, $rowId, $row);
                    break;
                case 'set':
                case 'update':
                    $this->customTableAnalyticsRepository
                        ->updateRow($tableName, $reportId, $itemId, $rowId, $row);
                    break;
                case 'remove':
                case 'delete':
                    $this->customTableAnalyticsRepository
                        ->deleteRow($tableName, $reportId, $itemId, $rowId);
                    break;
            }
        }

        return ['success' => 'Data updated'];
    }

    protected function isValidFactorColumn($factorId, $column): bool
    {
        return AdmFactorFieldModel::where('factor_id', $factorId)
            ->where('system_name', $column)
            ->exists();
    }
}
