<?php

namespace App\Modules\User\CustomTables\Http\Controllers;

use App\Modules\User\CustomTables\Export\CustomTableExportToCsv;
use App\Modules\User\CustomTables\Repositories\CustomTableRepositoryInterface;
use App\Modules\User\CustomTables\Utils\CustomTableAccess;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Modules\User\CustomTables\Http\Requests\ReportDataRequest;
use App\Modules\User\CustomTables\Http\Requests\FactorRequest;
use App\Modules\User\CustomTables\Http\Requests\FactorValueRequest;
use App\Modules\User\CustomTables\Http\Requests\UpdateReportDataRequest;
use App\Utils\ResponseUtil;

class CustomTableController extends Controller
{
    protected $customTableRepository;

    public function __construct(CustomTableRepositoryInterface $customTableRepository)
    {
        $this->customTableRepository = $customTableRepository;
    }

    public function data(ReportDataRequest $request)
    {
        $data = $request->validated();

        if (!CustomTableAccess::customTableBelongsToUser($data['report_id'], $data['item_id'])) {
            return ResponseUtil::error(message: 'You do not have permission to access this table', status: 403);
        }

        return response()->json(
            $this->customTableRepository->getReportData($data['report_id'], $data['item_id'])
        );
    }

    public function factor(FactorRequest $request)
    {
        $data = $request->validated();
        

        return response()->json([
            "columns" => $this->customTableRepository->getFactorColumns($data['item_id'], ['system_name', 'name', 'meta', 'role', 'position'], false),
            "table" => $this->customTableRepository->getFactorTable($data['item_id'])
        ]);
    }

    public function updateData(UpdateReportDataRequest $request)
    {
        $data = $request->validated();

        if (!CustomTableAccess::customTableBelongsToUser($data['report_id'], $data['item_id'])) {
            return ResponseUtil::error(message: 'You do not have permission to access this table', status: 403);
        }

        return response()->json(
            $this->customTableRepository->updateReportData($data['report_id'], $data['item_id'], $data['rows'])
        );
    }
}
