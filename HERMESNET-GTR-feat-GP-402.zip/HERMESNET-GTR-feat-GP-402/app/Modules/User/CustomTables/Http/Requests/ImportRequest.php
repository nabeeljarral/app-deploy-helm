<?php

namespace App\Modules\User\CustomTables\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ImportRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'report_id' => 'required|integer',
            'item_id'   => 'required|integer',
            'type'      => 'required|string|in:csv,xlsx',
            'file'      => 'required|file',
        ];
    }
}
