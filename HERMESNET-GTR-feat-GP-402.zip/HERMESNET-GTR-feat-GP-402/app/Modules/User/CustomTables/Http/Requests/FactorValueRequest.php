<?php

namespace App\Modules\User\CustomTables\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class FactorValueRequest extends FormRequest
{
    public function authorize()
    {
        return true; // Adjust authorization as needed
    }

    public function rules()
    {
        return [
            'item_id'      => 'required|integer',
            'parent_chain' => 'nullable|string',
            'column'       => 'required|string',
        ];
    }
}
