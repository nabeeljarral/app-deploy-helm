<?php

namespace App\Modules\User\CustomTables\Export;

use App\Models\Dashboard\Dashboard;
use App\Models\Template\TemplateItem;
use App\Modules\Core\Export\ExportResult;
use App\Modules\User\CustomTables\Repositories\CustomTableRepositoryInterface;
use Illuminate\Support\Facades\Storage;

class CustomTableExportToCsv
{
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(
        protected string|int $reportId,
        protected string|int $itemId
    )
    {
        //
    }

    public function handle(CustomTableRepositoryInterface $customTableRepository): ?ExportResult
    {
        $reportData = $customTableRepository->getReportData($this->reportId, $this->itemId);

        if (empty($reportData)) {
            return null;
        }

        $reportName = Dashboard::find($this->reportId)->name;
        $itemName = TemplateItem::find($this->itemId)->name;
        $dir = "reports/items/exports/";
        $name = "$reportName - $itemName - " . now()->toDateString() . ".csv";
        $fileName = $dir . $name;

        $path = Storage::path($fileName);
        //Create file
        Storage::put($fileName, '');
        try {
            $file = fopen($path, "w");

            $columns = array_keys((array) $reportData[0]);

            fputcsv($file, $columns);

            foreach ($reportData as $row) {
                fputcsv($file, (array) $row);
            }

            fclose($file);

        } catch (\Exception $exception) {
            unlink($path);
            throw $exception;
        }

        return new ExportResult(
            $path,
            $name,
            'text/csv',
        );
    }
}
