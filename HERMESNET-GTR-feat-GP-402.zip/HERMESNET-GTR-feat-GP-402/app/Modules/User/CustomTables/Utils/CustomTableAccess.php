<?php

namespace App\Modules\User\CustomTables\Utils;

use App\Models\Dashboard\Dashboard;
use Illuminate\Support\Facades\Auth;

class CustomTableAccess
{
    public static function customTableBelongsToUser($reportId, $itemId): bool
    {
        $user = Auth::user();
        if (!$user || !$user->organization_id) {
            return false;
        }

        $dashboard = Dashboard::find($reportId);
        if (!$dashboard || !$dashboard->environment) {
            return false;
        }

        $organization = $dashboard->environment->organization;
        if (!$organization || $organization->user_id !== $user->id) {
            return false;
        }

        return true;
    }
}