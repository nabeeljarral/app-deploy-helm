<?php

namespace App\Modules\User\ReportItems\Repositories;

use App\Models\Dashboard\Dashboard;
use App\Utils\DateTimeUtil;

final class ReportsSimpleRepository
{
    const REPORT_MODEL = Dashboard::class;

    public function setUpdatedAt(int $reportId): void
    {
        self::REPORT_MODEL::query()
            ->where('id', $reportId)
            ->update(['updated_at' => DateTimeUtil::now()]);
    }
}
