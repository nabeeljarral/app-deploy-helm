<?php

namespace App\Modules\User\ReportItems\Observers;

use App\Models\ConfigurationItem;
use App\Modules\User\ReportItems\Repositories\ReportsSimpleRepository;

/**
 *
 */
class ReportItemsObserver
{
    private ?ReportsSimpleRepository $reportsSimpleRepository;

    public function __construct(ReportsSimpleRepository $reportsSimpleRepository)
    {
        $this->reportsSimpleRepository = $reportsSimpleRepository;
    }

    public function updated(ConfigurationItem $configurationItem): void
    {
        if($configurationItem->isDirty('content') ) {
            $this->reportsSimpleRepository->setUpdatedAt($configurationItem->report_id);
        }
    }
}
