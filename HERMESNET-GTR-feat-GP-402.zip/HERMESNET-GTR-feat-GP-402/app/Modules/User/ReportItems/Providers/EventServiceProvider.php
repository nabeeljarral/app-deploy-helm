<?php

namespace App\Modules\User\ReportItems\Providers;

use App\Models\ConfigurationItem;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use App\Modules\User\ReportItems\Observers\ReportItemsObserver;

/**
 *
 */
class EventServiceProvider extends ServiceProvider
{

    /**
     * Register any events for your application.
     *
     * @return void
     */
    public function boot()
    {
        $this->observers();
    }

    /**
     * @return void
     */
    public function observers(): void
    {
        ConfigurationItem::observe(ReportItemsObserver::class);
    }
}
