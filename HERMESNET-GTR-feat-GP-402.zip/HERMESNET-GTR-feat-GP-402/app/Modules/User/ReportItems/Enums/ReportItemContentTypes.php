<?php

namespace App\Modules\User\ReportItems\Enums;

enum ReportItemContentTypes: int
{
    case richText = 0;
    case googleSheet = 1;
    case customTable = 2;
}
