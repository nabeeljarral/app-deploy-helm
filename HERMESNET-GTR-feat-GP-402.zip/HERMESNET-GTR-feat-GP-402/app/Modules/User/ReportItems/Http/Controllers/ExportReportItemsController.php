<?php
namespace App\Modules\User\ReportItems\Http\Controllers;

use App\Models\Template\TemplateItem;
use App\Models\Views\ConfigurationItemsView;
use App\Modules\User\CustomTables\Export\CustomTableExportToCsv ;
use App\Modules\User\CustomTables\Repositories\CustomTableRepositoryInterface;
use App\Modules\User\ReportItems\Enums\ReportItemContentTypes;
use Illuminate\Http\JsonResponse;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Storage;

class ExportReportItemsController extends Controller
{
    public function __construct(
        private CustomTableRepositoryInterface $customTableRepository,
    )
    {
    }

    public function exportToCsv(
        string|int $reportId,
        string|int $itemId,
    )
    {
        $item = TemplateItem::query()->find($itemId);

        if ($item->content_type === ReportItemContentTypes::customTable->value) {
            $handler = (new CustomTableExportToCsv($reportId, $itemId));

            $result = $handler->handle($this->customTableRepository);
        } else {
            throw new \Exception('Unsupported content type of item');
        }

        if ($result == null) {
            return [];
        }

        return response()
            ->file(
                $result->path,
                [
                    'Content-type' => $result->type,
                    'X-File-Name' => $result->name,
                ]
            );
    }
}
