<?php

namespace App\Modules\Admin\Factors\Repositories;

use App\Modules\Admin\Factors\Models\AdmFactorFieldModel;

final readonly class SQLAdmFactorFieldsRepository implements AdmFactorFieldsRepositoryInterface
{
    public function getFactorFields(int|string $factorId, string|array $columns=null): array
    {
        return AdmFactorFieldModel::query()
            ->selectGeneralData()
            ->where('factor_id', $factorId)
            ->orderBy('position')
            ->get($columns??'*')
            ->toArray();
    }

    public function getFactorFieldsSystemNames(int|string $factorId): array
    {
        return AdmFactorFieldModel::query()
            ->where('factor_id', $factorId)
            ->orderBy('position')
            ->pluck('system_name')
            ->toArray();
    }

    public function updateFactorFields(int|string $factorId, array $fields): void
    {
        foreach ($fields as $key => $field) {
            $fields[$key]['factor_id'] = $factorId;
            $fields[$key]['meta'] = json_encode($field['meta']);
        }

        AdmFactorFieldModel::query()
            ->upsert(
                $fields,
                ['id'],
                ['name', 'position', 'system_name', 'meta']
            );
    }

    public function updateFactorFieldById(int|string $fieldId, array $values): void
    {
        AdmFactorFieldModel::query()
            ->where('id', $fieldId)
            ->update($values);
    }

}
