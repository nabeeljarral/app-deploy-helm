<?php

namespace App\Modules\Admin\Factors\Repositories;

use Illuminate\Http\UploadedFile;

interface AdmFactorImportsRepositoryInterface
{
    public function saveFactorValuesCsv(int|string $factorId, UploadedFile $file): string;
}
