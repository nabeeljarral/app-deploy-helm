<?php

namespace App\Modules\Admin\Factors\Repositories;

use App\Modules\Core\Pagination\SimplePaginationDTO;


interface AdmFactorsRepositoryInterface
{
    public function getFactors(SimplePaginationDTO $simplePagination): array;

    public function countFactors(): int;

    public function getFactorGeneralData(int|string $factorId): array;

    public function getFactorSystemName(int|string $factorId): ?string;

    public function createFactorGeneralData(
        string $name,
        string $systemName,
    ): int;

    public function updateFactorGeneralData(int|string $factorId, string $name, string $systemName,): void;
}
