<?php

namespace App\Modules\Admin\Factors\Repositories;

use App\Modules\Admin\Factors\Models\AdmFactorValueModel;
use App\Modules\Core\Database\AnalyticsSchema;
use App\Modules\Core\Database\DBService;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

final readonly class PostgresAdmFactorValuesRepository implements AdmFactorValuesRepositoryInterface
{
    private function openConnection(): void
    {
        DBService::setConnectionToAnalyticsDB();
        DBService::setAnalyticsSchema(AnalyticsSchema::emissionFactors);
    }

    private function closeConnection(): void
    {
        DBService::setConnectionToAppDB();
    }

    public function list(string $factorSystemName, array $fields = ['*']): array
    {
        $this->openConnection();

        $fields[] = 'id';

        $values = DB::table($factorSystemName)
            ->select($fields)
            ->orderBy('id')
            ->get()
            ->toArray();

        $this->closeConnection();

        return $values;
    }

    public function massUpdate(string $factorSystemName, array $rows): void
    {
        $this->openConnection();

        $now = now()->toDateTimeString();

        foreach ($rows as $row) {
            $row['updated_at'] = $now;
            if (key_exists('id', $row) && ! empty($row['id'])) {
                DB::table($factorSystemName)
                    ->where('id', $row['id'])
                    ->update(Arr::except($row, ['id']));
            } else {
                $row['created_at'] = $now;
                DB::table($factorSystemName)->insert($row);
            }
        }

        $this->closeConnection();
    }

    public function insertRow(string $factorSystemName, array $row): void
    {
        $this->openConnection();

        $row['created_at'] = $row['updated_at'] = now()->toDateTimeString();
        DB::table($factorSystemName)->insert($row);

        $this->closeConnection();
    }

    public function updateRow(string $factorSystemName, string|int $rowId, array $row): void
    {
        $this->openConnection();

        $row['updated_at'] = now()->toDateTimeString();
        DB::table($factorSystemName)
            ->where('id', $rowId)
            ->update($row);

        $this->closeConnection();
    }

    public function existsByRowId(string $factorSystemName, int|string $rowId): bool
    {
        $this->openConnection();

        $exists = DB::table($factorSystemName)
            ->where('id', $rowId)
            ->exists();

        $this->closeConnection();

        return $exists;
    }
}
