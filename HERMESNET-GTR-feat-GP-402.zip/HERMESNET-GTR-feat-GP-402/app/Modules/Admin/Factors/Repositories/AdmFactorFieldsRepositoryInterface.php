<?php

namespace App\Modules\Admin\Factors\Repositories;

interface AdmFactorFieldsRepositoryInterface
{
    public function getFactorFields(int|string $factorId, string|array $columns = null): array;

    public function getFactorFieldsSystemNames(int|string $factorId): array;

    public function updateFactorFields(int|string $factorId, array $fields): void;

    public function updateFactorFieldById(int|string $fieldId, array $values): void;

}
