<?php

namespace App\Modules\Admin\Factors\Repositories;


use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;

final readonly class FileSystemAdmFactorImportsRepository implements AdmFactorImportsRepositoryInterface
{
    public function saveFactorValuesCsv(int|string $factorId, UploadedFile $file): string
    {
        $fileName = $factorId . '_' . time() . '.csv';
        return Storage::path($file->storeAs('admin/factors', $fileName));
    }
}
