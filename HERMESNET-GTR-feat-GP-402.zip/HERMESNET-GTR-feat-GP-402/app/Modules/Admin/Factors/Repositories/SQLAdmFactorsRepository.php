<?php

namespace App\Modules\Admin\Factors\Repositories;

use App\Modules\Admin\Factors\Models\AdmFactorModel;
use App\Modules\Core\Pagination\SimplePaginationDTO;


final readonly class SQLAdmFactorsRepository implements AdmFactorsRepositoryInterface
{
    public function getFactors(SimplePaginationDTO $simplePagination): array
    {
       return AdmFactorModel::selectGeneralData()
           ->simplePagination($simplePagination)
           ->get()
           ->toArray();
    }

    public function countFactors(): int
    {
        return AdmFactorModel::query()->count(['id']);
    }

    public function getFactorGeneralData(int|string $factorId): array
    {
        return AdmFactorModel::selectGeneralData()->find($factorId)?->toArray() ?? [];
    }

    public function getFactorSystemName(int|string $factorId): ?string
    {
        return AdmFactorModel::query()
            ->where('id', $factorId)
            ->value('system_name') ?? null;
    }

    public function createFactorGeneralData(string $name, string $systemName): int
    {
        $factorModel = AdmFactorModel::query()->create([
            'name' => $name,
            'system_name' => $systemName,
        ]);

        return $factorModel->id;
    }

    public function updateFactorGeneralData(
        int|string $factorId,
        string $name,
        string $systemName,
    ): void
    {
        AdmFactorModel::query()
            ->where('id', $factorId)
            ->update([
                'name' => $name,
                'system_name' => $systemName,
            ]);
    }
}
