<?php

namespace App\Modules\Admin\Factors\Repositories;

use App\Modules\Core\Pagination\SimplePaginationDTO;


interface AdmFactorValuesRepositoryInterface
{
    public function list(string $factorSystemName, array $fields = ['*']): array;

    public function massUpdate(string $factorSystemName, array $rows): void;

    public function insertRow(string $factorSystemName, array $row): void;

    public function updateRow(string $factorSystemName, string|int $rowId, array $row): void;

    public function existsByRowId(string $factorSystemName, string|int $rowId): bool;
}
