<?php
namespace App\Modules\Admin\Factors\Providers;

use App\Modules\Admin\Factors\Repositories\AdmFactorFieldsRepositoryInterface;
use App\Modules\Admin\Factors\Repositories\AdmFactorImportsRepositoryInterface;
use App\Modules\Admin\Factors\Repositories\AdmFactorsRepositoryInterface;
use App\Modules\Admin\Factors\Repositories\AdmFactorValuesRepositoryInterface;
use App\Modules\Admin\Factors\Repositories\FileSystemAdmFactorImportsRepository;
use App\Modules\Admin\Factors\Repositories\PostgresAdmFactorValuesRepository;
use App\Modules\Admin\Factors\Repositories\SQLAdmFactorFieldsRepository;
use App\Modules\Admin\Factors\Repositories\SQLAdmFactorsRepository;
use App\Modules\Admin\Factors\Repositories\SQLAdmFactorValuesRepository;
use Illuminate\Support\ServiceProvider;

class AdmFactorsServiceProvider extends ServiceProvider
{
    public function boot()
    {

    }

    public function register(): void
    {
        $this->app->singleton(AdmFactorsRepositoryInterface::class, SQLAdmFactorsRepository::class);
        $this->app->singleton(AdmFactorFieldsRepositoryInterface::class, SQLAdmFactorFieldsRepository::class);
        $this->app->singleton(AdmFactorValuesRepositoryInterface::class, PostgresAdmFactorValuesRepository::class);
        $this->app->singleton(AdmFactorImportsRepositoryInterface::class, FileSystemAdmFactorImportsRepository::class);
    }
}
