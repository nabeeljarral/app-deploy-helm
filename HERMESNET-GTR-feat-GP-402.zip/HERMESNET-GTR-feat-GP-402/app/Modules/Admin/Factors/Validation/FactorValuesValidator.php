<?php

namespace App\Modules\Admin\Factors\Validation;

use App\Modules\Admin\Factors\Entities\Enums\FactorFieldRole;
use App\Modules\Admin\Factors\Repositories\AdmFactorFieldsRepositoryInterface;
use App\Modules\Admin\Factors\Repositories\AdmFactorsRepositoryInterface;
use App\Modules\Admin\Factors\Repositories\AdmFactorValuesRepositoryInterface;
use App\Modules\Core\Validation\ValidationResult;
use App\Modules\Core\Validation\ValidationStatus;
use App\Modules\Core\Validation\ValidatorInterface;

final readonly class FactorValuesValidator implements ValidatorInterface
{
    public function __construct(
        public string|int $factorId,
        private AdmFactorsRepositoryInterface $factorsRepository,
        private AdmFactorFieldsRepositoryInterface $factorFieldsRepository,
        private AdmFactorValuesRepositoryInterface $factorValuesRepository,
    )
    {
    }

    public function validate(mixed $data): ValidationResult
    {
        $validationResult = new ValidationResult();
        $fields = $this->factorFieldsRepository->getFactorFields($this->factorId);
        $factorSystemName = $this->factorsRepository->getFactorSystemName($this->factorId);
        $preparedFields = [];

        foreach ($fields as $field) {
            $preparedFields[$field['system_name']] = $field;
        }

        $hasErrors = false;

        foreach ($data as $rowIndex => $row) {
            $rowErrors = [];

            foreach ($row as $systemName => $value) {
                if ($systemName === 'id') {
                    if (! $this->factorValuesRepository->existsByRowId($factorSystemName, $value)) {
                        $rowErrors['id'] = 'The row with system_id=' . $value . ' was not found.';
                    }
                    continue;
                }

                if (! array_key_exists($systemName, $preparedFields)) {
                    continue;
                }

                $isEmptyValue = empty($value);

                if (
                    ($preparedFields[$systemName]['meta']['admin_required'] ?? false)
                    && $isEmptyValue
                ) {
                    $rowErrors[$systemName] = 'The field "' . $preparedFields[$systemName]['name'] . '" is required.';
                    continue;
                }

                if (! $isEmptyValue) {
                    if (($preparedFields[$systemName]['role'] === FactorFieldRole::parameter->value || $preparedFields[$systemName]['role'] === FactorFieldRole::supplementary->value)
                        &&  ! is_string($value)
                    ) {
                        $rowErrors[$systemName] = 'The field value "' . $preparedFields[$systemName]['name'] . '" must be a string.';
                    }

                    if ($preparedFields[$systemName]['role'] === FactorFieldRole::factor->value
                        && filter_var($value, FILTER_VALIDATE_FLOAT) === false
                    ) {
                        $rowErrors[$systemName] = 'The field value "' . $preparedFields[$systemName]['name'] . '" must be a float. ' . $value;
                    }
                }
            }

            if (! empty($rowErrors)) {
                $validationResult->data[$rowIndex] = [
                    'row_id' => $row['id'] ?? null,
                    'messages' => $rowErrors,
                ];
                $hasErrors = true;
            }
        }

        if ($hasErrors) {
            $validationResult->status = ValidationStatus::error;
        } else {
            $validationResult->data = [];
        }

        return $validationResult;
    }
}
