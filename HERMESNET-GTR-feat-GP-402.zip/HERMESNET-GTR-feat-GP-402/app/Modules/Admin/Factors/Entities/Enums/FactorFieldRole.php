<?php
namespace App\Modules\Admin\Factors\Entities\Enums;

enum FactorFieldRole: int
{
    case parameter = 1;
    case factor = 2;
    case supplementary = 3;
}
