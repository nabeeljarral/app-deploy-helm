<?php

namespace App\Modules\Admin\Factors\Models;

use App\Modules\Admin\Factors\Entities\Enums\FactorFieldRole;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * @method static Builder|self selectGeneralData()
 */
class AdmFactorFieldModel extends Model
{
    use SoftDeletes;
    const TABLE = "admin_factors_fields";

    /**
     * @var string
     */
    protected $table = "admin_factors_fields";

    public $incrementing = false;
    /**
     * @var string[]
     */
    protected $fillable = [
        'id',
        'factor_id',
        'system_name',
        'name',
        'role',
        'meta',
    ];

    protected $casts = [
        'meta' => 'array',
        'role' => FactorFieldRole::class,
    ];

    public function scopeSelectGeneralData(Builder $builder): void
    {
        $builder->select(['id', 'name', 'system_name', 'position', 'meta', 'role']);
    }
}
