<?php

namespace App\Modules\Admin\Factors\Models;

use App\Modules\Core\Models\Scopes\SimplePaginationScope;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Builder;

/**
 * @method static Builder|self selectGeneralData()
 */
class AdmFactorModel extends Model
{
    use SoftDeletes;
    use SimplePaginationScope;

    const TABLE = "admin_factors";

    /**
     * @var string
     */
    protected $table = "admin_factors";

    /**
     * @var string[]
     */
    protected $fillable = [
        'name',
        'system_name',
        'created_at',
        'updated_at',
        'deleted_at',
    ];


    public function scopeSelectGeneralData(Builder $builder): void
    {
        $builder->select(['name', 'system_name', 'id', 'created_at', 'updated_at']);
    }
}
