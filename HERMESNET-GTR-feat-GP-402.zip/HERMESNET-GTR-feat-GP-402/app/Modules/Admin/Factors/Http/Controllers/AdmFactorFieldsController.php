<?php

namespace App\Modules\Admin\Factors\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Admin\Factors\Http\Requests\CreateFactorGeneralDataRequest;
use App\Modules\Admin\Factors\Http\Requests\UpdateFactorFieldsRequest;
use App\Modules\Admin\Factors\Http\Requests\UpdateFactorGeneralDataRequest;
use App\Modules\Admin\Factors\Jobs\UpdateFactorSchemaJob;
use App\Modules\Admin\Factors\Repositories\AdmFactorFieldsRepositoryInterface;
use App\Modules\Admin\Factors\Repositories\AdmFactorsRepositoryInterface;
use App\Modules\Core\Pagination\SimplePaginationDTO;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;

/**
 *
 */
class AdmFactorFieldsController extends Controller
{
    public function __construct(private AdmFactorFieldsRepositoryInterface $admFactorFieldsRepository)
    {
    }

    public function list(int|string $factorId): JsonResponse|array
    {
        return $this->admFactorFieldsRepository->getFactorFields($factorId);
    }

    public function update(int|string $factorId, UpdateFactorFieldsRequest $request): JsonResponse|array
    {
        $this->admFactorFieldsRepository->updateFactorFields($factorId, $request->fields);
        $this->dispatchSync(new UpdateFactorSchemaJob($factorId));

        return ['factorId' => $factorId];
    }
}
