<?php

namespace App\Modules\Admin\Factors\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Admin\Factors\Http\Requests\CreateFactorGeneralDataRequest;
use App\Modules\Admin\Factors\Http\Requests\UpdateFactorFieldsRequest;
use App\Modules\Admin\Factors\Http\Requests\UpdateFactorGeneralDataRequest;
use App\Modules\Admin\Factors\Repositories\AdmFactorsRepositoryInterface;
use App\Modules\Core\Pagination\SimplePaginationDTO;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 *
 */
class AdmFactorsController extends Controller
{
    public function __construct(private AdmFactorsRepositoryInterface $admFactorsRepository)
    {
    }


    public function list(Request $request): JsonResponse|array
    {
        $pagination = new SimplePaginationDTO($request->page ?? 1, $request->per_page ?? 15);
        $pagination->setCount($this->admFactorsRepository->countFactors());

        return [
            'data' => $this->admFactorsRepository->getFactors($pagination),
            'meta' => $pagination->toArray(),
        ];
    }

    public function create(CreateFactorGeneralDataRequest $request): JsonResponse|array
    {
        $factorId = $this->admFactorsRepository->createFactorGeneralData(
            $request->name,
            $request->system_name,
        );
        return ['factorId' => $factorId,];
    }

    public function getFactorGeneralData(int|string $factorId): JsonResponse|array
    {
        return $this->admFactorsRepository->getFactorGeneralData($factorId);
    }

    public function updateFactorGeneralData(int|string $factorId, UpdateFactorGeneralDataRequest $request): JsonResponse|array
    {
        $this->admFactorsRepository->updateFactorGeneralData($factorId, $request->name, $request->system_name,);

        return ['factorId' => $factorId];
    }
}
