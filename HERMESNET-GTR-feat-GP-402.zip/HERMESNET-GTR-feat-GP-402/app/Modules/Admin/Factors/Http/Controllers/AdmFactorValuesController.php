<?php

namespace App\Modules\Admin\Factors\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Admin\Factors\Http\Requests\CreateFactorGeneralDataRequest;
use App\Modules\Admin\Factors\Http\Requests\ImportFactorValuesRequest;
use App\Modules\Admin\Factors\Http\Requests\UpdateFactorFieldsRequest;
use App\Modules\Admin\Factors\Http\Requests\UpdateFactorGeneralDataRequest;
use App\Modules\Admin\Factors\Http\Requests\UpdateFactorValuesRequest;
use App\Modules\Admin\Factors\Jobs\ImportFactorValuesJob;
use App\Modules\Admin\Factors\Jobs\MassUpdateFactorValuesJob;
use App\Modules\Admin\Factors\Repositories\AdmFactorFieldsRepositoryInterface;
use App\Modules\Admin\Factors\Repositories\AdmFactorImportsRepositoryInterface;
use App\Modules\Admin\Factors\Repositories\AdmFactorsRepositoryInterface;
use App\Modules\Admin\Factors\Repositories\AdmFactorValuesRepositoryInterface;
use App\Modules\Admin\Factors\Validation\FactorValuesValidator;
use App\Modules\Core\Pagination\SimplePaginationDTO;

use App\Modules\Core\Validation\ValidationStatus;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

/**
 *
 */
class AdmFactorValuesController extends Controller
{
    public function __construct(
        private AdmFactorsRepositoryInterface $factorsRepository,
        private AdmFactorValuesRepositoryInterface $admFactorValuesRepository,
        private AdmFactorImportsRepositoryInterface $admFactorImportsRepository,
        private AdmFactorFieldsRepositoryInterface $admFactorFieldsRepository
    )
    {
    }

    public function list(int|string $factorId): JsonResponse|array
    {
        $factorSystemName = $this->factorsRepository->getFactorSystemName($factorId);
        $fields = $this->admFactorFieldsRepository->getFactorFieldsSystemNames($factorId);

        return $this->admFactorValuesRepository->list($factorSystemName, $fields);
    }

    public function massUpdate(int|string $factorId, UpdateFactorValuesRequest $request): JsonResponse|array
    {
        $validator = new FactorValuesValidator(
            $factorId,
            $this->factorsRepository,
            $this->admFactorFieldsRepository,
            $this->admFactorValuesRepository,
        );
        $validationResult = $validator->validate($request->get('values', []));

        if (! $validationResult->isValid()) {
            return new JsonResponse($validationResult->toArray(), 400);
        }

        $factorSystemName = $this->factorsRepository->getFactorSystemName($factorId);
        $this->admFactorValuesRepository->massUpdate($factorSystemName, $request->get('values', []));

        return [];
    }


    public function import(int|string $factorId, ImportFactorValuesRequest $request): JsonResponse|array
    {
        $job = new ImportFactorValuesJob($factorId, $this->admFactorImportsRepository->saveFactorValuesCsv($factorId, $request->file));
        dispatch_sync($job);

        return ['status' => ValidationStatus::success->value];
    }

}
