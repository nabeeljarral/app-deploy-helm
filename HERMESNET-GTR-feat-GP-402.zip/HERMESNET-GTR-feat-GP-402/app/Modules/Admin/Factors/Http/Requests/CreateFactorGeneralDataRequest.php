<?php

namespace App\Modules\Admin\Factors\Http\Requests;

use App\Modules\Admin\Factors\Models\AdmFactorModel;
use Illuminate\Foundation\Http\FormRequest;

class CreateFactorGeneralDataRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'name'  => ['required', 'string'],
            'system_name' => ['required', 'string', 'unique:' . AdmFactorModel::TABLE . ',system_name'],
        ];
    }

    public function authorize(): bool
    {
        return true;
    }
}
