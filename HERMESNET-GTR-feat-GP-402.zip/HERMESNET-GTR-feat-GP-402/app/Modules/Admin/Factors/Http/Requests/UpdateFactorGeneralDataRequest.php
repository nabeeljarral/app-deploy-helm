<?php

namespace App\Modules\Admin\Factors\Http\Requests;

use App\Modules\Admin\Factors\Models\AdmFactorModel;
use Illuminate\Foundation\Http\FormRequest;

class UpdateFactorGeneralDataRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'name'  => ['required', 'string'],
            'system_name'  => ['required', 'string'],
        ];
    }

    public function authorize(): bool
    {
        return true;
    }
}
