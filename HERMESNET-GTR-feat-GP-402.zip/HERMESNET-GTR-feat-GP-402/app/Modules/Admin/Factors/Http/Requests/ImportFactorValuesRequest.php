<?php

namespace App\Modules\Admin\Factors\Http\Requests;

use App\Modules\Admin\Factors\Entities\Enums\FactorFieldRole;
use App\Modules\Admin\Factors\Models\AdmFactorModel;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Enum;

class ImportFactorValuesRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'file' => ['required'],
        ];
    }

    public function authorize(): bool
    {
        return true;
    }
}
