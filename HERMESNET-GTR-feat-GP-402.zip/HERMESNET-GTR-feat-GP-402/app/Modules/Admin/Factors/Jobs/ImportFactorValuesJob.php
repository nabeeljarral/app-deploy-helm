<?php

namespace App\Modules\Admin\Factors\Jobs;

use App\Modules\Admin\Factors\Entities\Enums\FactorFieldRole;
use App\Modules\Admin\Factors\Repositories\AdmFactorFieldsRepositoryInterface;
use App\Modules\Admin\Factors\Repositories\AdmFactorsRepositoryInterface;
use App\Modules\Admin\Factors\Repositories\AdmFactorValuesRepositoryInterface;
use App\Modules\Admin\Factors\Validation\FactorValuesValidator;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Http\JsonResponse;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Arr;
use phpseclib3\Math\BigInteger\Engines\PHP;
use Symfony\Component\Uid\Ulid;

class ImportFactorValuesJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private array $fields = [];

    private AdmFactorFieldsRepositoryInterface $factorFieldsRepository;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(
        private int|string $factorId,
        private string $path,
    )
    {
        //
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle(
        AdmFactorValuesRepositoryInterface $factorValuesRepository,
        AdmFactorFieldsRepositoryInterface $factorFieldsRepository,
        AdmFactorsRepositoryInterface $factorsRepository,
    )
    {
        $this->factorFieldsRepository = $factorFieldsRepository;

        try {
            $headersRead = false;
            $systemIdIndex = false;
            $systemDeleteIndex = false;

            $factorSystemName = $factorsRepository->getFactorSystemName($this->factorId);

            $this->fields = $factorFieldsRepository->getFactorFields($this->factorId);

            $csvFile = fopen($this->path, "r+");

            $preparedRows = [];

            if ($csvFile !== false) {
                while (($row = fgetcsv($csvFile)) !== false) {
                    $preparedValues = [];

                    if (! $headersRead) {
                        $headersRead = true;
                        foreach ($row as $key => $header) {
                            if ($header === 'system_id') {
                                $systemIdIndex = $key;
                                continue;
                            }
                            if ($header === 'system_delete') {
                                $systemDeleteIndex = $key;
                                continue;
                            }
                        }
                        $this->loadFields($row);
                        continue;
                    }

                    foreach ($row as $index => $value) {
                        if ( $index === $systemIdIndex) {
                            if(! empty($value)) {
                                $preparedValues['id'] = $value;
                            }
                            continue;
                        }

                        if ($index === $systemDeleteIndex) {
                            continue;
                        }

                        if (key_exists($index, $this->fields)) {
                            $filedRole = $this->fields[$index]['role'];
                            if ($filedRole === FactorFieldRole::parameter->value) {
                                $value = empty($value) ? '-' : $value;
                            } elseif ($filedRole === FactorFieldRole::factor->value) {
                                $value = empty($value) ? null : str_replace(',', '.', $value);
                            }

                            $preparedValues[$this->fields[$index]['system_name']] = $value;
                        }
                    }

                    $preparedRows[] = $preparedValues;
                }

                fclose($csvFile);
            }

            $validator = new FactorValuesValidator(
                $this->factorId,
                $factorsRepository,
                $factorFieldsRepository,
                $factorValuesRepository,
            );

            $validationResult = $validator->validate($preparedRows);

            if (! $validationResult->isValid()) {
                $errorMessage = 'There are errors in some rows: ' . PHP_EOL;
                foreach($validationResult->data as $rowIndex => $error) {
                    $errorMessage .= "#$rowIndex: " . implode('|', $error['messages']) . PHP_EOL;
                }

                throw new \Exception($errorMessage);
            }

            $factorValuesRepository->massUpdate($factorSystemName, $preparedRows);
        } finally {
           unlink($this->path);
        }
    }

    private function loadFields(array $headers): void
    {
        $filteredFields = [];
        $this->fields = $this->factorFieldsRepository->getFactorFields($this->factorId);

        foreach ($headers as $index => $header) {
            $search = $this->searchFieldBySystemName($header);

            if (! empty($search)) {
                $filteredFields[$index] = $search;
            }
        }

        $this->fields = $filteredFields;
    }

    private function searchFieldBySystemName(string $systemName): array
    {
        foreach ($this->fields as $field) {
            if ($field['system_name'] === $systemName) {
                return $field;
            }
        }

        return [];
    }
}
