<?php

namespace App\Modules\Admin\Factors\Jobs;

use App\Modules\Admin\Factors\Repositories\AdmFactorFieldsRepositoryInterface;
use App\Modules\Admin\Factors\Repositories\AdmFactorsRepositoryInterface;
use App\Modules\Admin\Factors\Repositories\AdmFactorValuesRepositoryInterface;
use App\Modules\Core\Database\AnalyticsSchema;
use App\Modules\Core\Database\DBConnections;
use App\Modules\Core\Database\DBService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Symfony\Component\Uid\Ulid;

class UpdateFactorSchemaJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private AdmFactorFieldsRepositoryInterface $factorFieldsRepository;

    private AdmFactorsRepositoryInterface $factorsRepository;

    private array $preparedFieldsUpdate = [];
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(private int|string $factorId,)
    {
        //
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle(
        AdmFactorsRepositoryInterface $factorsRepository,
        AdmFactorFieldsRepositoryInterface $factorFieldsRepository,)
    {
        $this->factorFieldsRepository = $factorFieldsRepository;
        $this->factorsRepository = $factorsRepository;

        $factor = $this->factorsRepository->getFactorGeneralData($this->factorId);
        $fields = $this->factorFieldsRepository->getFactorFields($this->factorId);

        DBService::setConnectionToAnalyticsDB();
        DBService::setAnalyticsSchema(AnalyticsSchema::emissionFactors);

        $tableName = $factor['system_name'];

        if ( !Schema::hasTable($tableName)) {
            Schema::create($tableName, function (Blueprint $table) use ($factor, $fields) {
                $table->id();
                $table->timestamps();
                $table->softDeletes();
            });
        }

        Schema::table($tableName, function (Blueprint $table) use ($tableName, $fields) {
            foreach ($fields as $field) {
                $savedSystemName = $field['meta']['saved_system_name'] ?? null;
                $systemName = $field['system_name'];
                $hasSystemName = Schema::hasColumn($tableName, $systemName);
                if (empty($savedSystemName)) {
                    if (! $hasSystemName) {
                        $table->string($field['system_name'])->nullable();
                    }
                } else {
                    $hasSavesSystemName = Schema::hasColumn($tableName, $savedSystemName);

                    if ($hasSavesSystemName && $savedSystemName != $systemName) {
                        $table->renameColumn($savedSystemName, $systemName);
                    } else if (! $hasSystemName) {
                        $table->string($systemName)->nullable();
                    }
                }

                if ($savedSystemName != $systemName) {
                    DBService::setConnectionToAppDB();
                    $this->factorFieldsRepository
                        ->updateFactorFieldById(
                            $field['id'],
                            ['meta->saved_system_name' => $field['system_name']]
                        );
                    DBService::setConnectionToAnalyticsDB();
                }
            }
        });


        DBService::setConnectionToAppDB();

    }
}
