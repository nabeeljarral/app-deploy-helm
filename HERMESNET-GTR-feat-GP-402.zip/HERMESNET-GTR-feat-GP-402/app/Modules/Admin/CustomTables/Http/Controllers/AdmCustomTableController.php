<?php

namespace App\Modules\Admin\CustomTables\Http\Controllers;

use App\Modules\Admin\Factors\Models\AdmFactorModel;
use Cache;

class AdmCustomTableController
{
    /**
     * Returns all available for custom table factors. Their name(for display) and id(for internal use).
     * @return mixed
     */
    public function fetchFactorNames()
    {
        if(Cache::has('AdmAllFactorNames')) {
            return Cache::get('AdmAllFactorNames');
        }

        $factorNames = AdmFactorModel::query()
            ->select('id', 'name')
            ->get()
            ->toArray();

        Cache::put('AdmAllFactorNames', $factorNames, 60);

        return response()->json($factorNames);
    }
}