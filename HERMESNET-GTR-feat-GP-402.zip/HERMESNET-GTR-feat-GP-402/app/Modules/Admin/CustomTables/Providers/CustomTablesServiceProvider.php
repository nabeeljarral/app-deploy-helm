<?php

namespace App\Modules\Admin\CustomTables\Providers;

use Illuminate\Support\ServiceProvider;

class CustomTablesServiceProvider extends ServiceProvider
{
    public function boot()
    {

    }

    public function register(): void
    {
        //
    }
}
