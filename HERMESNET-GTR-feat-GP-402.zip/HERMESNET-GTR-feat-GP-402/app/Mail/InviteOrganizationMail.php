<?php

namespace App\Mail;

use App\Models\InvitedOrganization;
use App\Utils\UrlUtil;
use Illuminate\Mail\Mailable;
use Illuminate\Support\Facades\Crypt;

/**
 *
 */
class InviteOrganizationMail extends Mailable
{

    /**
     * @param InvitedOrganization $invitedOrganization
     */
    public function __construct(
        private InvitedOrganization $invitedOrganization
    )
    {

    }

    /**
     * @return InviteOrganizationMail
     */
    public function build()
    {
        $data = [
            'user_name'    => $this->invitedOrganization->user_name,
            'owner_name'   => $this->invitedOrganization->invitationOwner->name,
            'callback_url' => $this->getCallbackUrl()
        ];

        return $this
            ->subject("HERMESNET Invitation")
            ->view('emails.invite-organization', $data);
    }

    /**
     * @return string
     */
    private function getCallbackUrl(): string
    {
        $state = Crypt::encrypt($this->invitedOrganization->email);
        return UrlUtil::of(config("app.url"))
            ->join("/auth/registration")
            ->setQueryPrams([
                'state' => $state
            ])
            ->getValue();
    }
}
