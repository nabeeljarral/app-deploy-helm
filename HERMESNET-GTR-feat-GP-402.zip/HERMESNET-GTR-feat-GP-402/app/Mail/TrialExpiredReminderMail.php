<?php

namespace App\Mail;

use App\Models\Organization;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

/**
 *
 */
class TrialExpiredReminderMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * @param string $recipient_name
     * @param int $daysLeft
     */
    public function __construct(
        protected string $recipient_name,
        protected int    $daysLeft
    )
    {

    }

    /**
     * @return TrialExpiredReminderMail
     */
    public function build()
    {
        $view = ($this->daysLeft > 0)
            ? 'emails.trial-expired-reminder'
            : 'emails.trial-is-over-reminder';

        $daysLeft = $this->daysLeft . ' ' . \Str::plural('day', $this->daysLeft);

        return $this
            ->subject("HERMESNET. Reminder Trial Period Ends")
            ->view($view, [
                'recipient_name' => $this->recipient_name,
                'days_left'      => $daysLeft,
                'upgrade_url'    => config('app.url') . '/upgrade',
            ]);
    }
}
