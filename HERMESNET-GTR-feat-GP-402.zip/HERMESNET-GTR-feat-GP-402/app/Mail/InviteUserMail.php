<?php

namespace App\Mail;

use App\Models\User;
use App\Services\User\DTO\InviteUserDto;
use Illuminate\Mail\Mailable;

/**
 *
 */
class InviteUserMail extends Mailable
{

    /**
     * @param InviteUserDto $inviteUserDto
     * @param User|null $currentUser
     */
    public function __construct(
        private InviteUserDto $inviteUserDto,
        private ?User $currentUser = null
    )
    {

    }

    /**
     * @return InviteUserMail
     */
    public function build()
    {
        $data = $this->inviteUserDto->toArray();
        $data['currentUser'] = $this->currentUser ?? \Auth::user();

        return $this
            ->subject("HERMESNET Invitation")
            ->view('emails.invite-user', $data);
    }
}
