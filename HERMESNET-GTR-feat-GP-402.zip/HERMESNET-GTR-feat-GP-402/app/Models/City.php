<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 *
 */
class City extends Model
{
    /**
     * @var string
     */
    protected $table = "meta_cities";

    /**
     * @var string[]
     */
    protected $fillable = [
        'city',
        'country',
        'country_code',
    ];
}
