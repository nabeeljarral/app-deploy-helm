<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PrintConfParameter extends Model
{
    use HasFactory;

    protected $table = "print_configuration_parameters";

    protected $fillable = [
        'name',
        'title',
        'default_value',
        'value',
        'guidance',
        'type',
        'is_mandatory',
        'identity',
        'print_conf_enum_id',
        'print_conf_element_id',
        'link_source'
    ];

    public function element()
    {
        return $this->belongsTo(PrintConfElement::class);
    }

    public function template()
    {
        return $this->hasOneThrough(PrintConfTemplate::class, PrintConfElement::class);
    }

    public function enum()
    {
        return $this->belongsTo(PrintConfEnum::class, 'print_conf_enum_id', 'id');
    }
}
