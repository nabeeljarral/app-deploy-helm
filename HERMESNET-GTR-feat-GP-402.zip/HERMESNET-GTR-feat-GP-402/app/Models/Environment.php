<?php

namespace App\Models;

use App\Models\Dashboard\Dashboard;
use App\Models\Dashboard\DashboardSheetRelations;
use App\Models\Dashboard\DashboardUser;
use App\Models\Template\Template;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use  \Illuminate\Database\Eloquent\Relations\HasMany;

/**
 *
 */
class Environment extends Model
{
    /**
     * @var string
     */
    protected $table = "environments";

    /**
     * @var string[]
     */
    protected $fillable = [
        "organization_id",
        "name",
        "folder_id",
        "color",
        "active",
        "last_sync_gs_at",
        "global_template_id",
        'country',
        'city'
    ];

    /**
     * @var string[]
     */
    protected $dates = [
        "last_sync_gs_at",
    ];

    /**
     * @return HasOne
     */
    public function organization(): HasOne
    {
        return $this->hasOne(Organization::class, 'id', 'organization_id');
    }

    /**
     * @return HasOne
     */
    public function globalTemplate(): HasOne
    {
        return $this->hasOne(Template::class, "id", "global_template_id");
    }

    /**
     * @return HasMany
     */
    public function dashboards(): HasMany
    {
        return $this->hasMany(Dashboard::class, "environment_id", "id");
    }

    /**
     * @return HasMany
     */
    public function dashboardSheetRelations(): HasMany
    {
        return $this->hasMany(DashboardSheetRelations::class, "environment_id", "id");
    }

    /**
     * @return HasMany
     */
    public function dashboardUsers(): HasMany
    {
        return $this->hasMany(DashboardUser::class, "environment_id", "id");
    }
}
