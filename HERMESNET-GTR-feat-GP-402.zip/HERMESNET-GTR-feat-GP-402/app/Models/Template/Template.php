<?php

namespace App\Models\Template;

use App\Models\Dashboard\Dashboard;
use App\Models\Environment;
use App\Models\Organization;
use App\Models\PrintConfTemplate;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use Illuminate\Database\Eloquent\Builder;

/**
 *
 */
class Template extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * @var string
     */
    public $table = 'templates';

    /**
     * @var string[]
     */
    protected $fillable = [
        "name",
        "description",
        "category",
        "type",
        "use_with_any_summary",
        "is_trial",
        "is_public",
        "is_published",
        "is_blank",
        "has_preview",
        "gd_file_id",
        "gd_preview_file_id",
        "hidden_connected_sheet",
        "index_sheet",
        "data_sheet",
        "guidance",
        "allow_aggregation_view",
        "allow_report_structure_definition",
        "is_archived",
        "gtr_sync_config",
    ];

    /**
     * @var string[]
     */
    protected $casts = [
        "is_trial"                          => "boolean",
        "is_public"                         => "boolean",
        "is_published"                      => "boolean",
        "is_blank"                          => "boolean",
        "is_archived"                       => "boolean",
        "use_with_any_summary"              => "boolean",
        "hidden_connected_sheet"            => "boolean",
        "allow_aggregation_view"            => "boolean",
        "allow_report_structure_definition" => "boolean",
        "gtr_sync_config"                   => "array",
    ];

    /**
     * @return HasManyThrough
     */
    public function assignedOrganizations(): HasManyThrough
    {
        return $this->hasManyThrough(
            Organization::class,
            OrgTemplateAccess::class,
            'global_template_id',
            'id',
            'id',
            'organization_id'
        );
    }

    /**
     * @param Builder $query
     * @param string $keyword
     * @return void
     */
    public function scopeSearch(Builder $query, string $keyword): void
    {
        $query->where(function (Builder $query) use ($keyword) {
            $query->orWhere('name', 'like', '%' . $keyword . '%')
                ->orWhere('description', 'like', '%' . $keyword . '%');
        });
    }

    /**
     * @param Builder $query
     * @param Organization $organization
     * @return void
     */
    public function scopeOrganizationTemplates(Builder $query, Organization $organization): void
    {
        $query->where('is_published', true);

        $query->where(function (Builder $query) use ($organization) {
            $query->where('is_public', true)
                ->orWhereHas('assignedOrganizations', function (Builder $query) use ($organization) {
                    $query->where('organization_id', $organization->id);
                });
        });

        if ($organization->is_trial_access) {
            $query->where("is_trial", true);
        }
    }

    /**
     * @return BelongsToMany
     */
    public function relatedSummaries(): BelongsToMany
    {
        return $this->belongsToMany(
            Template::class,
            "template_related_summary",
            'data_collection_id',
            'summary_id',
        );
    }

    /**
     * @return BelongsToMany
     */
    public function relatedDataCollections(): BelongsToMany
    {
        return $this->belongsToMany(
            Template::class,
            "template_related_summary",
            'summary_id',
            'data_collection_id',
        );
    }

    /**
     * @return HasMany
     */
    public function analytics(): HasMany
    {
        return $this->hasMany(TemplateAnalytics::class, "template_id", "id")->orderBy('order_number');
    }

    /**
     * @return HasMany
     */
    public function configurations(): HasMany
    {
        return $this->hasMany(TemplateConfiguration::class, "template_id", "id");
    }

    /**
     * @return HasMany
     */
    public function complianceLevels(): HasMany
    {
        return $this->hasMany(TemplateComplianceLevel::class, "template_id", "id");
    }

    /**
     * @return HasMany
     */
    public function items(): HasMany
    {
        return $this->hasMany(TemplateItem::class, "template_id", "id");
    }

    /**
     * @return HasMany
     */
    public function childItems(): HasMany
    {
        return $this->hasMany(TemplateItem::class, "template_id", 'id')
            ->whereNull('parent_item_id');
    }

    /**
     * @return HasMany
     */
    public function nestedItems(): HasMany
    {
        return $this->hasMany(TemplateItem::class, "template_id", "id")
            ->whereNull('parent_item_id')
            ->with("nestedItems")
            ->orderBy('order_number');
    }


    /**
     * @return HasMany
     */
    public function printConfTemplates(): HasMany
    {
        return $this->hasMany(PrintConfTemplate::class, "template_id", "id")
            ->whereNull('report_id');
    }

    /**
     * @return HasMany
     */
    public function workspaces(): HasMany
    {
        return $this->hasMany(Environment::class, "global_template_id", "id");
    }

    /**
     * @return HasMany
     */
    public function reports(): HasMany
    {
        return $this->hasMany(Dashboard::class, "global_template_id", "id");
    }
}
