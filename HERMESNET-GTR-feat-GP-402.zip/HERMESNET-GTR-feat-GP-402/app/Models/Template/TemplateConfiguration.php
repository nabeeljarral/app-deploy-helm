<?php

namespace App\Models\Template;

use App\Models\ConfigurationItem;
use App\Models\Organization;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

/**
 *
 */
class TemplateConfiguration extends Model
{
    /**
     * @var string
     */
    protected $table = "template_configurations";

    /**
     * @var string[]
     */
    protected $fillable = [
        "template_id",
        "organization_id",
        "name",
        "guidance",
        "is_general",
        "is_published",
    ];

    /**
     * @var string[]
     */
    protected $casts = [
        "is_general" => "boolean",
        "is_published" => "boolean",
    ];

    /**
     * @return HasOne
     */
    public function template(): HasOne
    {
        return $this->hasOne(Template::class, "id", "template_id");
    }

    /**
     * @return HasOne
     */
    public function organization(): HasOne
    {
        return $this->hasOne(Organization::class, "id", "organization_id");
    }

    /**
     * @return HasMany
     */
    public function items(): HasMany
    {
        return $this->hasMany(ConfigurationItem::class, "configuration_id", "id");
    }
}
