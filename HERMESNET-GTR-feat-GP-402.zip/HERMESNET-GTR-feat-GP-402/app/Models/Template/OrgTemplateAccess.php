<?php

namespace App\Models\Template;

use App\Models\Organization;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

/**
 *
 */
class OrgTemplateAccess extends Model
{
    /**
     * @var string
     */
    protected $table = "org_template_access";

    /**
     * @var string[]
     */
    protected $fillable = [
        "organization_id",
        "global_template_id",
    ];

    /**
     * @return HasOne
     */
    protected function organization(): HasOne {
        return  $this->hasOne(Organization::class, "id", "organization_id");
    }

    /**
     * @return HasOne
     */
    public function globalTemplate(): HasOne {
        return $this->hasOne(Template::class, "id", "global_template_id");
    }
}
