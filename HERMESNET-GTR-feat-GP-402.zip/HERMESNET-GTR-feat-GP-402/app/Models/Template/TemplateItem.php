<?php

namespace App\Models\Template;

use App\Modules\Core\Entities\Enums\TemplateItemType;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class TemplateItem extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * @var string
     */
    protected $table = 'template_items';

    /**
     * @var string[]
     */
    protected $fillable = [
        'name',
        'template_id',
        'parent_item_id',
        'mandatory',
        'requirements',
        'recommendations',
        'guidance',
        'content',
        'content_type',
        'custom_table_meta',
        'include_in_printing',
        'sheet_name',
        'sheet_height',
        'order_number',
    ];

    /**
     * @var string[]
     */
    protected $casts = [
        'mandatory' => 'boolean',
        'custom_table_meta' => 'array',
    ];

    public static function canCreateCustomTable($meta): string|null
    {
        if( !isset($meta) ){
            return 'Missing custom table data, please contact support';
        }

        if( !isset($meta['system_name']) || $meta['system_name']=='' ){ return 'Please specify a system name'; }
        if( !isset($meta['fields']) ){ return 'No fields and/or factor field is set'; }
        if( !isset($meta['factor']) ){ return 'Please select a factor'; }
        if( !isset($meta['fields_order']) ){ return 'Fields order is corrupt. Please try again later, or contact support.'; }

        $factorFields = [];
        foreach(\App\Modules\Admin\Factors\Models\AdmFactorFieldModel::where('factor_id', $meta['factor'])
            ->orderBy('position')->get($cols??['system_name'])
            ->toArray() as $field)
        {
            $factorFields[$field['system_name']] = true;
        }
        $factorFields['row_id'] = true;
        $factorFields['item_id'] = true;
        $factorFields['report_id'] = true;

        $lookup = [];

        foreach($meta['fields'] as $fieldSysName => $field)
        {
            if( !isset($field['type']) ){ return "Field '$fieldSysName' is corrupted (No type passed). Please try again, or contact support."; }
            if( isset($lookup[$fieldSysName]) ){ return "Can't have few fields with the same system name!\nDuplicated system name: '$fieldSysName'"; }
            if( isset($factorFields[$fieldSysName]) ){ return "Can't have field with the same system name as factor field!\nDuplicated system name: '$fieldSysName'"; }
            $lookup[$fieldSysName] = $field['type'];
        }

        return count( DB::connection('db2')->select(
            'SELECT * FROM information_schema.tables WHERE table_schema = \'report_data\' AND table_name = \''. $meta['system_name'] .'\''
            )) > 0 ? 'Table with the same system name already exists' : null;
    }

    /**
     * @return HasOne
     */
    public function template(): HasOne
    {
        return $this->hasOne(Template::class, 'id', 'template_id');
    }

    /**
     * @return HasOne
     */
    public function parentItem(): HasOne
    {
        return $this->hasOne(TemplateItem::class, 'id', 'parent_item_id');
    }

    /**
     * @return HasMany
     */
    public function siblingItems(): HasMany
    {
        return $this->hasMany(TemplateItem::class, 'parent_item_id', 'parent_item_id');
    }

    /**
     * @return HasMany
     */
    public function childItems(): HasMany
    {
        return $this->hasMany(TemplateItem::class, 'parent_item_id', 'id');
    }

    /**
     * @return HasMany
     */
    public function nestedItems(): HasMany
    {
        return $this->hasMany(TemplateItem::class, 'parent_item_id', 'id')
            ->with('nestedItems')
            ->orderBy('order_number');
    }

    public static function boot()
    {
        parent::boot();

        $customTableRepository = app( \App\Modules\Core\CustomTables\Repositories\CustomTableAnalyticsRepositoryInterface::class);

        self::creating(function (TemplateItem $model) use ($customTableRepository) {
            if ($model->order_number) {
                $model->siblingItems()
                    ->where('order_number', '>=', $model->order_number)
                    ->increment('order_number');
            }

            if ($model->content_type == 2) {
                $customTableRepository->createCustomTable($model->custom_table_meta);
            }
        });

        self::updating(function (TemplateItem $model) use ($customTableRepository) {
            if ($model->order_number && $model->order_number != $model->getOriginal('order_number')) {
                if ($model->order_number > $model->getOriginal('order_number')) {
                    $model->siblingItems()
                        ->where('order_number', '>', $model->getOriginal('order_number'))
                        ->where('order_number', '<=', $model->order_number)
                        ->decrement('order_number');
                } else {
                    $model->siblingItems()
                        ->where('order_number', '>=', $model->order_number)
                        ->where('order_number', '<', $model->getOriginal('order_number'))
                        ->increment('order_number');
                }
            }

            if ($model->content_type == TemplateItemType::customTable->value) {
                $customTableRepository->updateCustomTable(
                    $model->custom_table_meta,
                    $model->getOriginal('custom_table_meta')
                );
            }
        });

        self::deleting(function (TemplateItem $model) use ($customTableRepository) {
            if ($model->content_type == TemplateItemType::customTable->value) {
                $customTableRepository->deleteCustomTable($model->custom_table_meta['system_name']);
            }

            $model->siblingItems()
                ->where('order_number', '>', $model->order_number)
                ->decrement('order_number');

            $model->childItems()->delete();
        });
    }
}
