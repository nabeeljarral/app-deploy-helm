<?php

namespace App\Models\Template;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

/**
 *
 */
class TemplateComplianceLevel extends Model
{
    /**
     * @var string
     */
    protected $table = "template_compliance_levels";

    /**
     * @var string[]
     */
    protected $fillable = [
        "template_id",
        "name",
        "guidance",
        "icon",
        "is_trial",
        "is_published",
    ];

    /**
     * @return HasOne
     */
    public function template(): HasOne
    {
        return $this->hasOne(Template::class, "id", "template_id");
    }
}
