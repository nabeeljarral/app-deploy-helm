<?php

namespace App\Models\Template;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

/**
 *
 */
class TemplateAnalytics extends Model
{
    /**
     * @var string
     */
    protected $table = "template_analytics";

    /**
     * @var string[]
     */
    protected $fillable = [
        "template_id",
        "name",
        "sheet_name",
        "icon",
        "order_number",
        "looker_embedding_config",
        "looker_embedding_url"
    ];

    /**
     * @var string[]
     */
    protected $casts = [
        "looker_embedding_config" => "array"
    ];

    /**
     * @return HasOne
     */
    public function template(): HasOne
    {
        return $this->hasOne(Template::class, "id", "template_id");
    }
}
