<?php

namespace App\Models\Template;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

/**
 *
 */
class TemplateRelatedSummary extends Model
{
    /**
     * @var string
     */
    protected $table = "template_related_summary";

    /**
     * @var string[]
     */
    protected $fillable = [
        "data_collection_id",
        "summary_id",
    ];

    /**
     * @return HasOne
     */
    public function dataCollection(): HasOne
    {
        return $this->hasOne(Template::class, "id", "data_collection_id");
    }

    /**
     * @return HasOne
     */
    public function summary(): HasOne
    {
        return $this->hasOne(Template::class, "id", "summary_id");
    }
}
