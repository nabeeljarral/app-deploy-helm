<?php

namespace App\Models;

use App\Models\Dashboard\Dashboard;
use App\Models\Template\TemplateConfiguration;
use App\Models\Template\TemplateItem;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

/**
 *
 */
class ConfigurationItem extends Model
{
    /**
     * @var string
     */
    protected $table = "configuration_items";

    /**
     * @var string[]
     */
    protected $fillable = [
        "configuration_id",
        "template_id",
        "report_id",
        "item_id",
        "is_included",
        "reason_of_omission",
        "content"
    ];

    /**
     * @var string[]
     */
    protected $casts = [
        "is_included" => "boolean",
    ];

    /**
     * @return HasOne
     */
    public function configuration(): HasOne
    {
        return $this->hasOne(TemplateConfiguration::class, "id", "configuration_id");
    }

    /**
     * @return HasOne
     */
    public function report(): HasOne
    {
        return $this->hasOne(Dashboard::class, "id", "report_id");
    }

    /**
     * @return HasOne
     */
    public function templateItem(): HasOne
    {
        return $this->hasOne(TemplateItem::class, "id", "item_id");
    }
}
