<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

/**
 *
 */
class InvitedOrganization extends Model
{
    /**
     * @var string
     */
    protected $table = 'invited_organizations';

    /**
     * @var string[]
     */
    protected $fillable = [
        'email',
        'user_name',
        'owner',
    ];

    /**
     * @return HasOne
     */
    public function invitationOwner(): HasOne
    {
        return $this->hasOne(User::class, 'id', 'owner');
    }
}
