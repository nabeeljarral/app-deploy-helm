<?php

namespace App\Models;


use App\Services\User\Enums\UserRole;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Collection;

/**
 *
 */
class Organization extends Model
{
    use HasFactory;

    /**
     * @var string
     */
    public $table = "organizations";

    /**
     * @var string[]
     */
    protected $fillable = [
        "number_of_employees",
        "city",
        "countries",
        "user_id",
        "report_period",
        "drive_folder_id",
        "organization_name",
        "is_trial_access",
        "trial_expired_at",
        'country',
    ];

    /**
     * @var string[]
     */
    protected $casts = [
        "countries"        => "array",
        "is_trial_access"  => "boolean",
        "trial_expired_at" => "datetime",
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function users()
    {
        return $this->hasMany(User::class, 'organization_id', 'id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function environments()
    {
        return $this->hasMany(Environment::class, "organization_id", "id");
    }

    /**
     * @return Collection<User>
     */
    public function getEnvironmentOwners(): Collection
    {
        return $this->users()->where('role', UserRole::ENVIRONMENT_OWNER)->get();
    }

    /**
     * @return bool
     */
    public function trialIsExpired(): bool
    {
        if (!$this->is_trial_access) {
            return false;
        }

        if (!$this->trial_expired_at) {
            return true;
        }

        return $this->trial_expired_at->lt(today());
    }

    /**
     * @param Builder $query
     * @param string $keyword
     * @return void
     */
    public function scopeSearch(Builder $query, string $keyword): void
    {
        $query->where('organization_name', 'like', '%' . $keyword . '%');
    }

    public function printConfigTemplates()
    {
        return $this->belongsToMany(PrintConfTemplate::class);
    }
}
