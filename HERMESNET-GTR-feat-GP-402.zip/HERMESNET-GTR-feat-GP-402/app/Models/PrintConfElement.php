<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PrintConfElement extends Model
{
    use HasFactory;

    protected $table = "print_configuration_elements";

    protected $fillable = [
        'name',
        'title',
        'is_mandatory',
        'is_single',
        'is_default',
        'is_embeddable',
        'is_parent',
        'order_number',
        'print_conf_template_id',
        'print_conf_element_id',
        'embeds',
        'default_embeds'
    ];

    protected $casts = [
        "embeds" => "json",
        "default_embeds" => "json"
    ];

    public function parameters()
    {
        return $this->hasMany(PrintConfParameter::class);
    }

    public function elements()
    {
        return $this->hasMany(PrintConfElement::class)->orderBy('order_number');
    }

    public function template()
    {
        return $this->belongsTo(PrintConfTemplate::class);
    }
}
