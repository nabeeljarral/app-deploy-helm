<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 *
 */
class OrgFolderPermissions extends Model
{
    /**
     * @var string
     */
    protected $table = "org_folder_permissions";

    /**
     * @var string[]
     */
    protected $fillable = [
        "organization_id",
        "user_id",
        "permissions_id",
    ];


    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function organization()
    {
        return $this->hasOne(Organization::class, "id", "organization_id");
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function user()
    {
        return $this->hasOne(User::class, "id", "user_id");
    }
}
