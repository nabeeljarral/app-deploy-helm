<?php

namespace App\Models\Dashboard;

use Illuminate\Database\Eloquent\Model;

/**
 *
 */
class DashboardMethodology extends Model
{
    /**
     * @var string
     */
    protected $table = "dsh_methodology";

    /**
     * @var string[]
     */
    protected $fillable = [
        "dashboard_id",
        "content",
    ];
}
