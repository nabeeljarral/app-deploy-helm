<?php

namespace App\Models\Dashboard;

use App\Models\Environment;
use Illuminate\Database\Eloquent\Model;

/**
 *
 */
class DashboardSheetRelations extends Model
{
    /**
     * @var string
     */
    protected $table = "dashboard_sheet_relations";

    /**
     * @var string[]
     */
    protected $fillable = [
       "environment_id",
       "source_sheet_id",
       "destination_sheet_id",
       "source_range",
       "last_updated_time",
    ];

    /**
     * @var string[]
     */
    protected $dates = [
        "last_updated_time",
    ];

    public function environment() {
        return $this->hasOne(Environment::class, "id", 'environment_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function sourceSheet() {
        return $this->hasOne(DashboardSheet::class, 'id', 'source_sheet_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function destinationSheet() {
        return $this->hasOne(DashboardSheet::class, 'id', 'destination_sheet_id');
    }
}
