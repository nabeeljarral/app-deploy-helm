<?php

namespace App\Models\Dashboard;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

/**
 *
 */
class ReportItemPermissions extends Model
{
    /**
     * @var string
     */
    protected $table = "report_items_permission";

    /**
     * @var string[]
     */
    protected $fillable = [
        'user_id',
        'report_id',
        'items_id',
    ];

    /**
     * @var string[]
     */
    protected $casts = [
        'items_id' => 'array',
    ];

    /**
     * @return HasOne
     */
    public function report() : HasOne {
        return  $this->hasOne(Dashboard::class, 'id', 'report_id');
    }
}
