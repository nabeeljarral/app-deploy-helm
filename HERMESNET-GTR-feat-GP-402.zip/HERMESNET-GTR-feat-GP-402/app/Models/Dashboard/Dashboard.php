<?php

namespace App\Models\Dashboard;

use App\Models\ConfigurationItem;
use App\Models\Environment;
use App\Models\PrintConfTemplate;
use App\Models\Template\Template;
use App\Models\Template\TemplateAnalytics;
use App\Models\Template\TemplateConfiguration;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 *
 */
class Dashboard extends Model
{
    /**
     * @var string
     */
    protected $table = "dashboards";

    /**
     * @var string[]
     */
    protected $fillable = [
        "name",
        "environment_id",
        "template_name",
        "template_id",
        "file_id",
        "type",
        "country",
        "index_sheet",
        "global_template_id",
        "configuration_id",
        "color",
        "status",
        "city",
        "gtr_last_sync_at",
    ];

    /**
     * @var string[]
     */
    protected $casts = [
        'gtr_last_sync_at' => "datetime",
    ];

    /**
     * @return HasOne
     */
    public function globalTemplate(): HasOne
    {
        return $this->hasOne(Template::class, "id", "global_template_id");
    }

    /**
     * @return HasOne
     */
    public function configuration(): HasOne
    {
        return $this->hasOne(TemplateConfiguration::class, "id", "configuration_id");
    }

    /**
     * @return HasOne
     */
    public function environment(): HasOne
    {
        return $this->hasOne(Environment::class, "id", "environment_id");
    }

    /**
     * @return HasMany
     */
    public function sheets(): HasMany
    {
        return $this->hasMany(DashboardSheet::class, "dashboard_id", "id");
    }

    /**
     * @return HasMany
     */
    public function dashboardUsers(): HasMany
    {
        return $this->hasMany(DashboardUser::class, "dashboard_id", "id");
    }

    /**
     * @return HasMany
     */
    public function dashboardProtections(): HasMany
    {
        return $this->hasMany(DashboardProtection::class, "dashboard_id", "id");
    }

    /**
     * @return string|null
     */
    public function getEnvironmentNameAttribute(): ?string
    {
        $environment = $this->environment;
        if ($environment) {
            return $environment->name;
        }
        return null;
    }

    /**
     * @return HasMany
     */
    public function items(): HasMany
    {
        return $this->hasMany(ConfigurationItem::class, "report_id", "id");
    }

    /**
     * @return HasMany
     */
    public function analyticsTabs(): HasMany
    {
        return $this->hasMany(TemplateAnalytics::class, 'template_id', 'global_template_id')->orderBy('order_number');
    }

    /**
     * @return HasMany
     */
    public function printConfTemplates(): HasMany
    {
        return $this->hasMany(PrintConfTemplate::class, "report_id", "id");
    }
}
