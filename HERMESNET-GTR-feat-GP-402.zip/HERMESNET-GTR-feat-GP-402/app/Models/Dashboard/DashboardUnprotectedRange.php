<?php

namespace App\Models\Dashboard;

use App\Utils\LoggerUtil;
use Google\Service\Sheets\GridRange;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 *
 */
class DashboardUnprotectedRange extends Model
{
    use SoftDeletes;

    /**
     * @var string
     */
    protected $table = "dsh_unprotected_range";

    /**
     * @var string[]
     */
    protected $fillable = [
        "dsh_protection_id",
        "start_row_id",
        "end_row_id",
        "start_column_id",
        "end_column_id",
        "need_implement"
    ];

    /**
     * @var string[]
     */
    protected $casts = [
        "need_implement" => "boolean",
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function dashboardProtection()
    {
        return $this->hasOne(DashboardProtection::class, "id", "dsh_protection_id");
    }

    /**
     * @see https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/other#GridRange
     * @return GridRange
     */
    public function getGridRangeEntity(): GridRange
    {
        $start_row_id = $this->start_row_id;
        $end_row_id = $this->end_row_id;
        $start_column_id = $this->start_column_id;
        $end_column_id = $this->end_column_id;


        ++$end_column_id;
        --$start_row_id;

        LoggerUtil::variable([
            "sheetId"          => $this->dashboardProtection->sheet->sheet_id,
            "startRowIndex"    => $start_row_id,
            "endRowIndex"      => $end_row_id,
            "startColumnIndex" => $start_column_id,
            "endColumnIndex"   => $end_column_id,
        ]);

        return new GridRange([
            "sheetId"          => $this->dashboardProtection->sheet->sheet_id,
            "startRowIndex"    => $start_row_id,
            "endRowIndex"      => $end_row_id,
            "startColumnIndex" => $start_column_id,
            "endColumnIndex"   => $end_column_id,
        ]);
    }
}
