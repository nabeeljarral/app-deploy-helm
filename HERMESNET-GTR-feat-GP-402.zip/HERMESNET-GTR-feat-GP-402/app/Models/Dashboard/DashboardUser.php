<?php

namespace App\Models\Dashboard;

use App\Models\Environment;
use App\Models\User;
use App\Services\User\UserPermissions\UserPermissionDto;
use Illuminate\Database\Eloquent\Model;

/**
 *
 */
class DashboardUser extends Model
{
    /**
     * @var string
     */
    protected $table = "dsh_users";

    /**
     * @var string[]
     */
    protected $fillable = [
        "user_id",
        "environment_id",
        "dashboard_id",
        "role",
        "drive_role",
        "permissions_id"
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function environment()
    {
        return $this->hasOne(Environment::class, 'id', 'environment_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function dashboard()
    {
        return $this->hasOne(Dashboard::class, 'id', 'dashboard_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function user()
    {
        return $this->hasOne(User::class, 'id', 'user_id');
    }

    /**
     * @param $query
     * @return string|null
     */
    public function getEnvironmentName($query): ?string
    {
        $env = $this->environment;
        if ($env) {
            return $env->name;
        }
        return null;
    }

    /**
     * @return UserPermissionDto
     */
    public function getPermissionDto(): UserPermissionDto
    {
        $entity = new UserPermissionDto();
        $entity->setRole($this->role);
        $entity->setEnvironmentId($this->environment_id);
        $entity->setDashboardId($this->dashboard_id);

        return $entity;
    }
}
