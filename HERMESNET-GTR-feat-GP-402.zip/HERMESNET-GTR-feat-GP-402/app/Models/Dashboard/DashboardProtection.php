<?php

namespace App\Models\Dashboard;

use Illuminate\Database\Eloquent\Model;

/**
 *
 */
class DashboardProtection extends Model
{
    /**
     * @var string
     */
    protected $table = "dsh_protections";

    /**
     * @var string[]
     */
    protected $fillable = [
        "dashboard_id",
        "sheet_id",
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function dashboard()
    {
        return $this->hasOne(Dashboard::class, 'id', 'dashboard_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function sheet()
    {
        return $this->hasOne(DashboardSheet::class, 'id', 'sheet_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function unprotectedRanges() {
        return $this->hasMany(DashboardUnprotectedRange::class, "dsh_protection_id", "id");

    }
}
