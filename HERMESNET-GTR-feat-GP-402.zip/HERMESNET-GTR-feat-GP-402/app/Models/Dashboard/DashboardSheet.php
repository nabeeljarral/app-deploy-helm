<?php

namespace App\Models\Dashboard;

use App\Services\Google\SheetGreedProperties;
use Illuminate\Database\Eloquent\Model;

/**
 *
 */
class DashboardSheet extends Model
{
    /**
     * @var string
     */
    protected $table = "dashboard_sheets";

    /**
     * @var string[]
     */
    protected $fillable = [
        "dashboard_id",
        "type",
        "sheet_title",
        "sheet_id",
        "sheet_type",
        "grid_properties"
    ];

    /**
     * @var string[]
     */
    protected $casts = [
        "grid_properties" => "json"
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function dashboard()
    {
        return $this->hasOne(Dashboard::class, "id", "dashboard_id");
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function dashboardProtection()
    {
        return $this->hasOne(DashboardProtection::class, "sheet_id", "id");
    }

    /**
     * @return SheetGreedProperties
     */
    public function getGridProperties(): SheetGreedProperties
    {
        $valueObject = new SheetGreedProperties();

        $properties = $this->grid_properties;
        if (!is_array($properties)) {
            return $valueObject;
        }

        $valueObject->setColumnCount(\Arr::get($properties, "columnCount", $valueObject->getColumnCount()));
        $valueObject->setRowCount(\Arr::get($properties, "rowCount", $valueObject->getRowCount()));

        return $valueObject;
    }
}
