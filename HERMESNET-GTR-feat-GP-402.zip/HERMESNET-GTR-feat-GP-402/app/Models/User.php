<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use App\Admin\Enums\AdminAbility;
use App\Models\Dashboard\DashboardUser;
use App\Models\Template\Template;
use App\Notifications\CustomResetPasswordNotification;
use App\Services\User\Enums\UserRole;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

/**
 * @property int $organization_id
 */
class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'google_email',
        'password',
        'social_id',
        'social_type',
        'role',
        'status',
        'organization_id',
        'invited_from',
        "users",
        "color",
        'is_admin',
        'is_templates_admin',
        'last_activity_at',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at'  => 'datetime',
        'last_activity_at'   => 'datetime',
        'is_admin'           => 'boolean',
        'is_templates_admin' => 'boolean',
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function organization()
    {
        return $this->hasOne(Organization::class, 'id', 'organization_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function dashboardUsers()
    {
        return $this->hasMany(DashboardUser::class, "user_id", "id");
    }

    /**
     * @return string|null
     */
    public function getOrganizationNameAttribute(): ?string
    {
        $organization = $this->organization;
        if ($organization) {
            return $organization->organization_name;
        }
        return null;
    }

    /**
     * @return mixed|string|null
     */
    public function getEnvironmentNameAttribute()
    {
        $dshUser = $this->dashboardUsers->first();
        if ($dshUser && $dshUser->environment_id) {
            return $dshUser->environment->name;
        }
        return null;
    }

    /**
     * @return mixed|string|null
     */
    public function getDashboardNameAttribute()
    {
        $dshUser = $this->dashboardUsers->first();
        if ($dshUser && $dshUser->dashboard_id) {
            return $dshUser->dashboard->name;
        }
        return null;
    }

    /**
     * @param $token
     * @return void
     */
    public function sendPasswordResetNotification($token)
    {
        $this->notify(new CustomResetPasswordNotification($token, $this));
    }

    /**
     * @return string|null
     */
    public function getMaxRole(): ?string
    {
        $roles = DashboardUser::where("user_id", $this->id)
            ->select("role")
            ->get()
            ->pluck('role')
            ->toArray();

        if (empty($roles)) {
            return $this->role;
        }

        return UserRole::getMaxRoleOf($roles);
    }

    /**
     * @return bool
     */
    public function isOrganizationOwner(): bool
    {
        return $this->organization->user_id === $this->id;
    }

    public function isAdmin()
    {
        return $this->is_admin === true;
    }

    /**
     * @return array
     */
    public function getAdminAbilities(): array
    {
        $abilities = [];
        if ($this->is_admin) {
            $abilities[] = AdminAbility::FULL;
        }
        if ($this->is_templates_admin) {
            $abilities[] = AdminAbility::TEMPLATE;
        }
        return $abilities;
    }
}
