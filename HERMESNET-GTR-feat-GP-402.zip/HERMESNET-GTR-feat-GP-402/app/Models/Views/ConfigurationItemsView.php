<?php

namespace App\Models\Views;

use App\Models\Dashboard\Dashboard;
use App\Models\Template\TemplateConfiguration;
use App\Models\Template\TemplateItem;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

/**
 * @property int $id
 * @property int $item_id
 * @property int $parent_item_id
 * @property string $name
 * @property int $report_id
 * @property int $configuration_id
 * @property bool $is_included
 * @property string $reason_of_omission
 * @property string $requirements
 * @property string $recommendations
 * @property array $content
 * @property int $template_id
 * @property string $guidance
 * @property string $sheet_name
 * @property int $content_type
 * @property int $order_number
 * @property bool $mandatory
 * @property string|Carbon $created_at
 * @property string|Carbon $updated_at
 */
class ConfigurationItemsView extends Model
{
    /**
     * @var string
     */
    protected $table = "configuration_items_view";

    /**
     * @var string[]
     */
    protected $fillable = [
        "id", // configuration_items.id
        "item_id", //template_items.id
        "parent_item_id", //template_items.parent_item_id
        "name", //template_items.name
        "report_id",
        "configuration_id",
        "is_included", //configuration_items.is_included
        "reason_of_omission", //configuration_items.reason_of_omission
        "order_number",
        "mandatory", //template_items.mandatory
        "created_at",
        "updated_at",
    ];

    /**
     * @return HasOne
     */
    public function configuration(): HasOne
    {
        return $this->hasOne(TemplateConfiguration::class, "id", "configuration_id");
    }

    /**
     * @return HasOne
     */
    public function report(): HasOne
    {
        return $this->hasOne(Dashboard::class, "id", "report_id");
    }

    /**
     * @return HasOne
     */
    public function templateItem(): HasOne
    {
        return $this->hasOne(TemplateItem::class, "id", "item_id");
    }

    /**
     * @return HasMany
     */
    public function childItems(): HasMany
    {
        return $this->hasMany(TemplateItem::class, "parent_item_id", 'item_id');
    }

    /**
     * @return HasOne
     */
    public function parentItem(): HasOne
    {
        return $this->hasOne(ConfigurationItemsView::class, "item_id", "parent_item_id");
    }

    /*
     * @param Builder $query
     * @return void
     */
    public function scopeHasContent(Builder $query): void
    {
        $query->where("content_type", "=", 0);
    }

    /**
     * @param Builder $query
     * @return void
     */
    public function scopeHasGoogleSheet(Builder $query): void
    {
        $query->where("content_type", "=", 1)
            ->whereNotNull('sheet_name');
    }

    /**
     * @param Builder $query
     * @return void
     */
    public function scopeHasCustomTable(Builder $query): void
    {
        $query->where("content_type", "=", 2)
            ->whereNotNull('sheet_name');
    }
}
