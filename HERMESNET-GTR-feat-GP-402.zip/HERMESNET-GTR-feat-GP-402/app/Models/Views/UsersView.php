<?php

namespace App\Models\Views;

use Illuminate\Database\Eloquent\Model;

/**
 * All Users with Invited Users
 * @param $id int user id or invited user id
 * @param $type string regular/invited (enum)UserType
 */
class UsersView extends Model
{
    /**
     * @var string
     */
    protected $table = "all_users_view";

    /**
     * @var string[]
     */
    protected $fillable = [
        "id",
        "organization_id",
        "name",
        "role",
        "type",
        "email",
        "color"
    ];
}
