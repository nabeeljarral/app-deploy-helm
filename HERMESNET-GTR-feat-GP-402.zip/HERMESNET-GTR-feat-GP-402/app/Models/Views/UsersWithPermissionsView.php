<?php

namespace App\Models\Views;

use App\Services\User\UserPermissions\UserPermissionDto;
use Illuminate\Database\Eloquent\Model;

/**
 * All Users with Invited Users and with user permissions (role, dashboard_id, environment_id) in ALL dashboards or environments
 * @param $id int user id or invited user id
 * @param $type string regular/invited (enum)UserType
 * @param $role string role per env or dashboard
 * @param $environment_id int
 * @param $dashboard_id null|int
 *
 */
class UsersWithPermissionsView extends Model
{
    /**
     * @var string
     */
    protected $table = "all_users_with_permissions_view";

    /**
     * @var string[]
     */
    protected $fillable = [
        "id",
        "name",
        "email",
        "environment_id",
        "role",
        "dashboard_id",
        "organization_id",
        "type",
        "color"
    ];
}
