<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PrintConfEnum extends Model
{
    use HasFactory;

    protected $table = "print_configuration_enums";

    protected $fillable = [
        'name',
        'values'
    ];

    /**
     * @var string[]
     */
    protected $casts = [
        "values" => "json"
    ];

    public function parameters()
    {
        return $this->hasMany(PrintConfParameter::class, 'id', 'print_conf_enum_id');
    }
}
