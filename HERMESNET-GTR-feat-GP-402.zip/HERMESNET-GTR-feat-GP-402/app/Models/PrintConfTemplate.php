<?php

namespace App\Models;

use App\Models\Template\Template;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class PrintConfTemplate extends Model
{
    use HasFactory;

    protected $table = "print_configuration_templates";

    protected bool $cascadeDeletes = true;

    protected $fillable = [
        'template_name',
        'is_blank',
        'template_id',
        'organization_id',
        'report_id',
        'print_conf_template_id'
    ];

    public static function getAvailableElements() {
        return static::query()->with('elements.parameters.enum')
            ->where('is_blank', '=', true)
            ->first()->elements;
    }

    public function elements()
    {
        return $this->hasMany(PrintConfElement::class)->whereNull('print_conf_element_id')->orderBy('order_number');
    }

    public function allElements()
    {
        return $this->hasMany(PrintConfElement::class);
    }

    public function parameters()
    {
        return $this->hasManyThrough(PrintConfParameter::class, PrintConfElement::class);
    }

    public function organizations(): HasMany
    {
        return $this->hasMany(Organization::class, 'id', 'organization_id');
    }

    public function globalTemplate(): HasOne
    {
        return $this->hasOne(Template::class, "id", "template_id");
    }
}
