<?php

namespace App\Models;

use App\Models\Dashboard\Dashboard;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

/**
 *
 */
class InvitedUser extends Model
{
    /**
     * @var string
     */
    protected $table = "invited_user";

    /**
     * @var string[]
     */
    protected $fillable = [
        "name",
        "status",
        "organization_id",
        "invited_from",
        "role",
        "email",
        "callback_url",
        "environment_id",
        "dashboard_id",
        "dashboard_sheet_id",
        "color",
        "items_id"
    ];

    protected $casts = [
        "items_id" => "array"
    ];

    /**
     * @return HasOne
     */
    public function organization(): HasOne
    {
        return $this->hasOne(Organization::class, 'id', 'organization_id');
    }

    /**
     * @return HasOne
     */
    public function environment(): HasOne
    {
        return $this->hasOne(Environment::class, "id", "environment_id");
    }

    /**
     * @return HasOne
     */
    public function dashboard(): HasOne
    {
        return $this->hasOne(Dashboard::class, "id", "dashboard_id");
    }

    /**
     * @return string|null
     */
    public function getOrganizationNameAttribute(): ?string
    {
        $organization = $this->organization;
        if ($organization) {
            return $organization->organization_name;
        }
        return null;
    }

    /**
     * @return string|null
     */
    public function getEnvironmentNameAttribute(): ?string
    {
        $environment = $this->environment;
        if ($environment) {
            return $environment->name;
        }
        return null;
    }

    /**
     * @return string|null
     */
    public function getDashboardNameAttribute(): ?string
    {
        $dashboard = $this->dashboard;
        if ($dashboard) {
            return $dashboard->name;
        }
        return null;
    }
}
