<?php

namespace App\Providers;

use App\Models\Dashboard\Dashboard;
use App\Models\Environment;
use App\Models\PrintConfTemplate;
use App\Models\Template\Template;
use App\Policies\DashboardPolicy;
use App\Policies\EnvironmentPolicy;
use App\Policies\DeleteUserPolicy;
use App\Policies\PrintConfigurationPolicy;
use App\Policies\TemplatePolicy;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The model to policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        Environment::class       => EnvironmentPolicy::class,
        Dashboard::class         => DashboardPolicy::class,
        PrintConfTemplate::class => PrintConfigurationPolicy::class,
        Template::class          => TemplatePolicy::class,
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();

        Gate::define('deleteUser', [DeleteUserPolicy::class, 'action']);
    }
}
