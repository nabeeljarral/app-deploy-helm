<?php

namespace App\Utils;

use App\Services\Google\GoogleAccessToken;
use Google\Client;

/**
 *
 */
final class GoogleUtil
{
    /**
     * @param bool $includeScopes
     * @return Client
     * @throws \Google\Exception
     */
    public static function authClient(bool $includeScopes = false): Client
    {
        $client = new Client();
        $client->setAuthConfig(base_path(config("project.google.api.config_file")));

        if ($includeScopes) {
            $client->addScope(config("project.google.api.scopes"));
        }

        $redirect_url = config("app.url") . config("project.google.api.callback_uri");
        $client->setRedirectUri($redirect_url);

        $client->setAccessType('offline');
        $client->setPrompt('consent');
        $client->setIncludeGrantedScopes(true);

        return $client;
    }

    /**
     * @param array|null $scopes
     * @return Client
     * @throws \Google\Exception
     */
    public static function apiClient(?array $scopes = null): Client
    {

        $googleClient = new Client();
        $googleClient->setAccessType('offline');

        if (config("project.google.api.use_service_account")) {
            $googleClient->setSubject(config('project.google.api.service_account_email'));
            $googleClient->setAuthConfig(base_path(config("project.google.api.service_account")));
        } else {
            $accessToken = GoogleAccessToken::getInstance();
            $googleClient->setAccessToken($accessToken->getToken());
        }

        if ($scopes) {
            $googleClient->addScope($scopes);
        }

        return $googleClient;
    }
}
