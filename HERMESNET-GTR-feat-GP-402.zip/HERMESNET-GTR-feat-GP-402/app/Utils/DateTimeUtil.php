<?php

namespace App\Utils;

use Illuminate\Support\Carbon;

final class DateTimeUtil
{
    static public function now(): Carbon
    {
        return now();
    }
}
