<?php

namespace App\Utils;

class ArrayUtil
{
    public static function isArrayInstanceOf(array $haystack, object|string $class): bool
    {
        if (is_string($class) && !class_exists($class)) {
            throw new \Exception(
                sprintf('Class %s does not exist', $class)
            );
        }

        $count = count(array_filter($haystack, function ($entry) use ($class) {
            return !($entry instanceof $class);
        }));

        return $count == 0;
    }
}
