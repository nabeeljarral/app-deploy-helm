<?php

namespace App\Utils;

/**
 *
 */
final class AvatarUtil
{
    /**
     * @param $name
     * @return string
     */
    public static function getShortName($name): string {
        $letters = array_map(fn($item) => substr($item, 0, 1), preg_split("/[\s,.]+/", $name));
        $short_name = implode('', array_splice($letters, 0, 2));
        return mb_strtoupper($short_name);
    }

    /**
     * @return string
     */
    protected static function randomColorPart(): string
    {
        return str_pad(dechex(mt_rand(0, 255)), 2, '0', STR_PAD_LEFT);
    }

    /**
     * @return string
     */
    public static function randomColorHex(): string
    {
        return "#" . self::randomColorPart() . self::randomColorPart() . self::randomColorPart();
    }
}
