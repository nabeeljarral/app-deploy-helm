<?php

namespace App\Utils;

use Illuminate\Support\Arr;
use Illuminate\Support\Str;

/**
 *
 */
final class UrlUtil
{
    /**
     * @var string
     */
    private string $value;

    /**
     * @param string $value
     */
    public function __construct(string $value)
    {
        $this->value = $value;
    }

    /**
     * @param string $value
     * @return UrlUtil
     */
    public static function of(string $value): self
    {
        return new self($value);
    }

    /**
     * @param string $pattern
     * @return bool
     */
    public function matches(string $pattern): bool
    {
        return Str::is(Str::start($pattern, '*'), $this->value);
    }

    /**
     * @param string $endpoint
     * @return $this
     */
    public function join(string $endpoint): self
    {
        if ($endpoint !== DIRECTORY_SEPARATOR) {
            $endpoint = ltrim($endpoint, DIRECTORY_SEPARATOR . ' ');
        }

        $requiresTrailingSlash = !empty($endpoint) && $endpoint !== DIRECTORY_SEPARATOR;

        $baseEndpoint = rtrim($this->value, DIRECTORY_SEPARATOR . ' ');

        $baseEndpoint = $requiresTrailingSlash
            ? $baseEndpoint . DIRECTORY_SEPARATOR
            : $baseEndpoint;

        $this->value = $baseEndpoint . $endpoint;

        return $this;
    }

    /**
     * @param array $params
     * @return $this
     */
    public function setQueryPrams(array $params = []): self
    {
        if (empty($params)) {
            return $this;
        }

        $this->value = $this->value . "?" . http_build_query($params);

        return $this;
    }

    /**
     * @return string
     */
    public function getValue(): string
    {
        return $this->value;
    }

    /**
     * @param string|null $default
     * @return string|null
     */
    public function getDomain(?string $default = null): ?string
    {
        $parse = parse_url($this->value);

        if (!array_key_exists("host", $parse)) {
            return $default;
        }
        $host = explode(".", $parse["host"]);
        if (empty($host) || !is_array($host)) {
            return $default;
        }

        return Arr::get($host, count($host) - 1, $default);
    }
}
