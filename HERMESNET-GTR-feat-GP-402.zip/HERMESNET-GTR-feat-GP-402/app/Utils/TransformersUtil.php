<?php

namespace App\Utils;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

/**
 *
 */
class TransformersUtil
{
    /**
     * @param Carbon $carbon
     * @return string
     */
    public static function dateTimeFormatted(Carbon $carbon):string {
        if ($carbon->diffInHours() >= 24) {
            return  $carbon->format("M d, Y");
        }else {
            return $carbon->diffForHumans();
        }
    }

    /**
     * @param Request $request
     * @param string $key
     * @return array
     */
    public static function getIncludesFromRequest(Request $request, string $key = 'includes'): array
    {
        $includes = explode(',', $request->get($key, ''));
        if (empty($includes)) {
            $includes = [];
        }
        return $includes;
    }
}
