<?php

namespace App\Admin\Http\Controllers\Templates;

use App\Admin\Http\Requests\Templates\SaveTemplateConfigurationRequest;
use App\Http\Controllers\Controller;
use App\Models\Template\Template;
use App\Models\Template\TemplateConfiguration;
use App\Services\Configuration\CreateTemplateConfiguration;
use App\Services\Configuration\UpdateTemplateConfiguration;
use App\Transformers\Configuration\ConfigurationTransformer;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Spatie\Fractalistic\ArraySerializer;
use Illuminate\Http\JsonResponse;

/**
 *
 */
class AdmTemplateConfigurationsController extends Controller
{
    /**
     * @param Template $template
     * @return JsonResponse
     */
    public function getConfigurationItems(
        Template $template
    ): JsonResponse
    {
        try {
            $configurations = $template->configurations()
                ->where('organization_id', null)
                ->get();

            return fractal($configurations)
                ->transformWith(new ConfigurationTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param TemplateConfiguration $templateConfiguration
     * @return JsonResponse
     */
    public function getConfigurationItem(
        Template $template,
        TemplateConfiguration $templateConfiguration
    ): JsonResponse
    {
        try {
            return fractal($templateConfiguration)
                ->transformWith(new ConfigurationTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }


    /**
     * @param Template $template
     * @param TemplateConfiguration $templateConfiguration
     * @param SaveTemplateConfigurationRequest $request
     * @return JsonResponse
     */
    public function updateConfigurationItem(
        Template $template,
        TemplateConfiguration $templateConfiguration,
        SaveTemplateConfigurationRequest $request
    ): JsonResponse
    {
        try {
            $templateConfiguration = (new UpdateTemplateConfiguration($templateConfiguration, $request->getDto()))->run();
            return fractal($templateConfiguration)
                ->transformWith(new ConfigurationTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param SaveTemplateConfigurationRequest $request
     * @return JsonResponse
     */
    public function createConfigurationItem(
        Template $template,
        SaveTemplateConfigurationRequest $request
    ): JsonResponse
    {
        try {
            $templateConfiguration = (new CreateTemplateConfiguration($template, $request->getDto()))->run();
            return fractal($templateConfiguration)
                ->transformWith(new ConfigurationTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param TemplateConfiguration $templateConfiguration
     * @return JsonResponse
     */
    public function deleteConfigurationItem(
        Template $template,
        TemplateConfiguration $templateConfiguration
    ): JsonResponse
    {
        try {
            $templateConfiguration->delete();
            return fractal($templateConfiguration)
                ->transformWith(new ConfigurationTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }
}
