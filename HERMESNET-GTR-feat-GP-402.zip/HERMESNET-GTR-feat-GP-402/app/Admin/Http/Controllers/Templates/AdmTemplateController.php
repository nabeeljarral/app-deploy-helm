<?php

namespace App\Admin\Http\Controllers\Templates;

use App\Admin\Http\Requests\Templates\SaveTemplateRequest;
use App\Admin\Services\Template\CloneTemplate;
use App\Exceptions\PolicyException;
use App\Http\Controllers\Controller;
use App\Models\Organization;
use App\Models\Template\OrgTemplateAccess;
use App\Models\Template\Template;
use App\Models\Template\TemplateRelatedSummary;
use App\Services\Dashboard\Enums\DashboardType;
use App\Services\Template\Actions\ExportTemplateAction;
use App\Services\Template\Actions\ImportTemplateAction;
use App\Services\Template\Actions\TemplatePublicationChecker;
use App\Services\Template\Actions\UpdateItemsStructure;
use App\Transformers\OrganizationTransformer;
use App\Transformers\Templates\TemplateTransformer;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use League\Fractal\Serializer\DataArraySerializer;
use Spatie\Fractalistic\ArraySerializer;
use Illuminate\Http\JsonResponse;

/**
 *
 */
class AdmTemplateController extends Controller
{
    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function getTemplates(Request $request): JsonResponse
    {
        try {
            $templates = Template::query()
                ->where('is_archived', $request->boolean('archived'))
                ->paginate($request->get("per_page", 10));

            return fractal($templates)
                ->transformWith(new TemplateTransformer())
                ->serializeWith(DataArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @return JsonResponse
     */
    public function getGeneralData(Template $template): JsonResponse
    {
        try {
            return fractal($template)
                ->transformWith(new TemplateTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param SaveTemplateRequest $request
     * @return JsonResponse
     */
    public function createTemplateGeneral(SaveTemplateRequest $request): JsonResponse
    {
        try {
            $template = Template::create($request->validated());

            return fractal($template)
                ->transformWith(new TemplateTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param SaveTemplateRequest $request
     * @return JsonResponse
     */
    public function updateTemplateGeneral(Template $template, SaveTemplateRequest $request): JsonResponse
    {
        try {
            $template->update($request->validated());
            return fractal($template)
                ->transformWith(new TemplateTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param Request $request
     * @return JsonResponse
     */
    public function publishTemplate(Template $template, Request $request)
    {
        try {
            $request->validate(['status' => ['required', 'bool']]);

            $status = $request->boolean("status", true);
            if ($template->is_published === $status) {
                return response()->json([
                    'status' => true,
                ]);
            }

            if ($status) {
                $isCanBePublished = (new TemplatePublicationChecker($template))->run();
                if (!$isCanBePublished) {
                    return response()->json([
                        'status'  => false,
                        'message' => 'The template cannot be published'
                    ]);
                }
            }

            $template->is_published = $status;
            $template->save();

            return response()->json([
                'status' => true
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param Request $request
     * @return JsonResponse
     */
    public function cloneTemplate(Template $template, Request $request): JsonResponse
    {
        try {
            $newTemplate = (new CloneTemplate($template, $request->input('type')))->run();
            return fractal($newTemplate)
                ->transformWith(new TemplateTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param Request $request
     * @return JsonResponse
     */
    public function getRelatedSummaryTemplates(Template $template, Request $request): JsonResponse
    {
        try {
            return fractal($template->relatedSummaries()->paginate($request->get('per_page', 10)))
                ->transformWith(new TemplateTransformer())
                ->serializeWith(DataArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param Request $request
     * @return JsonResponse
     */
    public function getAvailableSummaryForAdd(Template $template, Request $request): JsonResponse
    {
        try {
            $query = Template::query()
                ->whereNotIn("id", $template->relatedSummaries->pluck("id")->toArray())
                ->where("type", DashboardType::SUMMARY_DASHBOARD);

            if ($keyword = $request->get("keyword")) {
                $query->search($keyword);
            }

            $templates = $query->get();
            return fractal($templates)
                ->transformWith(new TemplateTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param Request $request
     * @return JsonResponse
     */
    public function addRelatedSummaryToDataCollection(Template $template, Request $request): JsonResponse
    {
        try {
            $request->validate(['ids' => ['required', 'array']]);
            foreach ($request->get("ids") as $item) {
                TemplateRelatedSummary::updateOrCreate([
                    'data_collection_id' => $template->id,
                    'summary_id'         => $item,
                ]);
            }
            return response()->json([
                'status' => true
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param Request $request
     * @return JsonResponse
     */
    public function deleteRelatedSummary(Template $template, Request $request): JsonResponse
    {
        try {
            $status = TemplateRelatedSummary::where("data_collection_id", $template->id)
                ->where('summary_id', $request->get('id'))
                ->delete();
            return response()->json(compact("status"));
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param Request $request
     * @return JsonResponse
     */
    public function getAssignedOrganizations(Template $template, Request $request): JsonResponse
    {
        try {
            $organizations = $template->assignedOrganizations()
                ->paginate($request->get('per_page', 10));

            return fractal($organizations)
                ->transformWith(new OrganizationTransformer())
                ->serializeWith(DataArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param Request $request
     * @return JsonResponse
     */
    public function getAvailableOrganizations(Template $template, Request $request): JsonResponse
    {
        try {
            $query = Organization::query();
            if ($assignedOrganizations = $template->assignedOrganizations) {
                $query->whereNotIn("id", $assignedOrganizations->pluck("id")->toArray());
            }

            if ($keyword = $request->get("keyword")) {
                $query->search($keyword);
            }

            $organizations = $query->get();
            return fractal($organizations)
                ->transformWith(new OrganizationTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param Request $request
     * @return JsonResponse
     */
    public function assignTemplateOrganizations(Template $template, Request $request): JsonResponse
    {
        try {
            $request->validate(['ids' => ['required', 'array']]);

            $organizations_ids = $request->get("ids");

            if ($currentOrganizations = $template->assignedOrganizations) {
                $organizations_ids = array_diff($organizations_ids, $currentOrganizations->pluck("id")->toArray());
            }

            if (empty($organizations_ids)) {
                throw new \InvalidArgumentException('The organization ids field is required');
            }

            foreach ($organizations_ids as $id) {
                OrgTemplateAccess::create(['organization_id' => $id, 'global_template_id' => $template->id]);
            }

            return response()->json(['status' => true]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param Request $request
     * @return JsonResponse
     */
    public function deleteAssignedOrganizations(Template $template, Request $request): JsonResponse
    {
        try {
            $request->validate(['ids' => ['required', 'array']]);
            $status = OrgTemplateAccess::where("global_template_id", $template->id)
                ->where('organization_id', $request->get("ids"))
                ->delete();

            return response()->json(compact("status"));
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param Request $request
     * @return JsonResponse
     */
    public function updateTemplateField(Template $template, Request $request): JsonResponse
    {
        try {
            $request->validate([
                'field' => ['required', 'string'],
                'value' => ['required']
            ]);

            $template->fill([
                $request->get('field') => $request->get('value')
            ]);
            $status = $template->save();
            return \Response::json(compact('status'));
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param Request $request
     * @return JsonResponse
     */
    public function updateTemplateType(Template $template, Request $request)
    {
        try {
            $request->validate([
                'type' => ['required', 'string', Rule::in(DashboardType::AVAILABLE)]
            ]);

            $targetType = $request->get('type');
            if ($template->type === $targetType) {
                return \Response::json([
                    'status' => true
                ]);
            }

            if (!$request->user()->can('changeTemplateType', $template)) {
                throw new PolicyException('You cannot change the type of this template');
            }

            $template->type = $targetType;
            $template->save();

            return \Response::json([
                'status' => true
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param Request $request
     * @return JsonResponse
     */
    public function deleteTemplate(Template $template, Request $request)
    {
        try {
            if (!$request->user()->can('deleteTemplate', $template)) {
                throw new PolicyException('You cannot delete this template');
            }
            $status = $template->delete();
            return \Response::json(compact('status'));
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param Request $request
     * @return JsonResponse
     */
    public function updateItemsStructure(Template $template, Request $request): JsonResponse
    {
        try {
            $request->validate(['items' => ['required', 'array']]);
            (new UpdateItemsStructure($template, $request->get('items')))->run();
            return \Response::json(['status' => true]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @return \Illuminate\Http\Response
     */
    public function exportTemplate(Template $template)
    {
        return (new ExportTemplateAction($template))->run();
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function importTemplate(Request $request)
    {
        try {
            $request->validate([
                'file' => ['required', 'file'],
                'name' => ['nullable', 'string'],
            ]);

            $template = (new ImportTemplateAction(
                $request->file('file'),
                $request->input('name')
            ))->run();

            return fractal($template)
                ->transformWith(new TemplateTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @return JsonResponse
     */
    public function archiveTemplate(Template $template)
    {
        try {
            $template->is_archived = true;
            $template->save();
            //$status = $template->delete();
            return \Response::json(['status' => true]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param int $template_id
     * @return JsonResponse
     */
    public function restoreTemplate(int $template_id)
    {
        try {
            $template = Template::query()->findOrFail($template_id);
            $template->is_archived = false;
            $template->save();
            return \Response::json(['status' => true]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    public function getGtrSyncConfig(Template $template)
    {
        try {
            return response()->json([
                'data' => $template->gtr_sync_config
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    public function updateGtrSyncConfig(Template $template, Request $request)
    {
        try {
            $request->validate([
                'gtr_sync_config' => 'nullable|array'
            ]);

            $template->gtr_sync_config = $request->get('gtr_sync_config');

            $template->save();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }
}
