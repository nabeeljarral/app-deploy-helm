<?php

namespace App\Admin\Http\Controllers\Templates;

use App\Admin\Http\Requests\Templates\UpsertAnalyticsTabsRequest;
use App\Http\Controllers\Controller;
use App\Models\Template\Template;
use App\Models\Template\TemplateAnalytics;
use App\Transformers\Templates\TemplateAnalyticsTransformer;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Illuminate\Http\JsonResponse;
use Spatie\Fractalistic\ArraySerializer;

class TemplateAnalyticsController extends Controller
{
    /**
     * @param Template $template
     * @return JsonResponse
     */
    public function getAnalyticsTabs(Template $template)
    {
        try {
            return fractal($template->analytics)
                ->transformWith(new TemplateAnalyticsTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param UpsertAnalyticsTabsRequest $request
     * @return JsonResponse
     */
    public function upsertAnalyticsTabs(Template $template, UpsertAnalyticsTabsRequest $request)
    {
        try {
            foreach ($request->validated("tabs") as $item) {
                $template->analytics()->updateOrCreate(
                    ['id' => \Arr::get($item, "id")],
                    $item,
                );
            }

            return fractal($template->analytics)
                ->transformWith(new TemplateAnalyticsTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param TemplateAnalytics $tab
     * @return JsonResponse
     */
    public function deleteAnalyticsTab(TemplateAnalytics $tab)
    {
        try {
            return response()->json([
                'status' => $tab->delete(),
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }
}
