<?php

namespace App\Admin\Http\Controllers\Templates;

use App\Admin\Http\Requests\Templates\SaveTemplateAnalyticsRequest;
use App\Http\Controllers\Controller;
use App\Models\Template\Template;
use App\Models\Template\TemplateAnalytics;
use App\Transformers\Templates\TemplateAnalyticsTransformer;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Spatie\Fractalistic\ArraySerializer;
use Illuminate\Http\JsonResponse;

/**
 *
 */
class AdmTemplateAnalyticsController extends Controller
{


    /**
     * @param Template $template
     * @return JsonResponse
     */
    public function getAnalyticsItems(
        Template $template
    ): JsonResponse
    {
        try {
            return fractal($template->analytics)
                ->transformWith(new TemplateAnalyticsTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param TemplateAnalytics $templateAnalytics
     * @return JsonResponse
     */
    public function getAnalyticsItem(
        Template          $template,
        TemplateAnalytics $templateAnalytics
    ): JsonResponse
    {
        try {
            return fractal($templateAnalytics)
                ->transformWith(new TemplateAnalyticsTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }


    /**
     * @param Template $template
     * @param TemplateAnalytics $templateAnalytics
     * @param SaveTemplateAnalyticsRequest $request
     * @return JsonResponse
     */
    public function updateAnalyticsItem(
        Template                     $template,
        TemplateAnalytics            $templateAnalytics,
        SaveTemplateAnalyticsRequest $request
    ): JsonResponse
    {
        try {
            $data = $request->validated();
            if (isset($data['icon_file'])) {
                $data['icon'] = $this->formatIcon($data['icon_file']);
            }
            $data['looker_embedding_config'] = $request->input("looker_embedding_config", []);

            $templateAnalytics->update($data);
            return fractal($templateAnalytics)
                ->transformWith(new TemplateAnalyticsTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param SaveTemplateAnalyticsRequest $request
     * @return JsonResponse
     */
    public function createAnalyticsItem(
        Template                     $template,
        SaveTemplateAnalyticsRequest $request
    ): JsonResponse
    {
        try {
            $data = $request->validated();
            $data['looker_embedding_config'] = $request->input("looker_embedding_config", []);
            $templateAnalytics = $template->analytics()->create($data);
            if (isset($data['icon_file'])) {
                $templateAnalytics->icon = $this->formatIcon($data['icon_file']);
                $templateAnalytics->save();
            }
            return fractal($templateAnalytics)
                ->transformWith(new TemplateAnalyticsTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param $file
     * @return string|null
     */
    private function formatIcon($file): string|null
    {
        $svg = $file->getContent();
        return preg_replace('/\s+fill=".+?"/', '', $svg);
    }

    /**
     * @param Template $template
     * @param TemplateAnalytics $templateAnalytics
     * @return JsonResponse
     */
    public function deleteAnalyticsItem(
        Template          $template,
        TemplateAnalytics $templateAnalytics
    ): JsonResponse
    {
        try {
            $templateAnalytics->delete();
            return fractal($templateAnalytics)
                ->transformWith(new TemplateAnalyticsTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param Request $request
     * @return JsonResponse|void
     */
    public function updateItemsOrder(Template $template, Request $request)
    {
        try {
            $request->validate([
                'items'                => ['required', 'array'],
                'items.*.id'           => ['required', 'integer'],
                'items.*.order_number' => ['required', 'integer'],
            ]);

            \DB::beginTransaction();
            $order = \Arr::pluck($request->items, 'order_number', 'id');
            foreach ($template->analytics as $item) {
                if (isset($order[$item->id])) {
                    $item->order_number = $order[$item->id];
                    $item->save();
                }
            }
            \DB::commit();

            return fractal($template->analytics()->get())
                ->transformWith(new TemplateAnalyticsTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            \DB::rollBack();
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }
}
