<?php

namespace App\Admin\Http\Controllers\Templates;

use App\Admin\Http\Requests\Templates\SaveTemplateItemRequest;
use App\Http\Controllers\Controller;
use App\Models\Template\Template;
use App\Models\Template\TemplateItem;
use App\Modules\Core\Entities\Enums\TemplateItemType;
use App\Transformers\Templates\NestedItemsTransformer;
use App\Transformers\Templates\TemplateItemTransformer;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Spatie\Fractalistic\ArraySerializer;
use Illuminate\Http\JsonResponse;

class AdmTemplateItemsController extends Controller
{
    /**
     * @param Template $template
     * @return JsonResponse
     */
    function getTemplateNestedItems(Template $template)
    {
        try {
            $items = $template->items()
                ->where('parent_item_id', null)
                ->orderBy('order_number', 'asc')
                ->get();

            return fractal($items)
                ->transformWith(new NestedItemsTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param TemplateItem $templateItem
     * @return JsonResponse
     */
    public function getTemplateItem(Template $template, TemplateItem $templateItem): JsonResponse
    {
        try {
            $transformer = new TemplateItemTransformer();
            return fractal($templateItem)
                ->transformWith($transformer)
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }


    /**
     * @param TemplateItem $templateItem
     * @param SaveTemplateItemRequest $request
     * @return JsonResponse
     */
    public function updateTemplateItem(Template $template, TemplateItem $templateItem, SaveTemplateItemRequest $request): JsonResponse
    {
        try {
            $templateItem->update($request->validated());
            return fractal($templateItem)
                ->transformWith(new TemplateItemTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param SaveTemplateItemRequest $request
     * @return JsonResponse
     */
    public function createTemplateItem(Template $template, SaveTemplateItemRequest $request): JsonResponse
    {
        try {
            $itemData = $request->validated();
            if( $request->input('parent_item_id') ) {
                $lastItem = TemplateItem::where('id', $request->input('parent_item_id'))->first()
                    ->childItems()->orderBy('order_number', 'desc')
                    ->first();
            } else {
                $lastItem = $template->items()->orderBy('order_number', 'desc')->first();
            }

            if( isset($lastItem->order_number) && $lastItem ) {
                $itemData['order_number'] = $lastItem->order_number + 1;
            }

            if( $itemData['content_type']==TemplateItemType::customTable->value ){
                $canCreateCustomTable = TemplateItem::canCreateCustomTable($itemData['custom_table_meta']);
                if( $canCreateCustomTable!==null ){
                    return ResponseUtil::error($canCreateCustomTable);
                }
            }
    
            $templateItem = $template->items()->create($itemData);
            return fractal($templateItem)
                ->transformWith(new TemplateItemTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param TemplateItem $templateItem
     * @return JsonResponse
     */
    public function deleteTemplateItem(Template $template, TemplateItem $templateItem): JsonResponse
    {
        try {
            $templateItem->delete();
            return fractal($templateItem)
                ->transformWith(new TemplateItemTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }
}
