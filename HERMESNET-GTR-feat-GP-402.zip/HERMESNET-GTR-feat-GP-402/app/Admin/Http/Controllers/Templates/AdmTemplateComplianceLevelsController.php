<?php

namespace App\Admin\Http\Controllers\Templates;

use App\Admin\Http\Requests\Templates\SaveTemplateComplianceLevelRequest;
use App\Http\Controllers\Controller;
use App\Models\Template\Template;
use App\Models\Template\TemplateComplianceLevel;
use App\Transformers\Templates\TemplateComplianceLevelTransformer;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Spatie\Fractalistic\ArraySerializer;
use Illuminate\Http\JsonResponse;

/**
 *
 */
class AdmTemplateComplianceLevelsController extends Controller
{


    /**
     * @param Template $template
     * @return JsonResponse
     */
    public function getComplianceLevelItems(
        Template $template
    ): JsonResponse
    {
        try {
            return fractal($template->complianceLevels)
                ->transformWith(new TemplateComplianceLevelTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param TemplateComplianceLevel $templateComplianceLevel
     * @return JsonResponse
     */
    public function getComplianceLevelItem(
        Template $template,
        TemplateComplianceLevel $templateComplianceLevel
    ): JsonResponse
    {
        try {
            return fractal($templateComplianceLevel)
                ->transformWith(new TemplateComplianceLevelTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }


    /**
     * @param Template $template
     * @param TemplateComplianceLevel $templateComplianceLevel
     * @param SaveTemplateComplianceLevelRequest $request
     * @return JsonResponse
     */
    public function updateComplianceLevelItem(
        Template $template,
        TemplateComplianceLevel $templateComplianceLevel,
        SaveTemplateComplianceLevelRequest $request
    ): JsonResponse
    {
        try {
            $data = $request->validated();
            if (isset($data['icon_file'])) {
                $data['icon'] = $this->formatIcon($data['icon_file']);
            }
            $templateComplianceLevel->update($data);
            return fractal($templateComplianceLevel)
                ->transformWith(new TemplateComplianceLevelTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Template $template
     * @param SaveTemplateComplianceLevelRequest $request
     * @return JsonResponse
     */
    public function createComplianceLevelItem(
        Template $template,
        SaveTemplateComplianceLevelRequest $request
    ): JsonResponse
    {
        try {
            $data = $request->validated();
            $templateComplianceLevel = $template->complianceLevels()->create($data);
            if (isset($data['icon_file'])) {
                $templateComplianceLevel->icon = $this->formatIcon($data['icon_file']);
                $templateComplianceLevel->save();
            }
            return fractal($templateComplianceLevel)
                ->transformWith(new TemplateComplianceLevelTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    private function formatIcon($file): string|null
    {
        $svg = $file->getContent();
        return preg_replace('/\s+fill=".+?"/', '', $svg);
    }

    /**
     * @param Template $template
     * @param TemplateComplianceLevel $templateComplianceLevel
     * @return JsonResponse
     */
    public function deleteComplianceLevelItem(
        Template $template,
        TemplateComplianceLevel $templateComplianceLevel
    ): JsonResponse
    {
        try {
            $templateComplianceLevel->delete();
            return fractal($templateComplianceLevel)
                ->transformWith(new TemplateComplianceLevelTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }
}
