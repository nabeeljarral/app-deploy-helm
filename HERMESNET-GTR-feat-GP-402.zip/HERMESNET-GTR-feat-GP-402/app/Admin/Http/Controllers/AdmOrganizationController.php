<?php

namespace App\Admin\Http\Controllers;

use App\Admin\Http\Requests\InviteOrganizationRequest;
use App\Http\Controllers\Controller;
use App\Mail\InviteOrganizationMail;
use App\Models\InvitedOrganization;
use App\Models\Organization;
use App\Transformers\OrganizationTransformer;
use App\Transformers\UserTransformer;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;
use League\Fractal\Serializer\DataArraySerializer;
use Spatie\Fractalistic\ArraySerializer;
use Illuminate\Http\JsonResponse;

/**
 *
 */
class AdmOrganizationController extends Controller
{
    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function getOrganizations(Request $request): JsonResponse
    {
        try {
            $organizations = Organization::paginate($request->get('per_page', 10));
            return fractal($organizations)
                ->transformWith(new OrganizationTransformer())
                ->serializeWith(DataArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Organization $organization
     * @return JsonResponse
     */
    public function getOrganization(Organization $organization): JsonResponse
    {
        try {
            return fractal($organization)
                ->transformWith(new OrganizationTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Organization $organization
     * @param Request $request
     * @return JsonResponse
     */
    public function getUsers(Organization $organization, Request $request): JsonResponse
    {
        try {
            $users = $organization->users()->paginate($request->get('per_page', 10));

            return fractal($users)
                ->transformWith(new UserTransformer())
                ->serializeWith(DataArraySerializer::class)
                ->respond();
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Organization $organization
     * @param Request $request
     * @return JsonResponse
     */
    public function updateTrial(Organization $organization, Request $request): JsonResponse
    {
        try {
            $request->validate([
                'trial_expired_at' => ['required_if:trial_expired_at,true'],
                'is_trial_access'  => ['required', 'boolean']
            ]);

            $isTrialAccess = $request->get('is_trial_access');
            $organization->is_trial_access = $isTrialAccess;

            $organization->trial_expired_at = $isTrialAccess ?
                Carbon::createFromDate($request->get('trial_expired_at'))
                : null;

            $organization->save();

            return response()->json([
                'status' => true,
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param Organization $organization
     * @return JsonResponse
     */
    public function loginAsOrganization(Organization $organization): JsonResponse
    {
        try {
            Session::put('organization_id', $organization->id);

            return response()->json(['status' => true]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    /**
     * @param InviteOrganizationRequest $request
     * @return JsonResponse
     */
    public function inviteOrganization(InviteOrganizationRequest $request): JsonResponse
    {
        try {
            $invitedOrganization = InvitedOrganization::create([
                'email'     => $request->get('email'),
                'user_name' => $request->get('user_name'),
                'owner'     => $request->user()->id,
            ]);

            $mail = new InviteOrganizationMail($invitedOrganization);
            $sentMessage = Mail::to($invitedOrganization->email)->send($mail);

            return response()->json([
                'status' => !!$sentMessage,
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }
}
