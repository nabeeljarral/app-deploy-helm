<?php

namespace App\Admin\Http\Controllers;

use App\Exceptions\PolicyException;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\User\RemoveUser;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AdmUserController extends Controller
{
    /**
     * @param User $user
     * @param Request $request
     * @return JsonResponse
     */
    public function deleteUser(User $user, Request $request): JsonResponse
    {
        try {
            if (!$request->user()->can('deleteUser', $user)) {
                throw new PolicyException("You cannot delete this user");
            }

            $isRemoved = (new RemoveUser($user))->run();
            return response()->json([
                'status' => $isRemoved
            ]);
        } catch (\Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }
}
