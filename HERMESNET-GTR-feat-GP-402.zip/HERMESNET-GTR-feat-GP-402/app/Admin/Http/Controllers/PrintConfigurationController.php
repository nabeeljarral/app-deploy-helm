<?php

namespace App\Admin\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\CreatePrintConfTemplateRequest;
use App\Http\Requests\PrintConfElementRequest;
use App\Http\Requests\PrintConfTemplateRequest;
use App\Models\PrintConfElement;
use App\Models\PrintConfTemplate;
use App\Models\Template\Template;
use App\Services\PrintConfiguration\Templates\BlankPrintConfiguration;
use App\Services\PrintConfiguration\Templates\CustomPrintConfiguration;
use App\Transformers\PrintConfiguration\PrintConfElementTransformer;
use App\Transformers\PrintConfiguration\PrintConfTemplateTransformer;
use App\Utils\LoggerUtil;
use App\Utils\ResponseUtil;
use Exception;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Response;
use Spatie\Fractalistic\ArraySerializer;

class PrintConfigurationController extends Controller

{

    public function getTemplatesList(Template $template): \Illuminate\Http\JsonResponse
    {
        try {
            $printConfigurations = $template->printConfTemplates()
                ->where("organization_id", null)
                ->get();

            return fractal($printConfigurations)
                ->transformWith(new PrintConfTemplateTransformer())
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (Exception $exception) {
            LoggerUtil::exception($exception);

            return ResponseUtil::exception($exception);
        }
    }

    public function getTemplate(Template $template, PrintConfTemplate $printConfTemplate): \Illuminate\Http\JsonResponse
    {
        try {
            return fractal($printConfTemplate)
                ->transformWith(new PrintConfTemplateTransformer())
                ->parseIncludes('elements')
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (Exception $exception) {
            LoggerUtil::exception($exception);

            return ResponseUtil::exception($exception);
        }
    }

    public function getElements(): \Illuminate\Http\JsonResponse

    {
        try {
            $elements = PrintConfTemplate::getAvailableElements();

            return fractal($elements)
                ->transformWith(new PrintConfElementTransformer())
                ->parseExcludes('elements')
                ->serializeWith(ArraySerializer::class)
                ->respond();
        } catch (Exception $exception) {
            LoggerUtil::exception($exception);

            return ResponseUtil::exception($exception);
        }
    }


    public function createGlobalTemplate(
        Template $template,
        CreatePrintConfTemplateRequest $request,
        CustomPrintConfiguration $printConfiguration
    ): \Illuminate\Http\JsonResponse {
        try {
            $templateData = $request->validated();
            $templateData['is_blank'] = false;
            $printConfTemplate = $printConfiguration->saveCustomTemplate($template, $templateData);

            return $this->fractalResponse($printConfTemplate);
        } catch (Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    public function updateCustomTemplate(
        Template $template,
        PrintConfTemplate $printConfTemplate,
        PrintConfTemplateRequest $request,
        CustomPrintConfiguration $printConfiguration
    ): \Illuminate\Http\JsonResponse {
        try {
            $printConfTemplate = $printConfiguration->updatePrintConfTemplate($printConfTemplate,
                $request->validated());

            return $this->fractalResponse($printConfTemplate);
        } catch (Exception $exception) {
            LoggerUtil::exception($exception);

            return ResponseUtil::exception($exception);
        }
    }

    public function deleteTemplate(
        Template $template,
        PrintConfTemplate $printConfTemplate,
        CustomPrintConfiguration $printConfiguration
    ): \Illuminate\Http\JsonResponse {
        try {
            $printConfiguration->deleteTemplate($printConfTemplate);

            return Response::json(['status' => true]);
        } catch (Exception $exception) {
            LoggerUtil::exception($exception);

            return ResponseUtil::exception($exception);
        }
    }

    public function cloneGlobalTemplate(
        Template $template,
        PrintConfTemplate $printConfTemplate,
        CustomPrintConfiguration $printConfiguration
    ): \Illuminate\Http\JsonResponse {
        try {
            $printConfTemplate = fractal($printConfTemplate)
                ->transformWith(new PrintConfTemplateTransformer())
                ->parseIncludes('elements')
                ->serializeWith(ArraySerializer::class)
                ->toArray();

            $printConfiguration->clonePrintConfTemplate($printConfTemplate);

            return Response::json(['status' => true]);
        } catch (Exception $exception) {
            LoggerUtil::exception($exception);

            return ResponseUtil::exception($exception);
        }
    }

    private function fractalResponse($printConfTemplate): \Illuminate\Http\JsonResponse
    {
        return fractal($printConfTemplate)
            ->transformWith(new PrintConfTemplateTransformer())
            ->parseIncludes('elements')
            ->serializeWith(ArraySerializer::class)
            ->respond();
    }

    public function updateElement(PrintConfElement $element, CustomPrintConfiguration $printConfiguration, PrintConfElementRequest $request): \Illuminate\Http\JsonResponse
    {
        try {
            $elementData = $request->validated();
            $printConfiguration->updateElement($elementData);

            return Response::json(['status' => true]);
        } catch (Exception $exception) {
            LoggerUtil::exception($exception);
            return ResponseUtil::exception($exception);
        }
    }

    public function checkTemplateName(
        Template $template,
        CreatePrintConfTemplateRequest $request,
        CustomPrintConfiguration $printConfiguration
    ){
        $templateData = $request->validated();
        $templateName = $templateData['template_name'];
        $status = PrintConfTemplate::where("organization_id", null)->get()->contains('template_name', $templateName);
        return Response::json(compact('status'));

    }

}

