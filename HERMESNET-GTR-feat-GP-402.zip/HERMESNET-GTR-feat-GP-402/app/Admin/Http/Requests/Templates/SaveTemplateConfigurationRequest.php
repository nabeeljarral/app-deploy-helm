<?php

namespace App\Admin\Http\Requests\Templates;

use App\Services\Configuration\DTO\ConfigurationDto;
use Illuminate\Foundation\Http\FormRequest;

/**
 *
 */
class SaveTemplateConfigurationRequest extends FormRequest
{
    /**
     * @return array[]
     */
    public function rules(): array
    {
        return [
            'organization_id' => ["nullable", "string"],
            'name'            => ["required", "string"],
            "guidance"        => ["required", "string"],
            "is_general"      => ["nullable", "boolean"],
            "is_published"    => ["nullable", "boolean"]
        ];
    }


    /**
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return ConfigurationDto
     */
    public function getDto(): ConfigurationDto
    {
        return ConfigurationDto::of($this->validated());
    }
}
