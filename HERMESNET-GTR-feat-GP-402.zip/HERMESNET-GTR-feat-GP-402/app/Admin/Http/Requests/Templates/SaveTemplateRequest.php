<?php

namespace App\Admin\Http\Requests\Templates;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class SaveTemplateRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'name'                              => ["required", "string"],
            "description"                       => ["nullable", "string"],
            "category"                          => ["required", "string"],
            "type"                              => ["required", "string"],
            "is_public"                         => ["bool"],
            "is_trial"                          => ["bool"],
            "use_with_any_summary"              => ["bool"],
            'gd_file_id'                        => ['nullable', "string"],
            'index_sheet'                       => ['nullable', "string"],
            'gd_preview_file_id'                => ['nullable', "string"],
            'hidden_connected_sheet'            => ['bool'],
            'allow_aggregation_view'            => ['bool'],
            'allow_report_structure_definition' => ['bool'],
            'data_sheet'                        => ['nullable', "string"],
            'guidance'                          => ['nullable', "string"],
        ];
    }

    public function authorize(): bool
    {
        return true;
    }
}
