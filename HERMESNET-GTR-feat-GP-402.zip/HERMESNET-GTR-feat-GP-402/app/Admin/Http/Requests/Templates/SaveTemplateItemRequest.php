<?php

namespace App\Admin\Http\Requests\Templates;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class SaveTemplateItemRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'name'                  => ["required", "string"],
            "parent_item_id"        => ["nullable", "string"],
            "mandatory"             => ["bool"],
            "content_type"          => ["required", "numeric"],
            "include_in_printing"   => ["bool"],
            'requirements'          => ['nullable', "string"],
            'recommendations'       => ['nullable', "string"],
            'guidance'              => ['nullable', "string"],
            'content'               => ['nullable', "string"],
            'custom_table_meta'     => ['nullable', "array"],
            'sheet_name'            => ['nullable', "string"],
            'sheet_height'          => ['nullable', "string"],
            //'order_number'     => ['nullable', "numeric"],
        ];
    }


    public function authorize(): bool
    {
        return true;
    }
}
