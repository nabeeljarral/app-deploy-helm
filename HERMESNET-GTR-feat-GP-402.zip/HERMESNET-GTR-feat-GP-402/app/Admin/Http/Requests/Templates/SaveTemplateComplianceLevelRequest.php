<?php

namespace App\Admin\Http\Requests\Templates;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\File;

class SaveTemplateComplianceLevelRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'name'         => ["required", "string"],
            "guidance"     => ["required", "string"],
            "icon_file"    => ["nullable", File::types(['svg'])],
            "is_trial"     => ["required", "boolean"],
            "is_published" => ["required", "boolean"],
        ];
    }

    /**
     * Prepare inputs for validation.
     *
     * @return void
     */
    protected function prepareForValidation()
    {
        $this->merge([
            'is_trial'     => $this->toBoolean($this->is_trial),
            'is_published' => $this->toBoolean($this->is_published),
        ]);
    }

    /**
     * Convert to boolean
     *
     * @param $booleable
     * @return boolean
     */
    private function toBoolean($booleable)
    {
        return filter_var($booleable, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
    }

    public function authorize(): bool
    {
        return true;
    }
}
