<?php

namespace App\Admin\Http\Requests\Templates;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\File;

class SaveTemplateAnalyticsRequest extends FormRequest
{
    public function rules(): array
    {
        $rules = [
            'name'                    => ["required", "string"],
            "icon_file"               => ["nullable", File::types(['svg'])],
            "looker_embedding_url"    => ["required_if:sheet_name,null", "nullable", "string"],
            "looker_embedding_config" => ["nullable", "array"],
            "sheet_name"              => ["required_if:looker_embedding_url,null", "string"],
        ];

        if ($this->input('looker_embedding_url')) {
            $rules = array_merge($rules, [
                "sheet_name"                                 => ["nullable", "string"],
                "looker_embedding_config.models"             => ["required", "array"],
                "looker_embedding_config.session_length"     => ["required", "numeric"],
                "looker_embedding_config.external_group_id"  => ["nullable", "string"],
                "looker_embedding_config.permissions"        => ["required", "array"],
                "looker_embedding_config.permissions.*"      => ["required", "string"],
                "looker_embedding_config.group_ids"          => ["nullable", "array"],
                "looker_embedding_config.user_attributes"    => ["nullable", "array"],
                "looker_embedding_config.access_filters"     => ["nullable", "array"],
                "looker_embedding_config.first_name"         => ["nullable", "string"],
                "looker_embedding_config.last_name"          => ["nullable", "string"],
                "looker_embedding_config.force_logout_login" => ["required", "boolean"],
            ]);
        }

        return $rules;
    }

    public function getValidatorInstance()
    {
        if (isset($this->looker_embedding_config) && $this->looker_embedding_url) {
            $lookerConfig = json_decode($this->looker_embedding_config, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new \Exception('Invalid JSON format');
            }

            $this->merge([
                'looker_embedding_config' => $lookerConfig,
            ]);
        } else {
            $this->merge([
                'looker_embedding_config' => null,
            ]);
        }

        return parent::getValidatorInstance();
    }

    public function messages(): array
    {
        return [
            'sheet_name.required_if'                              => 'Specify the sheet name or Looker embedding configuration.',
            'looker_embedding_config.models.required'             => 'Looker Embedding. The models field is required.',
            'looker_embedding_config.session_length.required'     => 'Looker Embedding. The session length field is required.',
            'looker_embedding_config.permissions.required'        => 'Looker Embedding. The permissions field is required.',
            'looker_embedding_config.permissions.*.required'      => 'Looker Embedding. The permissions field is required.',
            'looker_embedding_config.access_filters.required'     => 'Looker Embedding. The access filters field is required.',
            'looker_embedding_config.force_logout_login.required' => 'Looker Embedding. The force logout login field is required.',
        ];
    }

    public function authorize(): bool
    {
        return true;
    }
}
