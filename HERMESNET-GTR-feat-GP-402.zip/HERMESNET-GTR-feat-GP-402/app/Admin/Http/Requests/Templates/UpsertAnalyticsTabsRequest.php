<?php

namespace App\Admin\Http\Requests\Templates;

use Illuminate\Foundation\Http\FormRequest;

/**
 *
 */
class UpsertAnalyticsTabsRequest extends FormRequest
{
    /**
     * @return array[]
     */
    public function rules(): array
    {
        return [
            'tabs'            => ['required', 'array'],
            'tabs.*.id'       => ["nullable", "int", "exists:template_analytics,id"],
            'tabs.*.name'     => ["required", "string"],
            'tabs.*.sheet_name' => ["required", "string"],
        ];
    }

    /**
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }
}
