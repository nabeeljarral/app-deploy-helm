<?php

namespace App\Admin\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class InviteOrganizationRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'email' => ['required', 'email', 'unique:users,email', 'unique:invited_user,email', 'unique:invited_organizations,email'],
            'user_name' => ['required', 'string']
        ];
    }

    public function authorize(): bool
    {
        return true;
    }
}
