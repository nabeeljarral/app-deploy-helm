<?php

namespace App\Admin\Mail;

use App\Models\Organization;
use App\Transformers\OrganizationTransformer;
use App\Utils\UrlUtil;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Collection;

/**
 *
 */
class TrialAdminNotificationMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * @param Collection $organizations
     * @param bool $isOver
     */
    public function __construct(
        protected Collection $organizations,
        protected bool $isOver = true
    )
    {

    }

    /**
     * @return TrialAdminNotificationMail
     */
    public function build()
    {
        $organizations = fractal($this->organizations)
            ->transformWith(new OrganizationTransformer())
            ->toArray();

        $admin_url = UrlUtil::of(config('app.url'))->join('admin')->getValue();

        $view = ($this->isOver)
            ? 'emails.admin.trial-is-over'
            : 'emails.admin.trial-expired';

        return $this
            ->subject("HERMESNET. Reminder Trial Period Ends")
            ->view($view, compact('organizations', 'admin_url'));
    }
}
