<?php

namespace App\Admin\Mail;

use App\Models\User;
use App\Utils\UrlUtil;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

/**
 *
 */
class SubscriptionRequestMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * @param User $user
     */
    public function __construct(private User $user)
    {

    }


    /**
     * @return SubscriptionRequestMail
     */
    public function build()
    {
        $admin_url = UrlUtil::of(config('app.url'))->join('admin')->getValue();

        return $this
            ->subject("HERMESNET. Subscription request")
            ->view('emails.admin.subscription-request', [
                "user_name"         => $this->user->name,
                "user_email"        => $this->user->email,
                "organization_name" => $this->user->organization->organization_name,
                "admin_url"         => $admin_url,
            ]);
    }
}
