<?php

namespace App\Admin\Enums;

class AdminAbility
{
    public const FULL = "admin";

    public const TEMPLATE = "templates_admin";
}
