<?php

namespace App\Admin\Services;

use App\Abstractions\Runnable;
use App\Models\User;
use Illuminate\Mail\Mailable;
use Illuminate\Support\Facades\Mail;

/**
 *
 */
class SendAdminsEmail implements Runnable
{
    /**
     * @param Mailable $mail
     */
    public function __construct(private Mailable $mail)
    {

    }

    /**
     * @return mixed|void
     */
    public function run()
    {
        $admins = User::where('is_admin', true)->get();

        if ($admins->isEmpty()) {
            return;
        }
        $emails = $admins->pluck("email")->toArray();
        Mail::to($emails)->queue($this->mail);
    }
}
