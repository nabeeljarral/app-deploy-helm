<?php

namespace App\Admin\Services\Template;

use App\Abstractions\Runnable;
use App\Models\Template\Template;
use App\Models\Template\TemplateItem;

class ReplaceTemplateItemsCrossLinks implements Runnable
{
    public function __construct(
        private Template $template,
        private array    $itemIdRatio,
    )
    {

    }

    public function run(): void
    {
        /** @var TemplateItem $item */
        foreach ($this->template->items as $item) {
            $item->requirements = $this->replaceHtmlCrossItemsLinks($item->requirements);
            $item->guidance = $this->replaceHtmlCrossItemsLinks($item->guidance);
            $item->recommendations = $this->replaceHtmlCrossItemsLinks($item->recommendations);
            $item->save();
        }
    }

    /**
     * @param string|null $html
     * @return string|null
     */
    private function replaceHtmlCrossItemsLinks(?string $html): ?string
    {
        if (!$html) {
            return null;
        }
        return preg_replace_callback(
            '/<a href="#item_id=(\d+)">(.+?)<\/a>/',
            function ($matches) {
                $id = $matches[1];
                $name = $matches[2];
                $newId = $this->itemIdRatio[$id] ?? $id;
                return "<a href=\"#item_id={$newId}\">{$name}</a>";
            },
            $html
        );
    }
}
