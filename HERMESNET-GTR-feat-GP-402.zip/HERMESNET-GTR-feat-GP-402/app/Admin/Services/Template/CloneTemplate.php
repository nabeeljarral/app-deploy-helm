<?php

namespace App\Admin\Services\Template;

use App\Abstractions\Runnable;
use App\Admin\Services\Template\PrintConf\ClonePrintConf;
use App\Models\Template\Template;
use App\Models\Template\TemplateItem;

/**
 *
 */
class CloneTemplate implements Runnable
{
    /**
     * @var array<int, int>
     */
    private array $itemIdRatio = [];

    /**
     * @var Template
     */
    private Template $newTemplate;

    /**
     * @param Template $template
     * @param string|null $type
     */
    public function __construct(
        private Template $template,
        private ?string  $type = null,
    )
    {

    }

    /**
     * @return Template
     */
    public function run(): Template
    {
        $this->newTemplate = $this->template->replicate();
        $this->newTemplate->type = $this->type ?? $this->template->type;
        $this->newTemplate->name = $this->newTemplate->name . ' (copy)';
        $this->newTemplate->push();

        $this->cloneRelations();
        $this->clonePrintConfigs();
        $this->cloneItems($this->template, $this->newTemplate);
        $this->replaceCrossItemsLinks();
        return $this->newTemplate;
    }

    /**
     * @return void
     */
    private function cloneRelations(): void
    {
        $relations = ['analytics', 'configurations'];
        foreach ($relations as $relationName) {
            foreach ($this->template->$relationName as $record) {
                $this->newTemplate->$relationName()->save($record->replicate());
            }
        }
    }

    /**
     * @param TemplateItem|Template $originRecord
     * @param TemplateItem|Template $newRecord
     * @return void
     */
    private function cloneItems(TemplateItem|Template $originRecord, TemplateItem|Template $newRecord): void
    {
        foreach ($originRecord->childItems as $record) {
            $originId = $record->id;
            $replicate = $record->replicate();
            $replicate->template_id = $this->newTemplate->id;

            /** @var TemplateItem|Template $clonedRecord */
            $clonedRecord = $newRecord->childItems()->save($replicate);
            $this->itemIdRatio[$originId] = $clonedRecord->id;

            $this->cloneItems($record, $clonedRecord);
        }
    }

    /**
     * @return void
     */
    private function replaceCrossItemsLinks(): void
    {
        (new ReplaceTemplateItemsCrossLinks($this->newTemplate, $this->itemIdRatio))->run();
    }

    /**
     * @return void
     */
    private function clonePrintConfigs(): void
    {
        foreach ($this->template->printConfTemplates as $oldPrintConfTemplates) {
            (new ClonePrintConf( $this->newTemplate->id, $oldPrintConfTemplates))->run();
        }
    }
}
