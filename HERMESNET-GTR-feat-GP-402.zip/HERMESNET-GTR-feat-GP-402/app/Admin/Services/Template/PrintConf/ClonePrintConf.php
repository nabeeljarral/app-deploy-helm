<?php

namespace App\Admin\Services\Template\PrintConf;

use App\Abstractions\Runnable;
use App\Admin\Services\Template\ReplaceTemplateItemsCrossLinks;
use App\Models\PrintConfElement;
use App\Models\PrintConfTemplate;
use App\Models\Template\Template;
use App\Models\Template\TemplateItem;
use Illuminate\Database\Eloquent\Model;

/**
 *
 */
class ClonePrintConf implements Runnable
{
    private ?PrintConfTemplate $newPrintConf = null;

    /**
     * @param PrintConfTemplate $oldPrintConf
     */
    public function __construct(
        private int $newTemplateId,
        private PrintConfTemplate $oldPrintConf,
    )
    {

    }

    public function run(): PrintConfTemplate
    {
        $this->newPrintConf = $this->oldPrintConf->replicate();
        $this->newPrintConf->template_id = $this->newTemplateId;
        $this->newPrintConf->push();
        $this->cloneElements();
        return $this->newPrintConf;
    }

    private function cloneElements(): void
    {
        foreach ($this->oldPrintConf->elements as $oldElement) {
            $this->cloneElement($oldElement, $this->newPrintConf);
        }
    }

    private function cloneElement(PrintConfElement $oldElement, PrintConfElement|PrintConfTemplate|Model $parent): void
    {
        $newElement = $parent->elements()->save($oldElement->replicate());
        if (! $newElement) {
            return;
        }
        foreach ($oldElement->parameters as $oldParameter) {
            $newElement->parameters()->save($oldParameter->replicate());
        }
        foreach ($oldElement->elements as $oldChildElement) {
            $this->cloneElement($oldChildElement, $newElement);
        }
    }

}
