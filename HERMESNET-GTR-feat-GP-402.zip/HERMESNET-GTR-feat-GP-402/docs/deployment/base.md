# Server setup

- Web Server
- PHP 8.1
- NodeJs v14.20.1
- NPM v6.14.17
- composer.phar v2.4.2
- MySql Server
- Redis Server
- Supervisor

# Google Drive structure

```
    - root
        - _clients
        - _templates
            - blank.xlsx
            - ghg_summary_v1.0.xlsx
            - ghg_v1.0.xlsx
```

# Config

### .env

```
    APP_URL=https://my-domain.com
    
    DB_CONNECTION=mysql
    DB_HOST=127.0.0.1
    DB_PORT=3306
    DB_DATABASE=username
    DB_USERNAME=dbname
    DB_PASSWORD=password
    
    CACHE_DRIVER=redis
    QUEUE_CONNECTION=database
    
    REDIS_HOST=127.0.0.1
    REDIS_PASSWORD=null
    REDIS_PORT=6379
    REDIS_CLIENT=predis
```

### Google Cloud Config

### config/project/google.php - Google Api

https://console.cloud.google.com/apis/credentials/oauthclient/583777094252-e5ug059a13amsvf93obu5iv18fna4rjs.apps.googleusercontent.com?project=smiling-spider-365110

```php
    
<?php
return [
    "api"   => [
        "config_file"   => "client_secret_****.json", // download the file from google cloud -> credentials and place it in the root directory
        ...
    ],
    'drive' => [
        ...
        "templates_folder_id"   => "1g3_ZAKnnDmKE5m9vvwIToa-t0ARK8Vgc", // Google Drive folder with templates
        "clients_folder_id"     => "1tY-8VxQbhtw9Uo0kaPSN-5gXmMtEECTq", // Google Drive root folder for clients
        ...
    ],
];
```

### config/project/dashboard.php

```php
<?php
return [
    'templates' => [
        'ghg_summary' => [
            'id'   => '1Y4c7WsNPkX--C53sYGRFDS-2dq7zOCNwQs8J8_aOz0E', // ghg_summary_v1.0.xlsx - Google Drive file id 
            'name' => 'ghg_summary',
            'label' => 'GHG',
            'type' => \App\Services\Dashboard\Enums\DashboardType::SUMMARY_DASHBOARD,
        ],
        'ghg'         => [
            'id'   => '13ls8WbMwDoMae3vsTpkbGu-BoCi0bIRaH4_HWG2BRzw', // ghg_v1.0.xlsx  - Google Drive file id 
            'name' => 'ghg',
            'label' => 'GHG',
            'type' => \App\Services\Dashboard\Enums\DashboardType::DASHBOARD,
        ],
        'empty'       => [
            'id'   => '1ODIenohiaWII4h-pqlCrvKPHYnlQW7Cd9FtZvdhhhw0', // blank.xlsx - Google Drive file id 
            'name' => 'empty',
            'label' => 'New Empty Dashboard',
            'type' => \App\Services\Dashboard\Enums\DashboardType::DASHBOARD,
        ],
    ],
];

```

### config/services.php - Google Login

https://console.cloud.google.com/apis/credentials/oauthclient/583777094252-rbc80a3jdafr5qcm068a3ho3od5lfvet.apps.googleusercontent.com?project=smiling-spider-365110

```php
return [
    ...
    'google' => [
        'client_id' => '***.apps.googleusercontent.com',
        'client_secret' => '****',
        'redirect' => 'https://my-domain.com/api/auth/google/callback' //
    ]
    ...
]
```

### supervisor

https://www.digitalocean.com/community/tutorials/how-to-install-and-manage-supervisor-on-ubuntu-and-debian-vps

```bash
$ sudo nano /etc/supervisor/conf.d/hermes.conf
```

```conf
[program:hermes-worker]
process_name=%(program_name)s_%(process_num)02d
command=php8.0 /full/path/to/project/artisan queue:work database --tries=1 --sleep=3 --queue=hermessync
autostart=true
autorestart=true
user=crmoz
startsecs=0
numprocs=4
redirect_stderr=true
stdout_logfile=/full/path/to/project/storage/logs/worker.log
```

# Install Project

```bash
$ cd /full/path/to/project
$ composer install
$ npm install
$ npm run prod
$ ###php artisan key:generate
$ php artisan cache:clear
$ php artisan config:clear
$ php artisan view:clear
$ php artisan queue:restart
$ php artisan queue:clear
$ php artisan optimize
$ php artisan migrate          
$ php artisan migrate:refresh --path=/database/migrations/views 
```

# Google Api oAuth - google_api_oauth.mp4
/api/google/oauth

### ENV
- [ ] `MIX_APP_NAME="${APP_NAME}"`
VITE_APP_NAME="${APP_NAME}"
VITE_APP_URL="${APP_URL}"

php artisan migrate:refresh --path=/database/migrations/2022_10_28_123944_create_templates_table.php
php artisan migrate --path=/database/migrations/printConfigurations

php artisan admin:assign-admin #user_id - to grant admin rights
php artisan tmp:assign-old-reports-template - link templates to old reports
php artisan print-configuration:save-elements - update print configuration elements
php artisan storage:link - create link to rich-text upload images


# Regs view
create view regs as
select u.id as UserId, name as Name, email, organization_name Organization, u.created_at as RegisteredAt, google_email as GoogleAccount, 
	last_activity_at as LastActivity, countries as Countries, city as City
from organizations o, users u
where u.organization_id = o.id
order by RegisteredAt desc;
