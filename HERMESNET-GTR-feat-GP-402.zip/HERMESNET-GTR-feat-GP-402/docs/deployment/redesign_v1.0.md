# TODO:
### Base

- [ ] npm install
- [ ] php artisan migrate
- [ ] php artisan optimize:clear

### ENV
- [ ] `MIX_APP_NAME="${APP_NAME}"`
