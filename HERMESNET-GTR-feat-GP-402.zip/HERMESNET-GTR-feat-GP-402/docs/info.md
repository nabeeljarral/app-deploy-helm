> нам нужно переименовывать роли: Environment owner > Workspace owner; Dashboard owner > Document owner; Contributor > Contributor
