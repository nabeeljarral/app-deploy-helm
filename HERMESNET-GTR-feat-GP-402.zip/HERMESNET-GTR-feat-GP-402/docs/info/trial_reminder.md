# TrialReminderCommand
[`TrialReminderCommand.php`](..%2Fapp%2FConsole%2FCommands%2FTrialReminderCommand.php)

## Introduction
The `TrialReminderCommand` command can be executed using the `php artisan` command in a terminal or command prompt. 
The command accepts an optional `--is-over` flag, which indicates whether the trial period has already ended or not. 
If the `--is-over` flag is set, the command will retrieve the organizations whose trial period has ended on the current day. 
Otherwise, it will retrieve the organizations whose trial period will expire in a number 
of days specified in the [`subscription.php`](..%2Fconfig%2Fproject%2Fsubscription.php) configuration file.

The command will then retrieve the list of organizations whose trial period has expired 
or will expire soon and send email reminders to environment owners and admins using the `TrialExpiredReminderMail` and `TrialAdminNotificationMail`.

## Functionality

The `TrialReminderCommand` command uses the `Organization` model to retrieve the list of organizations
whose trial period has expired or will expire soon.

The command accepts an optional `--is-over` flag, which can be used to retrieve the organizations 
whose trial period has already ended.

When the `handle()` method is called, it first checks if the `--is-over` option has been set. 
If it has, it retrieves the list of organizations whose trial access has ended on the current day. 
If it hasn't, it retrieves the list of organizations whose trial access will expire in a number 
of days specified in the [subscription.php](..%2Fconfig%2Fproject%2Fsubscription.php) configuration file.

After retrieving the list of organizations, the `handle()` method checks if any organizations were found. 
If no organizations were found, the method prints a message to the console and exits.

If organizations were found, the `toEnvironmentOwners()` and `toAdmins()` methods are called to send email reminders 
to the environment owners and admins.

The `toEnvironmentOwners()` method retrieves the list of environment owners for each organization and sends 
them an email reminder using the `TrialExpiredReminderMail`.

The `toAdmins()` method sends an email reminder to the admins of each organization using the `TrialAdminNotificationMail` class.

## Usage
To use the `TrialReminderCommand` command, open a terminal or command prompt and navigate 
to the root directory of your Laravel application. Then, enter the following command:

```bash
    php artisan trial:reminder
```

You can also use the optional --is-over flag to retrieve the organizations whose trial period has already ended:

```bash
php artisan trial:reminder --is-over
```

Note that the `TrialReminderCommand` command requires that the Laravel application is properly configured 
and that the [`subscription.php`](..%2Fconfig%2Fproject%2Fsubscription.php) configuration file contains the required configuration parameters.


## Execution Schedule
The execution schedule for the `TrialReminderCommand` is located in the [`App\Console\Kernel`](..%2Fapp%2FConsole%2FKernel.php) class.
The Kernel class is responsible for scheduling and executing console commands in Laravel applications.

In the schedule() method of the Kernel class, you can see that the `TrialReminderCommand` is scheduled to run twice 
a day at specific times using the dailyAt() method. The first schedule runs the command without the --is-over option daily at 9:00.
The second schedule runs the command with the --is-over option daily at 10:00.

Here is an example of the schedule configuration in the Kernel class:

```php

protected function schedule(Schedule $schedule)
{
    $schedule->command("trial:reminder")->dailyAt('09:00');
    $schedule->command("trial:reminder --is-over")->dailyAt('10:00');
}

```

By default, Laravel's task scheduler runs every minute and checks if any scheduled tasks need to be executed. 
If a scheduled task is due to run, the task scheduler will execute the command.

In summary, the Trial Reminder Command is scheduled to run automatically twice a day using the Kernel class in Laravel.
