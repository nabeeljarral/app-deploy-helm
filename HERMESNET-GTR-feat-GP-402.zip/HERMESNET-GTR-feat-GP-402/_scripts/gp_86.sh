#!/bin/bash
clear;
php artisan migrate:refresh --path=/database/migrations/2022_10_28_123944_create_templates_table.php;
php artisan migrate
php artisan migrate:refresh --path=/database/migrations/views;
php artisan move:templates-to-db;
php artisan optimize:clear;
php artisan queue:restart
npm i;
npm run prod;
echo "-> DONE <-";
