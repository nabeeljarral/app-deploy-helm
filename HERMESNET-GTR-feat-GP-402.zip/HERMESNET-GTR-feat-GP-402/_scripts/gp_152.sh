#!/bin/bash
clear;
php artisan migrate
php artisan migrate:refresh --path=/database/migrations/views;
php artisan optimize:clear;
php artisan queue:restart
npm run prod;
echo "-> DONE <-";
