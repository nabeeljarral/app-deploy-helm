#!/bin/bash
clear;
php artisan migrate
php artisan migrate:refresh --path=/database/migrations/printConfigurations;
php artisan print-configuration:save-elements;
php artisan optimize:clear;
php artisan queue:restart
npm run prod;
echo "-> DONE <-";
