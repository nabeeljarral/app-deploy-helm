#!/bin/bash
php artisan migrate:refresh --path=/database/migrations/views;
