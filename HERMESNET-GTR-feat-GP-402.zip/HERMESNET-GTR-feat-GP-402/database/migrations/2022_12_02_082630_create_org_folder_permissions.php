<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::create('org_folder_permissions', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger("organization_id");
            $table->unsignedBigInteger("user_id");
            $table->text("permissions_id")->nullable();

            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->cascadeOnDelete();

            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('org_folder_permissions');
    }
};
