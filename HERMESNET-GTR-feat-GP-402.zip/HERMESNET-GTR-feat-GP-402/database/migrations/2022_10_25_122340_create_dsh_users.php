<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::create('dsh_users', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger("user_id")->nullable(false);
            $table->unsignedBigInteger("environment_id")->nullable(false);
            $table->unsignedBigInteger("dashboard_id")->nullable(true);
            $table->string("role")->nullable(false);
            $table->string("drive_role")->nullable(false); //writer\reader\commenter
            $table->text("permissions_id")->nullable();

            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->cascadeOnDelete();

            $table->foreign('environment_id')
                ->references('id')
                ->on('environments')
                ->cascadeOnDelete();

            $table->foreign('dashboard_id')
                ->references('id')
                ->on('dashboards')
                ->nullOnDelete();

            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('dsh_users');
    }
};
