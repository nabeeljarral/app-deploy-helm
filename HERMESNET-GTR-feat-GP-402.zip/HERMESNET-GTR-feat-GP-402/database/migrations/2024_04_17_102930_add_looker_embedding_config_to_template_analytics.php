<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('template_analytics', function (Blueprint $table) {
            $table->json("looker_embedding_config")->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('template_analytics', function (Blueprint $table) {
            $table->dropColumn("looker_embedding_config");
        });
    }
};
