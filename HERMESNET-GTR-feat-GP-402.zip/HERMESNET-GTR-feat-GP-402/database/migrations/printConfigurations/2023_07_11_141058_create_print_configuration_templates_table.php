<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('print_configuration_templates', function (Blueprint $table) {
            $table->id();
            $table->string('template_name');
            $table->boolean('is_blank')->default(false);

            $table->unsignedBigInteger('organization_id')->nullable(true);
            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->cascadeOnDelete();

            $table->unsignedBigInteger('template_id')->nullable();
            $table->foreign('template_id')
                ->references('id')
                ->on('templates')
                ->nullOnDelete();

            $table->unsignedBigInteger('print_conf_template_id')->nullable();
            $table->foreign('print_conf_template_id')
                ->references('id')
                ->on('print_configuration_templates');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('print_configuration_templates');
    }
};
