<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('print_configuration_elements', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('title');
            $table->boolean('is_mandatory')->default(false);
            $table->boolean('is_single')->default(false);
            $table->boolean('is_default')->default(false);
            $table->boolean('is_embeddable');
            $table->boolean('is_parent');
            $table->integer('order_number')->nullable();

            $table->unsignedBigInteger('print_conf_template_id');
            $table->foreign('print_conf_template_id')
                ->references('id')
                ->on('print_configuration_templates')
                ->cascadeOnDelete();


            $table->unsignedBigInteger('print_conf_element_id')->nullable();
            $table->foreign('print_conf_element_id')
                ->references('id')
                ->on('print_configuration_elements')
                ->cascadeOnDelete();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('print_configuration_elements');
    }
};
