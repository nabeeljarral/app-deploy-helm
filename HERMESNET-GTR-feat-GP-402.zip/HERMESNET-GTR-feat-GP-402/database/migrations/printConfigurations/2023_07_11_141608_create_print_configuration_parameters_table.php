<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('print_configuration_parameters', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('title')->nullable();
            $table->string('default_value')->nullable();
            $table->text('value')->nullable();
            $table->string('guidance', 500)->nullable();
            $table->string('type');
            $table->boolean('is_mandatory')->default(false);
            $table->boolean('identity')->default(false);

            $table->unsignedBigInteger('print_conf_element_id');
            $table->foreign('print_conf_element_id')
                ->references('id')
                ->on('print_configuration_elements')
                ->cascadeOnDelete();

            $table->unsignedBigInteger('print_conf_enum_id')->nullable();
            $table->foreign('print_conf_enum_id')
                ->references('id')
                ->on('print_configuration_enums')
                ->nullOnDelete();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('print_configuration_parameters');
    }
};
