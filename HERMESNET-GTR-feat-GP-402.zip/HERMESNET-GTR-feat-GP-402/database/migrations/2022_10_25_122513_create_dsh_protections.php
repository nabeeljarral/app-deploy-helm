<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::create('dsh_protections', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger("dashboard_id")->nullable(false);
            $table->unsignedBigInteger("sheet_id")->nullable(false);
            $table->string("protected_range_id")->nullable(true);

            $table->foreign('dashboard_id')
                ->references('id')
                ->on('dashboards')
                ->cascadeOnDelete();

            $table->foreign('sheet_id')
                ->references('id')
                ->on('dashboard_sheets')
                ->cascadeOnDelete();

            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('dsh_protections');
    }
};
