<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('templates', function (Blueprint $table) {
            $table->string("gd_file_id")->nullable();
            $table->string("gd_preview_file_id")->nullable();
            $table->boolean("hidden_connected_sheet")->default(false);
            $table->string("index_sheet")->nullable();
            $table->string("data_sheet")->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('templates', function (Blueprint $table) {
            $table->dropColumn("gd_file_id");
            $table->dropColumn("gd_preview_file_id");
            $table->dropColumn("hidden_connected_sheet");
            $table->dropColumn("index_sheet");
            $table->dropColumn("data_sheet");
        });
    }
};
