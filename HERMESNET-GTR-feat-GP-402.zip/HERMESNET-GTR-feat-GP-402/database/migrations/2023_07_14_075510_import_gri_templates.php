<?php

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $dumpName = 'gtr_gri.sql';
        $file = Storage::drive('local')->exists($dumpName);
        if (!$file) {
            return;
        }

        DB::unprepared(file_get_contents(Storage::drive('local')->path($dumpName)));


        DB::table('gri_templates')->orderBy('id')
            ->each(function ($template) {
                $templateData = (array) $template;
                unset($templateData['id']);
                $templateData['category'] = 'complex';
                $templateData['type'] = 'summary';

                $templateOldId = $template->id;
                $templateNewId = DB::table('templates')->insertGetId($templateData);

                DB::table('gri_template_topics')
                    ->where('template_id', '=', $templateOldId)
                    ->orderBy('id')
                    ->each(function ($topic) use ($templateNewId) {
                        $topicData = (array) $topic;
                        unset($topicData['id']);
                        $topicData['template_id'] = $templateNewId;

                        $topicOldId = $topic->id;
                        $topicNewId = DB::table('template_items')->insertGetId($topicData);

                        DB::table('gri_disclosures')
                            ->where('topic_id', '=', $topicOldId)
                            ->orderBy('id')
                            ->each(function ($disclosure) use ($templateNewId, $topicNewId) {
                                $disclosureData = (array) $disclosure;
                                unset($disclosureData['id']);
                                unset($disclosureData['topic_id']);
                                $disclosureData['template_id'] = $templateNewId;
                                $disclosureData['parent_item_id'] = $topicNewId;

                                DB::table('template_items')->insert($disclosureData);
                            });
                    });
            });


        $tables = ['gri_disclosures', 'gri_template_topics', 'gri_templates'];
        foreach ($tables as $table) {
            Schema::dropIfExists($table);
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
};
