<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::create('invited_user', function (Blueprint $table) {
            $table->id();

            $table->string("name")->nullable(true);
            $table->string('email')->nullable(false);
            $table->string('role')->nullable(false);
            $table->string("status")->default("active"); // active | completed
            $table->unsignedBigInteger("organization_id")->nullable(false);
            $table->unsignedBigInteger("invited_from")->nullable(false);
            $table->unsignedBigInteger("environment_id")->nullable(true);
            $table->unsignedBigInteger("dashboard_id")->nullable(true);
            $table->unsignedBigInteger("dashboard_sheet_id")->nullable(true);


            $table->text("callback_url")->nullable(false);

            $table->foreign('organization_id')
                ->references('id')
                ->on('organizations')
                ->onDelete('cascade');

            $table->foreign('invited_from')
                ->references('id')
                ->on('users')
                ->cascadeOnDelete();



            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('invited_user');
    }
};
