<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('template_items', function (Blueprint $table) {
            $table->integer('content_type')->nullable();
            $table->string('custom_table_meta')->nullable();
        });

        // Map 'use_google_sheet' boolean values to 'content_type' integer
        \App\Models\Template\TemplateItem::chunkById(100, function ($items) {
            foreach ($items as $item) {
                $item->content_type = $item->use_google_sheet ? 1 : 0;
                $item->save();
            }
        });

        Schema::table('template_items', function (Blueprint $table) {
            $table->dropColumn('use_google_sheet');
        });
    }

    public function down()
    {
        Schema::table('template_items', function (Blueprint $table) {
            $table->boolean('use_google_sheet')->default(false);
        });

        // Map 'content_type' back to 'use_google_sheet'
        \App\Models\Template\TemplateItem::chunkById(100, function ($items) {
            foreach ($items as $item) {
                if( $item->content_type>1 ){ $item->delete(); continue; }
                $item->use_google_sheet = $item->content_type==1;
                $item->save();
            }
        });

        Schema::table('template_items', function (Blueprint $table) {
            $table->dropColumn('custom_table_meta');
            $table->dropColumn('content_type');
        });
    }
};
