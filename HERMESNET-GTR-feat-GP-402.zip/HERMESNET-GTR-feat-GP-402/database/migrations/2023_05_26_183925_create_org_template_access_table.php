<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('org_template_access', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger("organization_id");
            $table->unsignedBigInteger("global_template_id")->nullable();

            $table->foreign("organization_id")
                ->on("organizations")
                ->references("id")
                ->cascadeOnDelete();

            $table->foreign("global_template_id")
                ->on("templates")
                ->references("id")
                ->cascadeOnDelete();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('org_template_access');
    }
};
