<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::create('dsh_methodology', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger("dashboard_id")->nullable(false);
            $table->longText("content")->nullable(false);

            $table->foreign('dashboard_id')
                ->references('id')
                ->on('dashboards')
                ->onDelete('cascade');

            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('dsh_methodology');
    }
};
