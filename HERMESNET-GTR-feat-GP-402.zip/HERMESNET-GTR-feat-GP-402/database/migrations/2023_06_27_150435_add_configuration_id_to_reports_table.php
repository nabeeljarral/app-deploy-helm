<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('dashboards', function (Blueprint $table) {
            $table->unsignedBigInteger("configuration_id")->nullable();
            $table->foreign("configuration_id")
                ->on("template_configurations")
                ->references("id")
                ->cascadeOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('dashboards', function (Blueprint $table) {
            $table->dropForeign("dashboards_configuration_id_foreign");
            $table->dropColumn("configuration_id");
        });
    }
};
