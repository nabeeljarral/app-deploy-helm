<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('template_configurations', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger("template_id");
            $table->unsignedBigInteger("organization_id")->nullable();

            $table->string("name");
            $table->longText("guidance")->nullable();
            $table->boolean("is_general")->default(true); //if true - includes all template elements

            $table->foreign("template_id")
                ->on("templates")
                ->references("id")
                ->cascadeOnDelete();

            $table->foreign("organization_id")
                ->on("organizations")
                ->references("id")
                ->cascadeOnDelete();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('template_configurations');
    }
};
