<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('template_items', function (Blueprint $table) {
            $table->id();
            $table->string("name");
            $table->unsignedBigInteger("template_id");
            $table->unsignedBigInteger("parent_item_id")->nullable();
            $table->boolean("mandatory")->default(false);
            $table->longText('requirements')->nullable();
            $table->longText('recommendations')->nullable();
            $table->longText('guidance')->nullable();
            $table->longText('content')->nullable();

            //Google Sheet or Rich Text
            $table->boolean('use_google_sheet')->default(true);

            $table->string('sheet_name')->nullable();
            $table->string('sheet_height')->nullable();

            $table->foreign("template_id")
                ->references("id")
                ->on("templates")
                ->cascadeOnDelete();

            $table->softDeletes();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('template_items');
    }
};
