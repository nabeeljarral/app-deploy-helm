<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('template_related_summary', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger("data_collection_id");
            $table->unsignedBigInteger("summary_id");

            $table->foreign("data_collection_id")
                ->on("templates")
                ->references("id")
                ->cascadeOnDelete();

            $table->foreign("summary_id")
                ->on("templates")
                ->references("id")
                ->cascadeOnDelete();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('template_related_summary');
    }
};
