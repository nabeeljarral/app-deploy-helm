<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::create('dashboard_sheet_relations', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger("environment_id")->nullable(false);
            $table->unsignedBigInteger("source_sheet_id")->nullable(false);
            $table->unsignedBigInteger("destination_sheet_id")->nullable(false);
            $table->string("source_range")->default("A:Z");
            $table->dateTime("last_updated_time")->nullable(true);
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('dashboard_sheet_relations');
    }
};
