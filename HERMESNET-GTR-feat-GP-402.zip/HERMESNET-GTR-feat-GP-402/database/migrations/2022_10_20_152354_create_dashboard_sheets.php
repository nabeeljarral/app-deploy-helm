<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::create('dashboard_sheets', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger("dashboard_id")->nullable(false);
            $table->string("type")->nullable();
            $table->string("sheet_title")->nullable(false);
            $table->string("sheet_id")->nullable(false);
            $table->string("sheet_type")->nullable(false);

            $table->foreign('dashboard_id')->references('id')->on('dashboards')->onDelete('cascade');

            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('dashboard_sheets');
    }
};
