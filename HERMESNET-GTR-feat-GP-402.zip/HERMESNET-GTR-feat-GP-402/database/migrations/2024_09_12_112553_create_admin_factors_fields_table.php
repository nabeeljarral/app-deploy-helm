<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Modules\Admin\Factors\Entities\Enums\FactorFieldRole;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('admin_factors_fields', function (Blueprint $table) {
            $table->id();
            $table->foreignId('factor_id')->constrained('admin_factors');
            $table->string('system_name');
            $table->string('name');
            $table->unsignedTinyInteger('role');
            $table->unsignedTinyInteger('position')->nullable();
            $table->json('meta')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('admin_factors_fields');
    }
};
