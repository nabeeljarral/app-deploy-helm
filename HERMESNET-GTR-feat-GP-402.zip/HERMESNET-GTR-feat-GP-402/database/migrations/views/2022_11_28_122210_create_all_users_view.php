<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        DB::statement($this->createOrReplaceView());
    }

    public function down()
    {

    }

    private function createOrReplaceView(): string
    {
        return <<<SQL
CREATE OR REPLACE VIEW all_users_view as
     SELECT id,
       organization_id,
       name,
       role,
       'regular' as type,
       email,
       color,
       created_at,
       updated_at
    from users

    union
    select id,
           organization_id,
           name,
           role,
           'invited' as type,
           email,
           color,
           created_at,
           updated_at
    from invited_user
SQL;
    }
};
