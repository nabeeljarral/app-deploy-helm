<?php

use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    public function up(): void
    {
        DB::statement($this->createOrReplaceView());
    }

    public function down(): void
    {

    }

    private function createOrReplaceView(): string
    {
        return <<<SQL
        CREATE OR REPLACE VIEW configuration_items_view as
            select
                configuration_items.id,
                template_items.id as item_id,
                template_items.parent_item_id,
                template_items.name,
                configuration_items.report_id,
                configuration_items.configuration_id,
                template_items.template_id,
                template_items.order_number,
                template_items.mandatory,
                template_items.sheet_name,
                template_items.content_type,
                template_items.include_in_printing,
                template_items.requirements,
                template_items.recommendations,
                template_items.guidance,
                configuration_items.is_included,
                configuration_items.reason_of_omission,
                configuration_items.content,
                configuration_items.created_at,
                configuration_items.updated_at
            from configuration_items inner join template_items on configuration_items.item_id = template_items.id
            where template_items.deleted_at is null;
SQL;
    }
};
