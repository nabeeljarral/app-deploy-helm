<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        DB::statement($this->createOrReplaceView());
    }

    public function down()
    {

    }

    private function createOrReplaceView(): string
    {
        return <<<SQL
CREATE OR REPLACE VIEW all_users_with_permissions_view as
    SELECT users.id,
       organization_id,
       name,
       IF(dsh_users.role is null, users.role, dsh_users.role)  as role,
       'regular' as type,
       email,
       google_email as google_email,
       dashboard_id,
       environment_id,
       color,
       users.created_at,
       users.updated_at
    from users
        left join dsh_users on users.id = dsh_users.user_id
    union
    select id,
           organization_id,
           name,
           role,
           'invited' as type,
           email,
           email as google_email,
           dashboard_id,
           environment_id,
           color,
           invited_user.created_at,
           invited_user.updated_at
    from invited_user
SQL;
    }
};
