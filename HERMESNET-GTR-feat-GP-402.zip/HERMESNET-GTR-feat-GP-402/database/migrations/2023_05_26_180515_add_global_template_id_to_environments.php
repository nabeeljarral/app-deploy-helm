<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('environments', function (Blueprint $table) {
            $table->unsignedBigInteger("global_template_id")->nullable();

            $table->foreign("global_template_id")
                ->on("templates")
                ->references("id")
                ->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('environments', function (Blueprint $table) {
            $table->dropColumn("global_template_id");
        });
    }
};
