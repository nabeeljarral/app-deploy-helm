<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::table('dashboard_sheets', function (Blueprint $table) {
            $table->json("grid_properties")->nullable(true);
        });
    }

    public function down()
    {
        Schema::table('dashboard_sheets', function (Blueprint $table) {
            $table->dropColumn("grid_properties");
        });
    }
};
