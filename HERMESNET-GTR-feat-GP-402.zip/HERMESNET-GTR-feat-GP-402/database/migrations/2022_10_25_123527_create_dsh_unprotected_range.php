<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::create('dsh_unprotected_range', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger("dsh_protection_id");

            $table->integer("start_row_id");
            $table->integer("end_row_id");
            $table->integer("start_column_id");
            $table->integer("end_column_id");

            $table->foreign('dsh_protection_id')
                ->references('id')
                ->on('dsh_protections')
                ->cascadeOnDelete();

            $table->boolean("need_implement")->default(false);

            $table->softDeletes();

            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('dsh_unprotected_range');
    }
};
