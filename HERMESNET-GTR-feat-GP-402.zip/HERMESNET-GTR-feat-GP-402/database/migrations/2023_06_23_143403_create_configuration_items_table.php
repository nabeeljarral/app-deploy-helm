<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('configuration_items', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger("configuration_id")->nullable();
            $table->unsignedBigInteger("report_id")->nullable();
            $table->unsignedBigInteger("item_id");

            $table->boolean("is_included")->default(true);
            $table->longText("reason_of_omission")->nullable();

            $table->foreign("configuration_id")
                ->on("template_configurations")
                ->references("id")
                ->cascadeOnDelete();

            $table->foreign("report_id")
                ->on("dashboards")
                ->references("id")
                ->cascadeOnDelete();

            $table->foreign("item_id")
                ->on("template_items")
                ->references("id")
                ->cascadeOnDelete();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('configuration_items');
    }
};
