<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::create('dashboards', function (Blueprint $table) {
            $table->id();

            $table->string('name')->nullable(false);
            $table->string('type')->nullable(false);
            $table->string('country')->nullable(true);
            $table->unsignedBigInteger('environment_id')->nullable(false);
            $table->text("template_id")->nullable(true);
            $table->text("file_id")->nullable(true);

            $table->foreign('environment_id')
                ->references('id')
                ->on('environments')
                ->onDelete('cascade');

            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('dashboards');
    }
};
