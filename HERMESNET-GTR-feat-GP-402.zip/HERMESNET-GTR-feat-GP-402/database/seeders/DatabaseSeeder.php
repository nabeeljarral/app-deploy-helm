<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use App\Models\Template\TemplateConfiguration;
use App\Models\Template\TemplateItem;
use App\Models\Template\Template;
use App\Services\Dashboard\Enums\DashboardType;
use App\Services\Template\Enums\TemplateCategory;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        \App\Models\City::create([
            'city' => 'test',
            'country' => 'test',
            'country_code' => 0,
        ]);
        \App\Models\User::create([
            'name' => 'test',
            'email' => 'test@test.com',
            'password' => bcrypt('password'),
            'is_admin' => true,
            'color' => '#4B97D8',
            'remember_token' => \Str::random(10),
        ]);
        Template::factory(1)
            ->create([
                'name' => 'Complex GRI',
                'category'           => TemplateCategory::COMPLEX,
                'is_published'       => true,
                'is_trial'           => false,
                'gd_file_id'         => '1y7UvuDC4AabG0S-w34rCwVEzpfhYsGVMAwwhpIE889E',
                'gd_preview_file_id' => '1y7UvuDC4AabG0S-w34rCwVEzpfhYsGVMAwwhpIE889E',
                'type'               => DashboardType::SUMMARY_DASHBOARD,
            ])
            ->each(function (Template $template) {
                $template->items()
                    ->saveMany(
                        TemplateItem::factory(5)->create([
                            'template_id' => $template->id,
                            'mandatory' => false,
                        ]))
                    ->each(function (TemplateItem $item) {
                        $item->childItems()
                            ->saveMany(TemplateItem::factory(5)->create([
                                'template_id'    => $item->template_id,
                                'parent_item_id' => $item->id,
                            ]));
                    });

                TemplateConfiguration::create([
                    'template_id'     => $template->id,
                    'organization_id' => null,
                    'name'            => "General GRI Standard",
                    'guidance'        => $template->guidance,
                    'is_general'      => true,
                ]);
            });
    }
}
