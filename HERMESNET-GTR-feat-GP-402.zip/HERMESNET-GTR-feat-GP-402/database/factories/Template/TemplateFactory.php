<?php

namespace Database\Factories\Template;

use App\Models\Template\Template;
use App\Services\Dashboard\Enums\DashboardType;
use App\Services\Template\Enums\TemplateCategory;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Carbon;

class TemplateFactory extends Factory
{
    protected $model = Template::class;

    public function definition(): array
    {
        return [
            'name'                 => $this->faker->name(),
            'description'          => $this->faker->text(50),
            'category'             => TemplateCategory::DEFAULT,
            'is_trial'             => true,
            'is_public'            => true,
            'created_at'           => Carbon::now(),
            'updated_at'           => Carbon::now(),
            'is_published'         => $this->faker->boolean(),
            'type'                 => DashboardType::DASHBOARD,
            'is_blank'             => false,
            'use_with_any_summary' => true,
            'has_preview'          => false,
            'guidance'             => $this->faker->randomHtml(3, 6),
        ];
    }
}
