<?php

namespace Database\Factories\Template;

use App\Models\Template\TemplateItem;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Carbon;

class TemplateItemFactory extends Factory
{
    protected $model = TemplateItem::class;

    public function definition(): array
    {
        $sheets_name = [
            'Tab1','Tab2','Tab3','Tab4','Tab5','Tab6','Tab7','Tab8','Tab9','Tab10',
        ];

        return [
            'name'                => $this->faker->name(),
            'mandatory'           => $this->faker->boolean(),
            'requirements'        => $this->faker->randomHtml(3, 6),
            'recommendations'     => $this->faker->randomHtml(3, 6),
            'guidance'            => $this->faker->randomHtml(3, 6),
            'content'             => $this->faker->randomHtml(3, 6),
            'custom_table_meta'   => null,
            'content_type'        => $this->faker->numberBetween(0, 1), // We don't create custom_table content type
            'sheet_name'          => \Arr::random($sheets_name),
            'sheet_height'        => $this->faker->word(),
            'created_at'          => Carbon::now(),
            'updated_at'          => Carbon::now(),
        ];
    }
}
